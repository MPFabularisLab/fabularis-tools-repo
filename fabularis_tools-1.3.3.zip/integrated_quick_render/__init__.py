bl_info = {
    "name": "Quick Render Presets",
    "author": "Tu",
    "version": (3, 7, 4),
    "blender": (4, 2, 0),
    "location": "Properties > Render > Quick Render Presets  |  3D View > N-panel > Render",
    "description": "Preset ottimizzati per Cycles ed EEVEE: interno, esterno, dettaglio, impianti + ottimizzazione camera + flag trasparenze e slider qualità/rimbalzi",
    "category": "Render",
}

import bpy
from bpy.props import EnumProperty, BoolProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import Operator, Panel, PropertyGroup


# ---------------------------------------------------------------------------
# Helper: imposta un attributo solo se esiste (robusto tra versioni di Blender)
# ---------------------------------------------------------------------------
def _set(obj, name, value):
    try:
        if hasattr(obj, name):
            setattr(obj, name, value)
            return True
    except Exception as e:
        print(f"[QuickRenderPresets] impossibile impostare {name}: {e}")
    return False


def _apply_obj(obj, data):
    """Applica un dizionario di valori a un oggetto; i dizionari annidati
    (es. ray_tracing_options) vengono applicati al sotto-oggetto."""
    for k, v in data.items():
        if isinstance(v, dict):
            sub = getattr(obj, k, None)
            if sub is not None:
                _apply_obj(sub, v)
        else:
            _set(obj, k, v)


def _eevee_engine_id():
    """Blender 4.2-4.x usa BLENDER_EEVEE_NEXT, la 5.x è tornata a BLENDER_EEVEE."""
    try:
        items = [i.identifier for i in
                 bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
    except Exception:
        items = []
    for candidate in ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"):
        if candidate in items:
            return candidate
    return "BLENDER_EEVEE"


# ===========================================================================
#                                CYCLES
# ===========================================================================
CYCLES_BASE = {
    "cycles": {
        "device": "GPU",
        # Viewport
        "use_preview_adaptive_sampling": True,
        "preview_adaptive_threshold": 0.1,
        "preview_samples": 1024,
        "preview_adaptive_min_samples": 0,
        "use_preview_denoising": False,
        # Render
        "use_adaptive_sampling": True,
        "adaptive_threshold": 0.01,
        "samples": 300,
        "adaptive_min_samples": 0,
        "time_limit": 0.0,
        "use_denoising": True,
        "denoiser": "OPTIX",
        "denoising_input_passes": "RGB_ALBEDO_NORMAL",
        # Luci
        "use_light_tree": False,
        "light_sampling_threshold": 0.01,
        # Light paths
        "max_bounces": 5,
        "diffuse_bounces": 4,
        "glossy_bounces": 4,
        "transmission_bounces": 12,
        "volume_bounces": 0,
        "transparent_max_bounces": 8,
        "sample_clamp_direct": 0.0,
        "sample_clamp_indirect": 10.0,
        "blur_glossy": 1.0,
        "caustics_reflective": True,
        "caustics_refractive": True,
        "use_fast_gi": True,
        # Culling
        "use_camera_cull": True,
        "camera_cull_margin": 0.1,
        "use_distance_cull": False,
        # Texture
        "texture_limit": "2048",          # viewport
        "texture_limit_render": "OFF",    # render
        # Film
        "pixel_filter_type": "BLACKMAN_HARRIS",
        "filter_width": 1.5,
        "film_transparent_glass": False,
        "film_transparent_roughness": 0.1,
        # Performance
        "tile_size": 2048,
        "debug_use_spatial_splits": False,
        "debug_use_compact_bvh": False,
    },
    "render": {
        "use_simplify": True,
        "simplify_subdivision": 2,
        "simplify_subdivision_render": 6,
        "simplify_child_particles_render": 1.0,
        "use_persistent_data": True,
        "film_transparent": False,
    },
    "view": {
        "view_transform": "AgX",
        "look": "None",
        "exposure": 0.0,
        "gamma": 1.0,
    },
}

CYCLES_PRESETS = {
    "BASE": {},  # Impostazioni originali degli screenshot, senza override.
    "INTERIOR": {
        "cycles": {
            "samples": 400,
            "adaptive_threshold": 0.015,
            "use_light_tree": True,
            "max_bounces": 6,
            "diffuse_bounces": 4,
            "glossy_bounces": 3,
            "sample_clamp_indirect": 5.0,
            "caustics_reflective": False,
            "caustics_refractive": False,
            "use_fast_gi": False,
        },
        "render": {"simplify_subdivision_render": 4},
    },
    "EXTERIOR": {
        "cycles": {
            "samples": 200,
            "adaptive_threshold": 0.02,
            "use_light_tree": False,
            "max_bounces": 4,
            "diffuse_bounces": 2,
            "glossy_bounces": 3,
            "sample_clamp_indirect": 10.0,
            "caustics_reflective": False,
            "caustics_refractive": False,
            "use_fast_gi": True,
        },
        "render": {"simplify_subdivision_render": 6},
    },
    "DETAIL": {
        "cycles": {
            "samples": 600,
            "adaptive_threshold": 0.008,
            "use_light_tree": True,
            "max_bounces": 6,
            "diffuse_bounces": 4,
            "glossy_bounces": 5,
            "sample_clamp_indirect": 10.0,
            "caustics_reflective": True,
            "caustics_refractive": True,
            "use_fast_gi": False,
            "use_camera_cull": False,
            "filter_width": 1.2,
        },
        "render": {"use_simplify": False},
    },
    "ANIMATION": {
        "cycles": {
            "samples": 128,
            "adaptive_threshold": 0.03,
            "adaptive_min_samples": 16,
            "use_light_tree": True,
            "max_bounces": 4,
            "diffuse_bounces": 2,
            "glossy_bounces": 2,
            "transmission_bounces": 6,
            "transparent_max_bounces": 6,
            "sample_clamp_indirect": 5.0,
            "caustics_reflective": False,
            "caustics_refractive": False,
            "use_fast_gi": True,
            "use_camera_cull": True,
            "camera_cull_margin": 0.2,
            "use_distance_cull": True,
            "distance_cull_margin": 100.0,
            "texture_limit_render": "2048",
        },
        "render": {
            "use_simplify": True,
            "simplify_subdivision_render": 3,
            "simplify_child_particles_render": 0.5,
            "use_persistent_data": True,
        },
    },
}

CYCLES_TRANSPARENCY = {
    "cycles": {
        "transparent_max_bounces": 12,
        "transmission_bounces": 10,
        "caustics_refractive": False,
        "use_fast_gi": False,
        "film_transparent_glass": True,
    },
    "min_total_bounces": 10,
}


# ===========================================================================
#                                EEVEE
#  (EEVEE "Next": Blender 4.2+. I nomi sono applicati solo se esistono.)
# ===========================================================================
EEVEE_BASE = {
    "eevee": {
        "taa_samples": 16,                 # viewport
        "taa_render_samples": 128,
        "use_taa_reprojection": True,
        "use_shadows": True,
        "light_threshold": 0.01,
        "use_volumetric_shadows": False,
        "use_raytracing": False,
        "ray_tracing_method": "SCREEN",
        "ray_tracing_options": {
            "resolution_scale": "2",
            "trace_max_roughness": 0.5,
            "use_denoise": True,
        },
        "fast_gi_method": "AMBIENT_OCCLUSION_ONLY",
        "fast_gi_resolution": "2",
        "fast_gi_ray_count": 2,
        "fast_gi_step_count": 8,
        "shadow_ray_count": 1,
        "shadow_step_count": 6,
        "gi_diffuse_bounces": 3,
        "volumetric_tile_size": "2",
        "volumetric_samples": 64,
    },
    "render": {
        "use_simplify": True,
        "simplify_subdivision": 2,
        "simplify_subdivision_render": 6,
        "simplify_child_particles_render": 1.0,
        "film_transparent": False,
        "use_motion_blur": False,
    },
    "view": {
        "view_transform": "AgX",
        "look": "None",
        "exposure": 0.0,
        "gamma": 1.0,
    },
}

EEVEE_PRESETS = {
    "BASE": {},  # Base EEVEE; gli screenshot originali si riferiscono a Cycles.
    "INTERIOR": {
        "eevee": {
            "taa_render_samples": 128,
            "use_raytracing": True,                 # riflessi/GI più credibili in interno
            "ray_tracing_options": {"resolution_scale": "2"},
            "fast_gi_method": "GLOBAL_ILLUMINATION",
            "fast_gi_ray_count": 2,
            "fast_gi_step_count": 8,
            "shadow_ray_count": 2,
            "shadow_step_count": 8,
            "gi_diffuse_bounces": 3,
            "volumetric_samples": 64,
        },
        "render": {"simplify_subdivision_render": 4},
    },
    "EXTERIOR": {
        "eevee": {
            "taa_render_samples": 64,
            "use_raytracing": False,                # sole/HDRI: bastano probe e AO
            "fast_gi_method": "AMBIENT_OCCLUSION_ONLY",
            "shadow_ray_count": 1,
            "shadow_step_count": 6,
            "gi_diffuse_bounces": 2,
            "volumetric_tile_size": "4",
            "volumetric_samples": 48,
        },
        "render": {"simplify_subdivision_render": 6},
    },
    "DETAIL": {
        "eevee": {
            "taa_render_samples": 256,
            "use_raytracing": True,
            "ray_tracing_options": {"resolution_scale": "1", "trace_max_roughness": 0.6},
            "fast_gi_method": "GLOBAL_ILLUMINATION",
            "fast_gi_resolution": "1",
            "fast_gi_ray_count": 4,
            "fast_gi_step_count": 12,
            "shadow_ray_count": 4,
            "shadow_step_count": 12,
            "gi_diffuse_bounces": 4,
            "volumetric_tile_size": "1",
            "volumetric_samples": 96,
        },
        "render": {"use_simplify": False},
    },
    "ANIMATION": {
        "eevee": {
            "taa_render_samples": 48,
            "use_raytracing": False,
            "fast_gi_method": "AMBIENT_OCCLUSION_ONLY",
            "fast_gi_resolution": "4",
            "shadow_ray_count": 1,
            "shadow_step_count": 4,
            "gi_diffuse_bounces": 2,
            "volumetric_tile_size": "4",
            "volumetric_samples": 32,
            "use_taa_reprojection": True,
        },
        "render": {
            "use_simplify": True,
            "simplify_subdivision_render": 3,
            "simplify_child_particles_render": 0.5,
        },
    },
}

EEVEE_TRANSPARENCY = {
    "eevee": {
        # La rifrazione dei vetri richiede il ray tracing
        "use_raytracing": True,
        "ray_tracing_method": "SCREEN",
        "ray_tracing_options": {"trace_max_roughness": 0.5},
    },
}


# ---------------------------------------------------------------------------
# Backup / reset: salva i valori originali della scena prima del primo preset
# ---------------------------------------------------------------------------
BACKUP_KEY = "qrp_backup"
_SECTIONS = ("cycles", "eevee", "render", "view")
_suppress_live = False   # evita di riapplicare il preset mentre si resetta l'UI


def _root(scene, section):
    return {
        "cycles": scene.cycles,
        "eevee": scene.eevee,
        "render": scene.render,
        "view": scene.view_settings,
    }[section]


def _collect_paths(data, prefix, out):
    for k, v in data.items():
        if isinstance(v, dict):
            _collect_paths(v, prefix + (k,), out)
        else:
            out.add(prefix + (k,))


def _all_managed_paths():
    """Tutti i parametri che l'addon può modificare (da tutti i preset)."""
    paths = set()
    sources = [CYCLES_BASE, CYCLES_TRANSPARENCY, EEVEE_BASE, EEVEE_TRANSPARENCY]
    sources += list(CYCLES_PRESETS.values()) + list(EEVEE_PRESETS.values())
    for src in sources:
        for section in _SECTIONS:
            if section in src:
                _collect_paths(src[section], (section,), paths)
    return paths


def _resolve(scene, path):
    """Restituisce (oggetto, nome_attributo) per un percorso, o (None, None)."""
    obj = _root(scene, path[0])
    for part in path[1:-1]:
        obj = getattr(obj, part, None)
        if obj is None:
            return None, None
    return obj, path[-1]


def ensure_backup(scene):
    """Salva lo stato originale solo la prima volta (finché non si fa reset)."""
    if BACKUP_KEY in scene:
        return
    import json
    values = {}
    for path in _all_managed_paths():
        obj, name = _resolve(scene, path)
        if obj is None or not hasattr(obj, name):
            continue
        try:
            val = getattr(obj, name)
        except Exception:
            continue
        if isinstance(val, (bool, int, float, str)):
            values["/".join(path)] = val
    scene[BACKUP_KEY] = json.dumps({"engine": scene.render.engine, "values": values})


def restore_backup(scene):
    import json
    raw = scene.get(BACKUP_KEY)
    if not raw:
        return False
    data = json.loads(raw)
    _set(scene.render, "engine", data.get("engine", scene.render.engine))
    for key, val in data.get("values", {}).items():
        obj, name = _resolve(scene, tuple(key.split("/")))
        if obj is not None:
            _set(obj, name, val)
    del scene[BACKUP_KEY]
    return True


# ---------------------------------------------------------------------------
# Applicazione del preset
# ---------------------------------------------------------------------------
def _apply_sections(scene, data):
    if "cycles" in data:
        _apply_obj(scene.cycles, data["cycles"])
    if "eevee" in data:
        _apply_obj(scene.eevee, data["eevee"])
    if "render" in data:
        _apply_obj(scene.render, data["render"])
    if "view" in data:
        _apply_obj(scene.view_settings, data["view"])


def apply_cycles(scene, scene_type, has_transparency, quality, bounce_offset):
    scene.render.engine = "CYCLES"
    cy = scene.cycles

    _apply_sections(scene, CYCLES_BASE)
    _apply_sections(scene, CYCLES_PRESETS[scene_type])

    if has_transparency:
        _apply_sections(scene, {"cycles": CYCLES_TRANSPARENCY["cycles"]})
        _set(cy, "max_bounces", max(cy.max_bounces, CYCLES_TRANSPARENCY["min_total_bounces"]))

    # Qualità: moltiplica i samples e adegua la soglia di rumore
    if abs(quality - 1.0) > 1e-4:
        _set(cy, "samples", max(1, round(cy.samples * quality)))
        _set(cy, "adaptive_threshold", max(0.001, cy.adaptive_threshold / quality))

    # Rimbalzi: somma/sottrae ai valori del preset
    if bounce_offset != 0:
        for name, minimum in (
            ("max_bounces", 1),
            ("diffuse_bounces", 0),
            ("glossy_bounces", 0),
            ("transmission_bounces", 0),
            ("transparent_max_bounces", 0),
        ):
            if hasattr(cy, name):
                _set(cy, name, max(minimum, getattr(cy, name) + bounce_offset))


def apply_eevee(scene, scene_type, has_transparency, quality, bounce_offset):
    scene.render.engine = _eevee_engine_id()
    ee = scene.eevee

    _apply_sections(scene, EEVEE_BASE)
    _apply_sections(scene, EEVEE_PRESETS[scene_type])

    if has_transparency:
        _apply_sections(scene, EEVEE_TRANSPARENCY)

    # Qualità: moltiplica i samples di render
    if abs(quality - 1.0) > 1e-4 and hasattr(ee, "taa_render_samples"):
        _set(ee, "taa_render_samples", max(1, round(ee.taa_render_samples * quality)))

    # Rimbalzi: in EEVEE agiscono sui rimbalzi diffusi della GI
    if bounce_offset != 0 and hasattr(ee, "gi_diffuse_bounces"):
        _set(ee, "gi_diffuse_bounces", max(0, ee.gi_diffuse_bounces + bounce_offset))


def apply_preset(scene, engine, scene_type, has_transparency, transparent_bg, quality, bounce_offset):
    ensure_backup(scene)
    if engine == "EEVEE":
        apply_eevee(scene, scene_type, has_transparency, quality, bounce_offset)
    else:
        apply_cycles(scene, scene_type, has_transparency, quality, bounce_offset)
    # Sfondo trasparente (PNG con alpha): opzione separata, vale per entrambi i motori
    _set(scene.render, "film_transparent", bool(transparent_bg))


# ---------------------------------------------------------------------------
# Proprietà, operatore e pannello
# ---------------------------------------------------------------------------
def _run(settings, scene):
    apply_preset(
        scene,
        settings.engine,
        settings.scene_type,
        settings.has_transparency,
        settings.transparent_bg,
        settings.quality,
        settings.bounce_offset,
    )


def _live_update(self, context):
    if self.live_update and not _suppress_live and _optimizer_job is None:
        _run(self, context.scene)


# ---------------------------------------------------------------------------
# Ottimizzazione camera: frustum conservativo, unione di tutti i frame.
# Nessuna cancellazione, keyframe o modifica dei materiali.
# ---------------------------------------------------------------------------
import time
import math
from mathutils import Vector
from bpy.props import CollectionProperty, StringProperty
try:
    from bpy_extras.object_utils import world_to_camera_view
except ImportError:
    world_to_camera_view = None

_optimizer_job = None


def _elapsed(seconds):
    seconds = max(0, int(seconds))
    return f"{seconds // 60:02d}:{seconds % 60:02d}"


def _redraw(context):
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in {'VIEW_3D', 'PROPERTIES'}:
                area.tag_redraw()


def _in_frustum(corners, matrix, margin):
    """Reject only if ALL box corners lie beyond ONE homogeneous clip plane.
    Unlike a corner-inside test, this retains large walls crossing the image.
    Blender projection uses OpenGL NDC [-1, 1], including the depth axis.
    """
    clip = [matrix @ Vector((c[0], c[1], c[2], 1.0)) for c in corners]
    if not clip or any(not math.isfinite(v) for p in clip for v in p):
        return True
    limit = 1.0 + 2.0 * margin
    planes = (
        lambda p: p.x + limit * p.w,
        lambda p: limit * p.w - p.x,
        lambda p: p.y + limit * p.w,
        lambda p: limit * p.w - p.y,
        lambda p: p.z + p.w,
        lambda p: p.w - p.z,
    )
    return not any(all(plane(p) < -1e-7 for p in clip) for plane in planes)


def _bounds_in_camera(scene, camera, evaluated, matrix_world, margin):
    """Test an evaluated object's world-space bounds in Blender camera space.

    world_to_camera_view handles Blender's camera conventions (lens, sensor,
    shift, orthographic scale and clipping) directly. The homogeneous fallback
    remains available for stripped-down/background Blender environments.
    """
    bounds = getattr(evaluated, 'bound_box', None)
    if not bounds:
        return True
    if world_to_camera_view is None:
        return True
    try:
        points = []
        for c in bounds:
            world4 = matrix_world @ Vector((c[0], c[1], c[2], 1.0))
            points.append(world_to_camera_view(
                scene, camera, Vector((world4[0], world4[1], world4[2]))))
        pad = max(0.0, float(margin))
        if all(p.z < 0.0 for p in points):
            return False
        return not (
            all(p.x < -pad for p in points) or
            all(p.x > 1.0 + pad for p in points) or
            all(p.y < -pad for p in points) or
            all(p.y > 1.0 + pad for p in points)
        )
    except Exception:
        return True


def _fully_occluded(scene, depsgraph, camera, evaluated, matrix_world):
    """Conservative occlusion test using the center and bounding-box corners.

    A mesh becomes a candidate only when every sampled point is reached through
    another object first. One visible corner keeps the whole mesh active.
    """
    ray_cast = getattr(scene, 'ray_cast', None)
    bounds = getattr(evaluated, 'bound_box', None)
    if ray_cast is None or not bounds:
        return False
    try:
        center = sum((Vector(c) for c in bounds), Vector((0.0, 0.0, 0.0))) / len(bounds)
        samples = [center]
        # Corners are deliberately sampled after the center: most fully hidden
        # industrial parts are rejected with one ray, while thin visible parts
        # are protected by the corner checks.
        samples.extend(Vector(c) for c in bounds)
        world_points = []
        for point in samples:
            world4 = matrix_world @ Vector((point[0], point[1], point[2], 1.0))
            world_points.append(Vector((world4[0], world4[1], world4[2])))
        cam_origin = camera.matrix_world.translation.copy()
        if camera.data.type == 'ORTHO':
            direction = (camera.matrix_world.to_3x3() @ Vector((0.0, 0.0, -1.0))).normalized()
            origins = [point - direction * 100000.0 for point in world_points]
        else:
            direction = None
            origins = [cam_origin] * len(world_points)
        original = getattr(evaluated, 'original', evaluated)
        for point, origin in zip(world_points, origins):
            ray = point - origin
            distance = ray.length
            if distance <= 1e-7:
                return False
            ray.normalize()
            result = ray_cast(depsgraph, origin, ray, distance=distance - 1e-5)
            hit = result[0]
            if not hit:
                return False
            hit_object = result[4]
            hit_original = getattr(hit_object, 'original', hit_object)
            if hit_original is original:
                return False
        return True
    except Exception:
        # Ray casting availability differs for some evaluated/procedural data;
        # keep the object active when the test is inconclusive.
        return False
class QRP_VisibilityBackup(PropertyGroup):
    obj: PointerProperty(type=bpy.types.Object)
    hidden: BoolProperty()


def _camera_poll(self, obj):
    return obj.type == 'CAMERA' and obj.name in self.id_data.objects


class QRP_CameraChoice(PropertyGroup):
    camera: PointerProperty(type=bpy.types.Object, poll=_camera_poll)
    enabled: BoolProperty(name='Analizza', default=False)


class QRP_Candidate(PropertyGroup):
    obj: PointerProperty(type=bpy.types.Object)


def _sync_camera_choices(scene):
    choices = scene.qrp_settings.optimizer_cameras
    selected = {item.camera for item in choices if item.camera and item.enabled}
    choices.clear()
    for camera in sorted((o for o in scene.objects if o.type == 'CAMERA'), key=lambda o: o.name.casefold()):
        entry = choices.add()
        entry.camera = camera
        entry.enabled = camera in selected


def _clear_candidates(scene):
    scene.qrp_candidates.clear()


def _store_candidates(scene, objects):
    _clear_candidates(scene)
    for obj in objects:
        entry = scene.qrp_candidates.add()
        entry.obj = obj


def _candidate_objects(scene):
    return [entry.obj for entry in scene.qrp_candidates if entry.obj is not None]


def _scene_has_animation(scene):
    """Conservative check: only static scenes may skip identical camera frames."""
    for obj in scene.objects:
        if obj.animation_data or obj.constraints:
            return True
        for mod in obj.modifiers:
            if mod.type in {'ARMATURE', 'CAST', 'CURVE', 'DISPLACE', 'HOOK',
                            'LATTICE', 'MESH_DEFORM', 'SHRINKWRAP', 'SMOOTH',
                            'SURFACE_DEFORM', 'WARP', 'WAVE', 'NODES'}:
                return True
    return False


def _camera_signature(scene, cameras):
    """Signature for camera identity and transform at the current frame."""
    active = scene.camera.name if scene.camera else None
    values = [active]
    for camera in cameras:
        values.append(camera.name if camera else None)
        if camera:
            values.extend(round(float(v), 6) for row in camera.matrix_world for v in row)
    return tuple(values)


def _camera_mode_update(self, context):
    if self.optimizer_camera_mode == 'MULTI' and _optimizer_job is None:
        _sync_camera_choices(self.id_data)


def _selected_cameras(scene):
    """None means follow the active/marker-bound scene camera on each frame."""
    settings = scene.qrp_settings
    mode = settings.optimizer_camera_mode
    if mode == 'SCENE':
        if scene.camera is None:
            raise ValueError('Imposta la camera della scena o scegli una camera da analizzare')
        return None
    if mode == 'SINGLE':
        cameras = [settings.optimizer_camera]
    else:
        cameras = [item.camera for item in settings.optimizer_cameras if item.enabled]
    if not cameras:
        raise ValueError('Seleziona almeno una camera da analizzare')
    result = []
    for camera in cameras:
        if camera is None or camera.type != 'CAMERA' or camera.name not in scene.objects:
            raise ValueError('Camera non valida: scegli una camera della scena o aggiorna elenco')
        if camera not in result:
            result.append(camera)
    return result


class QRP_OT_refresh_cameras(Operator):
    bl_idname = 'render.qrp_refresh_cameras'
    bl_label = 'Aggiorna elenco'
    bl_description = 'Aggiorna le camere della scena mantenendo le spunte già impostate'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _optimizer_job is None

    def execute(self, context):
        _sync_camera_choices(context.scene)
        return {'FINISHED'}


class QRP_UL_cameras(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, 'enabled', text='')
        row.label(text=item.camera.name if item.camera else 'Camera rimossa', icon='CAMERA_DATA')


def _restore_visibility(scene):
    count = 0
    # Remove a record only AFTER successful restoration, so errors remain recoverable.
    for i in range(len(scene.qrp_visibility_backup) - 1, -1, -1):
        entry = scene.qrp_visibility_backup[i]
        if entry.obj is not None:
            entry.obj.hide_render = entry.hidden
            count += 1
        scene.qrp_visibility_backup.remove(i)
    return count


def _protected_mesh(obj):
    # Viewport depsgraph is not a render depsgraph. Keep unsupported differences.
    if obj.library or len(obj.users_scene) > 1 or obj.hide_viewport:
        return True
    if obj.is_instancer or obj.instance_type != 'NONE' or getattr(obj, 'particle_systems', None):
        return True
    if obj.animation_data:  # Includes drivers, NLA and animated render visibility.
        # Transforms are supported, but inspecting all NLA/slot F-curves across
        # Blender releases is fragile: protect objects with any render visibility animation.
        ad = obj.animation_data
        if ad.action or ad.nla_tracks or ad.drivers:
            # Object transforms are still evaluated frame by frame; protect only
            # visibility channels, but retain complex NLA/slotted actions conservatively.
            if ad.nla_tracks:
                return True
            if any(d.data_path == 'hide_render' for d in ad.drivers):
                return True
            if ad.action:
                curves = getattr(ad.action, 'fcurves', None)
                if curves is None:
                    return True
                if any(c.data_path == 'hide_render' for c in curves):
                    return True
    for mod in obj.modifiers:
        if mod.type == 'NODES' or mod.show_viewport != mod.show_render:
            return True
        if mod.type == 'SUBSURF' and mod.levels != mod.render_levels:
            return True
        if mod.type == 'MULTIRES' and mod.levels != mod.render_levels:
            return True
    return False


def _object_dependencies(owner):
    # Keep modifier/constraint targets (booleans, armatures, shrinkwrap, etc.).
    for part in list(owner.modifiers) + list(owner.constraints):
        for prop in part.bl_rna.properties:
            if prop.type != 'POINTER' or prop.identifier == 'rna_type':
                continue
            value = getattr(part, prop.identifier, None)
            if isinstance(value, bpy.types.Object):
                yield value
            elif isinstance(value, bpy.types.Collection):
                yield from value.all_objects


def _node_dependencies(tree, visited=None):
    if tree is None:
        return
    if visited is None:
        visited = set()
    if tree.as_pointer() in visited:
        return
    visited.add(tree.as_pointer())
    for node in tree.nodes:
        for socket in node.inputs:
            value = getattr(socket, 'default_value', None)
            if isinstance(value, bpy.types.Object):
                yield value
            elif isinstance(value, bpy.types.Collection):
                yield from value.all_objects
        yield from _node_dependencies(getattr(node, 'node_tree', None), visited)


class QRP_OT_optimize(Operator):
    bl_idname = 'render.qrp_optimize_camera'
    bl_label = 'Analizza e ottimizza'
    bl_description = ('Esclude dal render le mesh sempre fuori camera; analizza ogni frame. '
                      'Non rileva le occlusioni. Esc annulla senza applicare risultati parziali')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if _optimizer_job is not None:
            return False
        try:
            _selected_cameras(context.scene)
        except ValueError:
            return False
        return True

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        global _optimizer_job
        scene = context.scene
        try:
            self.cameras = _selected_cameras(scene)
        except ValueError as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        if self.cameras:
            for camera in self.cameras:
                if camera.name not in context.view_layer.objects or camera.hide_viewport:
                    self.report({'ERROR'}, f'Camera {camera.name}: rendila disponibile nel View Layer attivo')
                    return {'CANCELLED'}
        if scene.render.use_multiview:
            self.report({'ERROR'}, 'Disattiva Multi-View stereoscopico; usa Più camere per camere indipendenti')
            return {'CANCELLED'}
        if getattr(scene.render, 'use_motion_blur', False):
            self.report({'ERROR'}, 'Motion Blur attivo: i sottoframe non sono supportati. Disattivalo per questa analisi')
            return {'CANCELLED'}
        if not context.window:
            self.report({'ERROR'}, 'Avvia il calcolo da una finestra Blender')
            return {'CANCELLED'}
        # Reanalysis must see geometry excluded by the previous run as well.
        # Restore only our exclusions; pre-existing hidden objects stay hidden.
        try:
            _restore_visibility(scene)
            _clear_candidates(scene)
        except Exception as exc:
            self.report({'ERROR'}, f'Ripristino prima della nuova analisi non riuscito: {exc}')
            return {'CANCELLED'}
        self.scene = scene
        self.view_layer = context.view_layer
        self.frame = scene.frame_current
        self.subframe = scene.frame_subframe
        self.camera = scene.camera
        self.started = time.monotonic()
        self._timer = None
        self._committing = False
        self._cancel_requested = False
        self.s = scene.qrp_settings
        self.s.optimizer_progress = 0.0
        self.s.optimizer_report = ''
        self.s.optimizer_elapsed = '00:00'
        self.s.optimizer_status = 'Preparazione... Esc per annullare'
        self.worker = self._work(context)
        _optimizer_job = self
        try:
            self._timer = context.window_manager.event_timer_add(0.08, window=context.window)
            context.window_manager.modal_handler_add(self)
        except Exception:
            _optimizer_job = None
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
            raise
        return {'RUNNING_MODAL'}

    def _work(self, context):
        scene = self.scene
        s = self.s
        candidates = []
        protected = set()
        all_meshes = 0
        # Preparation is chunked too: no long uninterruptible Python mesh scan.
        for i, obj in enumerate(scene.objects):
            if obj.type == 'MESH':
                all_meshes += 1
                if not obj.hide_render:
                    candidates.append(obj)
                    if _protected_mesh(obj):
                        protected.add(obj)
            protected.update(_object_dependencies(obj))
            for mod in obj.modifiers:
                if mod.type == 'NODES':
                    protected.update(_node_dependencies(mod.node_group))
                    # Blender 5.2 exposes some modifier structs without the
                    # IDProperty mapping API.  In that case ``mod.keys()``
                    # raises instead of returning an empty list.
                    try:
                        mod_keys = mod.keys() if hasattr(mod, 'keys') else ()
                    except (AttributeError, TypeError, RuntimeError):
                        mod_keys = ()
                    for key in mod_keys:
                        try:
                            value = mod[key]
                        except (KeyError, AttributeError, TypeError, RuntimeError):
                            continue
                        if isinstance(value, bpy.types.Object):
                            protected.add(value)
                        elif isinstance(value, bpy.types.Collection):
                            protected.update(value.all_objects)
            if obj.instance_collection:
                protected.update(obj.instance_collection.all_objects)
            if i % 32 == 0:
                s.optimizer_status = f'Analisi struttura: {i + 1} oggetti'
                yield
        candidate_set = set(candidates)
        visible = set(protected) & candidate_set
        observed = set()
        if s.optimizer_animation:
            frames = range(scene.frame_start, scene.frame_end + 1)
        else:
            frames = [self.frame]
        nframes = len(frames)
        margin = s.optimizer_margin
        static_scene = not _scene_has_animation(scene)
        last_signature = None
        analyzed_frames = 0
        for fi, frame in enumerate(frames):
            s.optimizer_status = f'Frame {frame} ({fi + 1}/{nframes}) · Esc interrompe'
            yield  # Give Blender a chance to process Esc before dependency evaluation.
            scene.frame_set(frame, subframe=0.0 if s.optimizer_animation else self.subframe)
            # frame_set updates marker-bound cameras too.
            dg = context.evaluated_depsgraph_get()
            cameras = self.cameras if self.cameras is not None else [scene.camera]
            signature_cameras = [scene.camera] if self.cameras is None else cameras
            signature = _camera_signature(scene, signature_cameras)
            # Static identical frames are always skipped; this is internal and
            # intentionally has no UI checkbox.
            if static_scene and signature == last_signature:
                s.optimizer_status = f'Frame {frame} saltato (camera/scena invariata)'
                s.optimizer_progress = (fi + 1) / nframes * 0.85
                yield
                continue
            last_signature = signature
            analyzed_frames += 1
            projections = []
            for ci, camera in enumerate(cameras):
                if not camera or camera.type != 'CAMERA':
                    raise RuntimeError(f'Frame {frame}: camera non valida')
                cam = camera.evaluated_get(dg)
                if cam.data.type not in {'PERSP', 'ORTHO'}:
                    raise RuntimeError(f'Frame {frame}: {camera.name}, serve una camera prospettica o ortografica')
                # A normalized camera transform ignores object scale, as Blender cameras do.
                projection = cam.calc_matrix_camera(
                    dg, x=scene.render.resolution_x, y=scene.render.resolution_y,
                    scale_x=scene.render.pixel_aspect_x, scale_y=scene.render.pixel_aspect_y)
                projections.append((cam, projection @ cam.matrix_world.normalized().inverted()))
                if ci % 16 == 0:
                    yield
            for oi, instance in enumerate(dg.object_instances):
                evaluated = instance.object
                original = evaluated.original
                if instance.is_instance:
                    # Sources may occur at transforms unrelated to their own object location.
                    # Keep emitters and sources; do not store temporary evaluated instances.
                    if original in candidate_set:
                        visible.add(original)
                    parent = instance.parent
                    if parent and parent.original in candidate_set:
                        visible.add(parent.original)
                elif original in candidate_set:
                    observed.add(original)
                    if original not in visible:
                        bounds = evaluated.bound_box
                        if not bounds or all(tuple(c) == (-1.0, -1.0, -1.0) for c in bounds):
                            visible.add(original)
                        else:
                            camera_visible = False
                            for cam, vp in projections:
                                if not _bounds_in_camera(scene, cam, evaluated,
                                                          instance.matrix_world, margin):
                                    continue
                                if s.optimizer_occlusion and _fully_occluded(
                                        scene, dg, cam, evaluated, instance.matrix_world):
                                    continue
                                camera_visible = True
                                break
                            if camera_visible:
                                visible.add(original)
                # Never suspend while retaining a DepsgraphObjectInstance reference.
                del instance, evaluated
                if oi % 32 == 0:
                    s.optimizer_progress = (fi + 0.5) / nframes * 0.85
                    yield
            s.optimizer_progress = (fi + 1) / nframes * 0.85
            yield
        # Never switch off objects missing from the viewport dependency graph.
        # Also keep sources in all excluded or hidden collections.
        hidden = [obj for obj in candidates if obj in observed and obj not in visible]
        unused_materials = 0
        for mi, material in enumerate(bpy.data.materials):
            if material.users == 0:
                unused_materials += 1
            if mi % 64 == 0:
                s.optimizer_status = f'Controllo materiali: {mi + 1}'
                yield
        # Candidate polygon counts use base mesh data: no expensive mesh conversion.
        polygons = sum(len(obj.data.polygons) for obj in hidden)
        # Analysis only prepares a review list. Rendering is changed by a separate
        # button after the user has inspected/selected the candidates.
        _store_candidates(scene, hidden)
        s.optimizer_report = (
            f'Mesh esaminate: {all_meshes}\n'
            f'Mesh candidate da escludere: {len(hidden)}\n'
            f'Poligoni base candidate: {polygons:,}\n'
            f'Mesh protette: {len(visible & protected)}\n'
            f'Materiali senza utenti: {unused_materials} (nessuna modifica)\n'
            f'Fotogrammi: {analyzed_frames}/{nframes} analizzati · camera + oggetti valutati\n'
            f'Camere: {len(self.cameras) if self.cameras is not None else "scena / marker"}\n'
            'Rianalizza dopo modifiche a scena, camera o animazione.')
        self._committing = False
        s.optimizer_progress = 1.0

    def _finish(self, context, cancelled=False, error=None):
        global _optimizer_job
        # A cancelled analysis applies no partial exclusions.
        restore_error = None
        try:
            self.worker.close()
            if cancelled and self._committing:
                _restore_visibility(self.scene)
        except Exception as exc:
            restore_error = str(exc)
        finally:
            try:
                self.scene.frame_set(self.frame, subframe=self.subframe)
                self.scene.camera = self.camera
            except Exception as exc:
                restore_error = restore_error or str(exc)
            finally:
                if self._timer:
                    context.window_manager.event_timer_remove(self._timer)
                    self._timer = None
                _optimizer_job = None
        if cancelled:
            _clear_candidates(self.scene)
        self.s.optimizer_elapsed = _elapsed(time.monotonic() - self.started)
        if error or restore_error:
            self.s.optimizer_status = 'Errore: ' + str(error or restore_error)
            self.report({'ERROR'}, self.s.optimizer_status)
        elif cancelled:
            self.s.optimizer_status = 'Interrotto · nessuna ottimizzazione applicata'
            self.s.optimizer_progress = 0.0
        else:
            self.s.optimizer_status = 'Ottimizzazione completata'
            self.report({'INFO'}, f'Mesh escluse: {len(self.scene.qrp_visibility_backup)}')
        _redraw(context)
        return {'CANCELLED'} if cancelled or error or restore_error else {'FINISHED'}

    def modal(self, context, event):
        if event.type == 'ESC' or self._cancel_requested:
            return self._finish(context, cancelled=True)
        # bpy.types.Event does not expose a timer attribute in Blender 5.2.
        # Handle TIMER events without dereferencing an unsupported event property.
        if event.type != 'TIMER':
            # Consume editing input during the scan to keep evaluation consistent.
            return {'RUNNING_MODAL'}
        if context.scene != self.scene or context.view_layer != self.view_layer:
            return self._finish(context, cancelled=True, error='Scena o View Layer cambiato')
        try:
            # Time budget per event, in addition to yields within the generator.
            deadline = time.monotonic() + 0.035
            while time.monotonic() < deadline:
                next(self.worker)
        except StopIteration:
            return self._finish(context)
        except Exception as exc:
            return self._finish(context, cancelled=True, error=str(exc))
        self.s.optimizer_elapsed = _elapsed(time.monotonic() - self.started)
        _redraw(context)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if _optimizer_job is self:
            self._finish(context, cancelled=True)


class QRP_OT_restore_visibility(Operator):
    bl_idname = 'render.qrp_restore_visibility'
    bl_label = 'Ripristina mesh'
    bl_description = 'Ripristina la visibilità render originale; funziona anche dopo salvataggio e riapertura'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _optimizer_job is None and bool(context.scene.qrp_visibility_backup)

    def execute(self, context):
        try:
            count = _restore_visibility(context.scene)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        context.scene.qrp_settings.optimizer_status = f'Ripristinate {count} mesh'
        context.scene.qrp_settings.optimizer_report = ''
        self.report({'INFO'}, f'Ripristinate {count} mesh')
        return {'FINISHED'}


class QRP_OT_select_candidates(Operator):
    bl_idname = 'render.qrp_select_candidates'
    bl_label = 'Seleziona candidate'
    bl_description = 'Seleziona nella viewport le mesh risultate fuori da tutte le camere analizzate'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _optimizer_job is None and bool(_candidate_objects(context.scene))

    def execute(self, context):
        objects = _candidate_objects(context.scene)
        # The operator performs one context-level deselect instead of walking
        # every scene object.  This matters on imported scenes containing
        # thousands of meshes: select_set() on all of them causes a redraw and
        # dependency-graph update for each object.
        try:
            bpy.ops.object.select_all(action='DESELECT')
        except (RuntimeError, AttributeError):
            # Keep the direct fallback for unusual/non-3D-view contexts.
            for obj in context.selected_objects:
                try:
                    obj.select_set(False)
                except RuntimeError:
                    pass
        selected = 0
        for obj in objects:
            try:
                if obj.hide_get():
                    obj.hide_set(False)
                obj.select_set(True)
                selected += 1
            except RuntimeError:
                continue
        if selected:
            context.view_layer.objects.active = objects[0]
        context.scene.qrp_settings.optimizer_status = f'Selezionate {selected} mesh candidate'
        self.report({'INFO'}, f'Selezionate {selected} mesh candidate')
        return {'FINISHED'}


class QRP_OT_hide_candidates(Operator):
    bl_idname = 'render.qrp_hide_candidates'
    bl_label = 'Spegni candidate nel render'
    bl_description = 'Disattiva nel render le mesh candidate, dopo averle controllate'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _optimizer_job is None and bool(_candidate_objects(context.scene))

    def execute(self, context):
        scene = context.scene
        objects = _candidate_objects(scene)
        count = 0
        for obj in objects:
            if obj is None or obj.hide_render or obj.is_property_readonly('hide_render'):
                continue
            entry = scene.qrp_visibility_backup.add()
            entry.obj = obj
            entry.hidden = obj.hide_render
            obj.hide_render = True
            count += 1
        # Apply one dependency-graph refresh after the batch, rather than
        # explicitly forcing a refresh for every hide_render assignment.
        try:
            context.view_layer.update()
        except (RuntimeError, AttributeError):
            pass
        scene.qrp_settings.optimizer_status = f'Spente {count} mesh candidate nel render'
        self.report({'INFO'}, f'Spente {count} mesh candidate nel render')
        return {'FINISHED'}


class QRP_OT_clear_candidates(Operator):
    bl_idname = 'render.qrp_clear_candidates'
    bl_label = 'Svuota candidate'
    bl_description = 'Rimuove la lista di candidate senza spegnerle'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _optimizer_job is None and bool(_candidate_objects(context.scene))

    def execute(self, context):
        _clear_candidates(context.scene)
        context.scene.qrp_settings.optimizer_status = 'Lista candidate svuotata'
        return {'FINISHED'}


def draw_optimizer(layout, context):
    s = context.scene.qrp_settings
    box = layout.column(align=True)
    controls = box.column(align=True)
    controls.enabled = _optimizer_job is None
    controls.prop(s, 'optimizer_camera_mode', text='Camere')
    if s.optimizer_camera_mode == 'SINGLE':
        controls.prop(s, 'optimizer_camera', text='Camera')
    elif s.optimizer_camera_mode == 'MULTI':
        controls.template_list('QRP_UL_cameras', '', s, 'optimizer_cameras',
                               s, 'optimizer_camera_index', rows=3, maxrows=5)
        controls.operator('render.qrp_refresh_cameras', icon='FILE_REFRESH')
    try:
        _selected_cameras(context.scene)
    except ValueError as exc:
        controls.label(text=str(exc), icon='INFO')
    controls.prop(s, 'optimizer_animation')
    controls.prop(s, 'optimizer_margin', slider=True)
    controls.prop(s, 'optimizer_occlusion')
    controls.operator('render.qrp_optimize_camera', icon='VIEW_CAMERA')
    if s.optimizer_status == 'Ottimizzazione completata' or context.scene.qrp_candidates:
        review = box.column(align=True)
        review.scale_y = 0.9
        review.label(text=f'Candidate trovate: {len(context.scene.qrp_candidates)}', icon='RESTRICT_RENDER_OFF')
        row = review.row(align=True)
        row.operator('render.qrp_select_candidates', icon='RESTRICT_SELECT_OFF')
        row.operator('render.qrp_hide_candidates', icon='RESTRICT_RENDER_ON')
        review.operator('render.qrp_clear_candidates', icon='X')
    box.operator('render.qrp_restore_visibility', icon='LOOP_BACK')
    if _optimizer_job:
        box.label(text='Calcolo in corso · Esc interrompe', icon='TIME')
        box.prop(s, 'optimizer_progress', slider=True, text='Avanzamento')
    if s.optimizer_status:
        status = box.column(align=True)
        status.scale_y = 0.85
        status.label(text=s.optimizer_status)
        status.label(text=f'Tempo trascorso: {s.optimizer_elapsed}')
    if s.optimizer_report:
        report = box.column(align=True)
        report.scale_y = 0.85
        for line in s.optimizer_report.splitlines():
            report.label(text=line)
    notes = box.column(align=True)
    notes.scale_y = 0.8
    notes.label(text='Solo fuori campo; non rileva le occlusioni.')
    notes.label(text='Può cambiare ombre, riflessi e luce indiretta.', icon='INFO')
    notes.label(text='I materiali inutilizzati non vengono renderizzati.')



class QRP_Settings(PropertyGroup):
    optimizer_camera_mode: EnumProperty(
        name='Camere', items=[
            ('SCENE', 'Camera scena / marker', 'Segue la camera attiva e i cambi camera nei marker'),
            ('SINGLE', 'Una camera', 'Analizza solo la camera scelta, anche se non è quella attiva'),
            ('MULTI', 'Più camere', 'Mantiene le mesh visibili da almeno una delle camere spuntate'),
        ], default='SCENE', update=_camera_mode_update,
    )
    optimizer_camera: PointerProperty(name='Camera', type=bpy.types.Object, poll=_camera_poll)
    optimizer_cameras: CollectionProperty(type=QRP_CameraChoice)
    optimizer_camera_index: IntProperty(default=0, min=0)
    ui_camera_open: BoolProperty(
        name="Analisi camera", default=False, options={'SKIP_SAVE'},
        description="Mostra o nasconde i controlli di analisi e ottimizzazione della camera",
    )
    ui_presets_open: BoolProperty(
        name="Preset", default=True, options={'SKIP_SAVE'},
        description="Mostra o nasconde i preset e le impostazioni di render",
    )
    optimizer_animation: BoolProperty(
        name="Intera animazione", default=True,
        description="Analizza ogni fotogramma tra Inizio e Fine, anche i movimenti degli oggetti e i cambi camera. Disattiva per il solo frame corrente",
    )
    optimizer_margin: FloatProperty(
        name="Margine camera", default=0.10, min=0.0, max=0.5,
        subtype='FACTOR', description="Margine aggiuntivo su ogni lato dell'inquadratura; 10% riduce esclusioni al bordo",
    )
    optimizer_occlusion: BoolProperty(
        name='Controlla occlusioni', default=True,
        description='Propone mesh completamente coperte da altre superfici usando raggi dalla camera; può aumentare il tempo di analisi',
    )
    optimizer_status: StringProperty(name="Stato", default="")
    optimizer_report: StringProperty(name="Risultato", default="")
    optimizer_elapsed: StringProperty(name="Tempo", default="00:00")
    optimizer_progress: FloatProperty(name="Avanzamento", min=0, max=1, subtype='FACTOR', options={'SKIP_SAVE'})

    engine: EnumProperty(
        name="Motore",
        items=[
            ("CYCLES", "Cycles", "Rendering path-traced (qualità, più lento)"),
            ("EEVEE", "EEVEE", "Rendering real-time (veloce)"),
        ],
        default="CYCLES",
        update=_live_update,
    )
    scene_type: EnumProperty(
        name="Tipo di scena",
        items=[
            ("BASE", "Super ottimizzato", "Cycles: impostazioni originali dei tuoi screenshot. EEVEE: base del motore"),
            ("INTERIOR", "Interno", "Scena d'interni"),
            ("EXTERIOR", "Esterno", "Scena d'esterni"),
            ("DETAIL", "Dettaglio", "Inquadratura di dettaglio / close-up"),
            ("ANIMATION", "Impianti", "Carrellate e scene pesanti (macchinari enormi, molte mesh e bones)"),
        ],
        default="INTERIOR",
        update=_live_update,
    )
    has_transparency: BoolProperty(
        name="Ci sono trasparenze",
        description="Vetri, materiali con alpha, ecc.: in Cycles aumenta i rimbalzi di trasparenza/trasmissione, "
                    "in EEVEE attiva il ray tracing per la rifrazione",
        default=False,
        update=_live_update,
    )
    transparent_bg: BoolProperty(
        name="Sfondo trasparente (PNG)",
        description="Attiva Film > Transparent per esportare con canale alpha",
        default=False,
        update=_live_update,
    )
    quality: FloatProperty(
        name="Qualità",
        description="Moltiplicatore dei samples (1.0 = preset). Sopra 1 più pulito e più lento, sotto 1 più veloce",
        default=1.0, min=0.25, max=3.0, step=5, precision=2,
        update=_live_update,
    )
    bounce_offset: IntProperty(
        name="Rimbalzi",
        description="Rimbalzi extra (+) o in meno (-) rispetto al preset. "
                    "Cycles: totale/diffuse/glossy/transmission/transparent. EEVEE: rimbalzi diffusi della GI",
        default=0, min=-3, max=6,
        update=_live_update,
    )
    live_update: BoolProperty(
        name="Aggiorna in tempo reale",
        description="Riapplica il preset ogni volta che cambi un'opzione o uno slider "
                    "(attenzione: sovrascrive eventuali modifiche manuali ai parametri gestiti dall'addon). "
                    "Per sicurezza non viene salvato nel file e torna disattivato alla riapertura",
        default=False,
        options={'SKIP_SAVE'},
        update=_live_update,
    )


class QRP_OT_apply(Operator):
    bl_idname = "render.qrp_apply_preset"
    bl_label = "Applica preset"
    bl_description = "Applica il preset di render alla scena corrente"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.qrp_settings
        _run(s, context.scene)
        self.report({"INFO"}, f"{s.engine} - preset '{s.scene_type}' applicato"
                    + (" (con trasparenze)" if s.has_transparency else ""))
        return {"FINISHED"}


class QRP_OT_reset(Operator):
    bl_idname = "render.qrp_reset_preset"
    bl_label = "Reset"
    bl_description = ("Ripristina le impostazioni della scena com'erano prima del primo preset applicato "
                      "e riporta flag e slider ai valori di default")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return BACKUP_KEY in context.scene

    def execute(self, context):
        global _suppress_live
        scene = context.scene
        s = scene.qrp_settings

        restore_backup(scene)

        # Riporta flag e slider ai default senza riapplicare il preset
        _suppress_live = True
        try:
            s.has_transparency = False
            s.transparent_bg = False
            s.quality = 1.0
            s.bounce_offset = 0
        finally:
            _suppress_live = False

        self.report({"INFO"}, "Impostazioni originali ripristinate")
        return {"FINISHED"}


def draw_ui(layout, context):
    s = context.scene.qrp_settings
    scene = context.scene
    camera_box = layout.box()
    camera_box.row(align=True).prop(
        s, 'ui_camera_open', text='Analisi camera', emboss=False,
        icon='TRIA_DOWN' if s.ui_camera_open else 'TRIA_RIGHT')
    if s.ui_camera_open:
        draw_optimizer(camera_box, context)
    elif _optimizer_job:
        # Keep elapsed time and Esc discoverable even when the section is closed.
        camera_box.label(text=f'Calcolo: {s.optimizer_elapsed} · Esc interrompe', icon='TIME')

    preset_box = layout.box()
    preset_box.row(align=True).prop(
        s, 'ui_presets_open', text='Preset', emboss=False,
        icon='TRIA_DOWN' if s.ui_presets_open else 'TRIA_RIGHT')
    if not s.ui_presets_open:
        return
    layout = preset_box.column()
    layout.enabled = _optimizer_job is None

    col = layout.column(align=True)
    col.prop(s, "engine", expand=True)
    col.separator()
    col.prop(s, "scene_type", expand=True)

    layout.separator()
    col = layout.column(align=True)
    col.prop(s, "has_transparency")
    col.prop(s, "transparent_bg")

    layout.separator()
    col = layout.column(align=True)
    col.prop(s, "quality", slider=True)
    col.prop(s, "bounce_offset", slider=True)

    layout.separator()
    layout.prop(s, "live_update")
    row = layout.row(align=True)
    row.operator("render.qrp_apply_preset", icon="CHECKMARK")
    row.operator("render.qrp_reset_preset", icon="LOOP_BACK")

    # Riepilogo dei valori attualmente impostati
    box = layout.box()
    col = box.column(align=True)
    col.scale_y = 0.85
    if s.engine == "EEVEE":
        ee = scene.eevee
        col.label(text=f"Samples render: {getattr(ee, 'taa_render_samples', '-')}")
        col.label(text=f"Ray tracing: {'sì' if getattr(ee, 'use_raytracing', False) else 'no'}")
        col.label(text=f"Rimbalzi diffusi GI: {getattr(ee, 'gi_diffuse_bounces', '-')}")
    else:
        cy = scene.cycles
        col.label(text=f"Samples: {cy.samples}   Soglia: {cy.adaptive_threshold:.3f}")
        col.label(text=f"Rimbalzi tot/diff/gloss: {cy.max_bounces}/{cy.diffuse_bounces}/{cy.glossy_bounces}")
        col.label(text=f"Transm/Transp: {cy.transmission_bounces}/{cy.transparent_max_bounces}")


class QRP_PT_render_panel(Panel):
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Quick Render Presets"
    bl_idname = "QRP_PT_render_panel"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"

    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_quick_render")


    def draw(self, context):
        draw_ui(self.layout, context)


class QRP_PT_sidebar_panel(Panel):
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Quick Render Presets"
    bl_idname = "QRP_PT_sidebar_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Fabularis Tools"
    bl_parent_id = "FABULARIS_SECTION_RENDER"

    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_quick_render")


    def draw(self, context):
        draw_ui(self.layout, context)


classes = (QRP_VisibilityBackup, QRP_CameraChoice, QRP_Candidate, QRP_UL_cameras, QRP_OT_refresh_cameras, QRP_OT_optimize, QRP_OT_restore_visibility, QRP_OT_select_candidates, QRP_OT_hide_candidates, QRP_OT_clear_candidates, QRP_Settings, QRP_OT_apply, QRP_OT_reset, QRP_PT_render_panel, QRP_PT_sidebar_panel)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.qrp_settings = PointerProperty(type=QRP_Settings)
    bpy.types.Scene.qrp_visibility_backup = CollectionProperty(type=QRP_VisibilityBackup)
    bpy.types.Scene.qrp_candidates = CollectionProperty(type=QRP_Candidate)


def unregister():
    if _optimizer_job is not None:
        _optimizer_job.cancel(bpy.context)
    # Never strand hidden meshes when the addon is disabled.
    for scene in bpy.data.scenes:
        _restore_visibility(scene)
        _clear_candidates(scene)
    del bpy.types.Scene.qrp_visibility_backup
    del bpy.types.Scene.qrp_candidates
    del bpy.types.Scene.qrp_settings
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
