import bpy
from bpy.types import AddonPreferences
from bpy.props import BoolProperty


def is_section_enabled(context, key):
    addon = context.preferences.addons.get(__package__)
    if addon is None:
        return True
    return bool(getattr(addon.preferences, key, True))


class FABULARIS_Preferences(AddonPreferences):
    bl_idname = __package__

    show_materials: BoolProperty(name="Materiali", default=True)
    show_material_gallery: BoolProperty(name="Material Gallery", default=True)
    show_material_remap: BoolProperty(name="Material Remap", default=True)
    show_batch_remap: BoolProperty(name="Batch Remap automatico", default=True)
    show_material_add: BoolProperty(name="Material Add", default=True)

    show_collections: BoolProperty(name="Collection e gerarchie", default=True)
    show_collection_to_empty: BoolProperty(name="Collection to Empty", default=True)
    show_empty_to_collection: BoolProperty(name="Empty to Collection", default=True)
    show_collection_finder: BoolProperty(name="Trova Collection Originale", default=True)
    show_quick_group: BoolProperty(name="Quick Group", default=True)

    show_optimization: BoolProperty(name="Ottimizzazione", default=False)
    show_hole_closer: BoolProperty(name="Chiudi fori", default=True)
    show_remesher: BoolProperty(name="Remesher", default=True)

    show_render: BoolProperty(name="Render", default=True)
    show_quick_render: BoolProperty(name="Quick Render", default=True)

    show_uv: BoolProperty(name="UV", default=False)
    show_missing_uv: BoolProperty(name="Crea UV mancanti", default=True)
    show_uv_packer: BoolProperty(name="UV Packer", default=True)

    show_multi_array: BoolProperty(name="Multi Array Cloner", default=True)

    show_other: BoolProperty(name="Altro", default=False)
    show_clone_manager: BoolProperty(name="Project Clone", default=True)
    show_scatter_brush: BoolProperty(name="Scatter Brush", default=True)

    def draw_group(self, layout, title, parent, children):
        box = layout.box()
        box.prop(self, parent, text=title)
        col = box.column(align=True)
        col.enabled = getattr(self, parent)
        for prop, label in children:
            col.prop(self, prop, text=label)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Mostra o nascondi gruppi e singoli pannelli in Fabularis Tools:")
        self.draw_group(layout, "Materiali", "show_materials", [
            ("show_material_gallery", "Material Gallery"),
            ("show_material_remap", "Material Remap"),
            ("show_batch_remap", "Batch Remap automatico"),
            ("show_material_add", "Material Add"),
        ])
        self.draw_group(layout, "Collection e gerarchie", "show_collections", [
            ("show_collection_to_empty", "Collection to Empty"),
            ("show_empty_to_collection", "Empty to Collection"),
            ("show_collection_finder", "Trova Collection Originale"),
            ("show_quick_group", "Quick Group"),
        ])
        self.draw_group(layout, "Ottimizzazione", "show_optimization", [
            ("show_hole_closer", "Chiudi fori"), ("show_remesher", "Remesher"),
        ])
        self.draw_group(layout, "Render", "show_render", [("show_quick_render", "Quick Render")])
        self.draw_group(layout, "UV", "show_uv", [
            ("show_missing_uv", "Crea UV mancanti"), ("show_uv_packer", "UV Packer"),
        ])
        self.draw_group(layout, "Altro", "show_other", [
            ("show_clone_manager", "Project Clone"), ("show_scatter_brush", "Scatter Brush"),
            ("show_multi_array", "Multi Array Cloner"),
        ])


def register():
    bpy.utils.register_class(FABULARIS_Preferences)

def unregister():
    bpy.utils.unregister_class(FABULARIS_Preferences)
