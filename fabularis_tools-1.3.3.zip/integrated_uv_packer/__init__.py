bl_info = {
    "name": "Fabularis UV Packer Lab",
    "author": "Fabularis Lab",
    "version": (2, 0, 0),
    "blender": (4, 3, 0),
    "location": "UV Editor / View3D > N > Fabularis UV",
    "description": "UV group schemes, target boxes, packing modes and island utilities",
    "category": "UV",
}
import bpy
import bmesh
import math
import colorsys
from mathutils import Vector
from bpy.types import Operator, Panel, PropertyGroup, UIList
from bpy.props import (BoolProperty, IntProperty, FloatProperty, FloatVectorProperty,
                       StringProperty, EnumProperty, CollectionProperty, PointerProperty)

PREFIX = "fabuv_v2_"
REGISTERED = []

def objects(context):
    if context.mode == 'EDIT_MESH':
        return list(context.objects_in_mode_unique_data)
    return list(dict.fromkeys(o for o in context.selected_objects if o.type == 'MESH'))

def uv_islands(bm, uv):
    remaining = set(bm.faces)
    groups = []
    while remaining:
        seed = remaining.pop()
        group, pending = [seed], [seed]
        while pending:
            face = pending.pop()
            for loop in face.loops:
                radial = loop.link_loop_radial_next
                if not loop.edge.is_manifold or radial.face not in remaining:
                    continue
                a, b = loop, loop.link_loop_next
                ra = radial if radial.vert == a.vert else radial.link_loop_next
                rb = radial if radial.vert == b.vert else radial.link_loop_next
                if ((a[uv].uv-ra[uv].uv).length_squared < 1e-12 and
                        (b[uv].uv-rb[uv].uv).length_squared < 1e-12):
                    remaining.remove(radial.face)
                    group.append(radial.face)
                    pending.append(radial.face)
        groups.append(group)
    return groups

def layer_name(scheme):
    return "fabuv_g_" + str(scheme.uid)

def get_layer(bm, scheme, create=False):
    name = layer_name(scheme)
    layer = bm.faces.layers.int.get(name)
    if layer is None and create:
        layer = bm.faces.layers.int.new(name)
    return layer

def scheme_of(s):
    if not s.schemes: return None
    return s.schemes[min(s.scheme_index, len(s.schemes)-1)]

def group_of(sc):
    if sc is None or not sc.groups: return None
    return sc.groups[min(sc.group_index, len(sc.groups)-1)]

def color_for(index):
    return (*colorsys.hsv_to_rgb((index*.6180339887) % 1.0, .78, 1.0), 1.0)

def read_bm(obj, edit):
    if edit:
        return bmesh.from_edit_mesh(obj.data)
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    return bm

def finish_bm(obj, bm, edit):
    if edit:
        bmesh.update_edit_mesh(obj.data)
    else:
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()

def box_valid(lo, hi):
    return hi[0] > lo[0] and hi[1] > lo[1]

def tile_origin(tile):
    i = tile-1001
    return (float(i%10), float(i//10))

def target_boxes(group, s, group_index, group_count):
    if s.mode == 'TOGETHER':
        return [((0.,0.),(1.,1.))]
    if s.layout == 'MANUAL' and group.boxes:
        return [(tuple(b.minimum), tuple(b.maximum)) for b in group.boxes]
    count = max(1, group.tile_count)
    if s.layout == 'HORIZONTAL':
        return [((float(i),float(group_index)),(float(i+1),float(group_index+1))) for i in range(count)]
    if s.layout == 'VERTICAL':
        return [((float(group_index),float(i)),(float(group_index+1),float(i+1))) for i in range(count)]
    if s.layout == 'GRID':
        return [((float(i%s.tiles_in_row),float(group_index+(i//s.tiles_in_row)*group_count)),
                 (float(i%s.tiles_in_row+1),float(group_index+(i//s.tiles_in_row)*group_count+1))) for i in range(count)]
    origin = tile_origin(group.tile)
    return [((origin[0]+i, origin[1]),(origin[0]+i+1, origin[1]+1)) for i in range(count)]

class FABUV_Box(PropertyGroup):
    name: StringProperty(name="Nome", default="Box")
    minimum: FloatVectorProperty(name="P1", size=2, default=(0,0))
    maximum: FloatVectorProperty(name="P2", size=2, default=(1,1))

class FABUV_Group(PropertyGroup):
    name: StringProperty(name="Nome", default="Group")
    uid: IntProperty(default=0)
    color: FloatVectorProperty(name="Colore", subtype='COLOR', size=4, min=0, max=1, default=(1,1,0,1))
    enabled: BoolProperty(name="Attivo", default=True)
    tile: IntProperty(name="Prima tile", default=1001, min=1001, max=1999)
    tile_count: IntProperty(name="Tile Count", default=1, min=1, max=64)
    density: FloatProperty(name="Densita relativa", default=1, min=.1, max=10)
    boxes: CollectionProperty(type=FABUV_Box)
    box_index: IntProperty(default=0)

class FABUV_Scheme(PropertyGroup):
    name: StringProperty(name="Nome", default="Scheme")
    uid: IntProperty(default=0)
    groups: CollectionProperty(type=FABUV_Group)
    group_index: IntProperty(default=0)

class FABUV_Settings(PropertyGroup):
    schemes: CollectionProperty(type=FABUV_Scheme)
    scheme_index: IntProperty(default=0)
    next_uid: IntProperty(default=1)
    mode: EnumProperty(name="Main Mode", items=[
        ('SINGLE','Single Tile','Packing in una tile'),
        ('TILES','Tiles','Packing su piu tile'),
        ('GROUP_TILES','Groups To Tiles','Ogni gruppo in box o tile dedicate'),
        ('TOGETHER','Groups Together','Gruppi vicini nello stesso spazio'),
        ('GROUP_SINGLE','Groups To Single Tile','Sotto-box automatiche in una tile')], default='SINGLE')
    grouping: EnumProperty(name="Grouping Method", items=[
        ('MANUAL','Grouping Scheme (Manual)','Assegnazione manuale'),
        ('MATERIAL','Material','Gruppi per materiale'),
        ('OBJECT','Object','Gruppi per oggetto'),
        ('MESH_PART','Mesh Part','Componenti mesh disconnesse'),
        ('TILE','Tile','Gruppi per tile UV')], default='MANUAL')
    density_policy: EnumProperty(name="Texel Density Policy", items=[
        ('INDEPENDENT','Independent','Ogni gruppo indipendente'),
        ('UNIFORM','Uniform','Scala omogenea, packing nativo senza normalizzazione'),
        ('CUSTOM','Custom','Moltiplicatori per gruppo')], default='INDEPENDENT')
    layout: EnumProperty(name="Group Layout Mode", items=[
        ('AUTOMATIC','Automatic','Tile progressive'),
        ('GRID','Grid','Griglia a righe'),
        ('HORIZONTAL','Horizontal','Tile orizzontali'),
        ('VERTICAL','Vertical','Tile verticali'),
        ('MANUAL','Manual','Box personalizzate')], default='AUTOMATIC')
    tiles_in_row: IntProperty(name="Tiles In Row", default=10, min=1, max=50)
    tex_w: IntProperty(name="Texture Width", default=2048, min=16)
    tex_h: IntProperty(name="Texture Height", default=2048, min=16)
    margin: IntProperty(name="Pixel Margin", default=8, min=0, max=512)
    rotate: BoolProperty(name="Allow Rotation", default=True)
    scale: BoolProperty(name="Normalize Scale", default=True)
    shape: EnumProperty(name="Island Shape", items=[
        ('CONCAVE','Concave',''),('CONVEX','Convex',''),('AABB','Bounding Box','')], default='CONCAVE')
    selected_only: BoolProperty(name="Selected Islands Only", default=False)
    snap_pixels: BoolProperty(name="Pixel Alignment", default=False)
    target_tile: IntProperty(name="Start UDIM", default=1001, min=1001, max=1999)
    tile_count: IntProperty(name="Tile Count", default=4, min=1, max=64)
    custom_box: BoolProperty(name="Custom Target Box", default=False)
    box_min: FloatVectorProperty(name="P1", size=2, default=(0,0))
    box_max: FloatVectorProperty(name="P2", size=2, default=(1,1))
    stack_tolerance: FloatProperty(name="Stack Tolerance", default=.0001, min=.000001, max=.1, precision=6)
    angle: FloatProperty(name="Rotation", default=math.pi/2, subtype='ANGLE')
    priority: FloatProperty(name="Island Scale", default=1.2, min=.1, max=10)
    lock_overlapping: BoolProperty(name="Preserve Overlaps (native)", default=False)

class FABUV_UL_groups(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, 'color', text='')
        row.prop(item, 'name', text='', emboss=False)
        row.prop(item, 'enabled', text='')

class FABUV_UL_schemes(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item,'name',text='',emboss=False,icon='GROUP_UVS')

class FABUV_UL_boxes(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item,'name',text='',emboss=False,icon='MESH_PLANE')

class FABUV_OT_manage(Operator):
    bl_idname = "fabuv2.manage"
    bl_label = "Manage UV Schemes"
    bl_options = {'REGISTER','UNDO'}
    action: EnumProperty(items=[(x,x,'') for x in (
        'ADD_SCHEME','REMOVE_SCHEME','ADD_GROUP','REMOVE_GROUP','UP_GROUP','DOWN_GROUP',
        'ADD_BOX','REMOVE_BOX','ASSIGN','CLEAR','SELECT','DESELECT')])
    def execute(self, context):
        s = context.scene.fabuv2
        sc = scheme_of(s)
        if self.action == 'ADD_SCHEME':
            sc = s.schemes.add()
            sc.name = "Scheme " + str(len(s.schemes))
            sc.uid = s.next_uid
            s.next_uid += 1
            s.scheme_index = len(s.schemes)-1
            return {'FINISHED'}
        if not sc:
            self.report({'WARNING'},"Create a scheme first")
            return {'CANCELLED'}
        if self.action == 'REMOVE_SCHEME':
            s.schemes.remove(s.scheme_index)
            s.scheme_index = max(0,min(s.scheme_index,len(s.schemes)-1))
            return {'FINISHED'}
        if self.action == 'ADD_GROUP':
            g = sc.groups.add()
            g.name = "Group " + str(len(sc.groups))
            g.uid = s.next_uid
            s.next_uid += 1
            g.color = color_for(len(sc.groups)-1)
            g.tile = 1000+len(sc.groups)
            sc.group_index = len(sc.groups)-1
            return {'FINISHED'}
        g = group_of(sc)
        if not g:
            self.report({'WARNING'},"Create a group first")
            return {'CANCELLED'}
        if self.action == 'REMOVE_GROUP':
            removed_uid = g.uid
            for obj in objects(context):
                bm = read_bm(obj, context.mode=='EDIT_MESH')
                layer = get_layer(bm,sc)
                if layer:
                    for f in bm.faces:
                        if f[layer] == removed_uid: f[layer] = 0
                finish_bm(obj,bm,context.mode=='EDIT_MESH')
            sc.groups.remove(sc.group_index)
            sc.group_index = max(0,min(sc.group_index,len(sc.groups)-1))
            return {'FINISHED'}
        if self.action in {'UP_GROUP','DOWN_GROUP'}:
            idx = sc.group_index
            new = idx + (-1 if self.action == 'UP_GROUP' else 1)
            if 0 <= new < len(sc.groups):
                sc.groups.move(idx,new)
                sc.group_index = new
            return {'FINISHED'}
        if self.action == 'ADD_BOX':
            b = g.boxes.add()
            b.name = f"Box {len(g.boxes)-1}"
            g.box_index = len(g.boxes)-1
            return {'FINISHED'}
        if self.action == 'REMOVE_BOX':
            if g.boxes:
                g.boxes.remove(g.box_index)
                g.box_index = max(0,min(g.box_index,len(g.boxes)-1))
            return {'FINISHED'}
        if context.mode != 'EDIT_MESH':
            self.report({'WARNING'},"Enter Edit Mode, select UV islands")
            return {'CANCELLED'}
        count = 0
        for obj in objects(context):
            bm = read_bm(obj,True)
            uv = bm.loops.layers.uv.active
            if uv is None: continue
            layer = get_layer(bm,sc,self.action=='ASSIGN')
            if layer is None: continue
            for island in uv_islands(bm,uv):
                if self.action in {'ASSIGN','CLEAR'}:
                    if any(f.select for f in island):
                        for f in island: f[layer] = g.uid if self.action=='ASSIGN' else 0
                        count += 1
                elif any(f[layer]==g.uid for f in island):
                    for f in island: f.select_set(self.action=='SELECT')
                    count += 1
            finish_bm(obj,bm,True)
        self.report({'INFO'},f"Islands: {count}")
        return {'FINISHED'}

def island_group(obj, island, uv, sc, s, layer, lookup, component_index):
    if s.grouping == 'MANUAL':
        uid = island[0][layer] if layer else 0
        return next((i for i,g in enumerate(sc.groups) if g.uid==uid),None)
    if s.grouping == 'OBJECT':
        key = ('OBJECT',obj.name)
    elif s.grouping == 'MATERIAL':
        idx = island[0].material_index
        mat = obj.material_slots[idx].material if idx < len(obj.material_slots) else None
        key = ('MATERIAL',mat.name if mat else 'No Material')
    elif s.grouping == 'TILE':
        uv0 = island[0].loops[0][uv].uv
        key = ('TILE',int(math.floor(uv0.x)),int(math.floor(uv0.y)))
    else:
        key = ('PART',obj.name,component_index)
    if key not in lookup:
        lookup[key] = len(lookup)
    return lookup[key]

def uv_pack_op(context,s):
    area = context.area
    if area is None:
        raise RuntimeError("Open in UV Editor or 3D View")
    old_type, old_ui = area.type, area.ui_type
    try:
        if area.type != 'IMAGE_EDITOR':
            area.type='IMAGE_EDITOR'
            area.ui_type='UV'
        kwargs = dict(rotate=s.rotate, scale=s.scale,
                      margin_method='FRACTION',
                      margin=s.margin/max(s.tex_w,s.tex_h),
                      shape_method=s.shape)
        bpy.ops.uv.pack_islands(**kwargs)
    finally:
        if area.type != old_type:
            area.type=old_type
            area.ui_type=old_ui

def transform_group(obj,sc, group_uid, src_min, src_max, dst_min, dst_max, snap=False, s=None):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    uv = bm.loops.layers.uv.active
    layer = get_layer(bm,sc)
    if uv and layer:
        for f in bm.faces:
            if f[layer] != group_uid: continue
            for loop in f.loops:
                v=loop[uv].uv.copy()
                x=dst_min[0]+(v.x-src_min[0])/(src_max[0]-src_min[0])*(dst_max[0]-dst_min[0])
                y=dst_min[1]+(v.y-src_min[1])/(src_max[1]-src_min[1])*(dst_max[1]-dst_min[1])
                if snap:
                    x=round(x*s.tex_w)/s.tex_w
                    y=round(y*s.tex_h)/s.tex_h
                loop[uv].uv=(x,y)
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()

def packed_bounds(objs,sc,uid):
    xs,ys=[],[]
    for obj in objs:
        bm=bmesh.new(); bm.from_mesh(obj.data)
        uv=bm.loops.layers.uv.active
        layer=get_layer(bm,sc)
        if uv and layer:
            for f in bm.faces:
                if f[layer]==uid:
                    for l in f.loops:
                        xs.append(l[uv].uv.x);ys.append(l[uv].uv.y)
        bm.free()
    if not xs: return None
    return ((min(xs),min(ys)),(max(xs),max(ys)))

class FABUV_OT_pack(Operator):
    bl_idname="fabuv2.pack"
    bl_label="Pack UV"
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        s=context.scene.fabuv2
        objs=objects(context)
        if context.mode != 'OBJECT' or not objs:
            self.report({'WARNING'},"Select meshes in Object Mode")
            return {'CANCELLED'}
        if not context.area:
            return {'CANCELLED'}
        sc=scheme_of(s)
        if s.mode in {'GROUP_TILES','TOGETHER','GROUP_SINGLE'} and s.grouping=='MANUAL' and (not sc or not sc.groups):
            self.report({'WARNING'},"Create scheme/groups and assign islands")
            return {'CANCELLED'}
        old_sel=list(context.selected_objects)
        old_active=context.view_layer.objects.active
        old_sync=context.scene.tool_settings.use_uv_select_sync
        processed=0
        try:
            for obj in objs:
                if not obj.data.uv_layers: obj.data.uv_layers.new(name="UVMap")
            if s.mode=='SINGLE':
                groups=[(None,objs)]
            else:
                groups=[]
                if sc is None:
                    sc=s.schemes.add()
                    sc.name="Automatic"
                    sc.uid=s.next_uid
                    s.next_uid+=1
                lookup={}
                membership={}
                for obj in objs:
                    bm=bmesh.new();bm.from_mesh(obj.data)
                    uv=bm.loops.layers.uv.active
                    layer=get_layer(bm,sc,True)
                    islands=uv_islands(bm,uv)
                    for i,island in enumerate(islands):
                        idx=island_group(obj,island,uv,sc,s,layer,lookup,i)
                        if idx is None: continue
                        while idx>=len(sc.groups):
                            g=sc.groups.add()
                            g.name=str(list(lookup.keys())[idx][1:])
                            g.uid=s.next_uid
                            s.next_uid+=1
                            g.color=color_for(idx)
                            g.tile=1001+idx
                        uid=sc.groups[idx].uid
                        for f in island:
                            f[layer]=uid
                        membership.setdefault(uid,set()).add(obj)
                    bm.to_mesh(obj.data);bm.free();obj.data.update()
                groups=[(g, list(membership.get(g.uid,[]))) for g in sc.groups if g.enabled and membership.get(g.uid)]
            for gi,(group,eligible) in enumerate(groups):
                if not eligible:continue
                bpy.ops.object.select_all(action='DESELECT')
                for obj in eligible:obj.select_set(True)
                context.view_layer.objects.active=eligible[0]
                bpy.ops.object.mode_set(mode='EDIT')
                try:
                    bpy.ops.mesh.select_all(action='DESELECT')
                    for obj in eligible:
                        bm=bmesh.from_edit_mesh(obj.data)
                        layer=get_layer(bm,sc) if group else None
                        for f in bm.faces:
                            f.select_set(bool(group is None or (layer and f[layer]==group.uid)))
                        bmesh.update_edit_mesh(obj.data)
                    context.scene.tool_settings.use_uv_select_sync=True
                    uv_pack_op(context,s)
                finally:
                    bpy.ops.object.mode_set(mode='OBJECT')
                if group:
                    source=packed_bounds(eligible,sc,group.uid)
                    if not source:continue
                    if source[1][0]-source[0][0] < 1e-10 or source[1][1]-source[0][1] < 1e-10:
                        self.report({'WARNING'},'Degenerate UV bounds in '+group.name)
                        continue
                    group_idx=next(i for i,g in enumerate(sc.groups) if g.uid==group.uid)
                    if s.mode=='GROUP_SINGLE':
                        n=len(groups)
                        cols=math.ceil(math.sqrt(n))
                        rows=math.ceil(n/cols)
                        cell=group_idx
                        dest=((cell%cols/cols,cell//cols/rows),((cell%cols+1)/cols,(cell//cols+1)/rows))
                    elif s.mode=='TOGETHER':
                        n=len(groups)
                        dest=((group_idx/n,0),((group_idx+1)/n,1))
                    elif s.mode=='TILES':
                        origin=tile_origin(s.target_tile+processed)
                        dest=(origin,(origin[0]+1,origin[1]+1))
                    else:
                        boxes=target_boxes(group,s,group_idx,len(sc.groups))
                        dest=boxes[0]
                    if not box_valid(*dest):
                        self.report({'WARNING'},f"Invalid target box: {group.name}")
                        continue
                    if s.density_policy=='CUSTOM':
                        center=((dest[0][0]+dest[1][0])/2,(dest[0][1]+dest[1][1])/2)
                        w=(dest[1][0]-dest[0][0])*min(group.density,1)
                        h=(dest[1][1]-dest[0][1])*min(group.density,1)
                        dest=((center[0]-w/2,center[1]-h/2),(center[0]+w/2,center[1]+h/2))
                    for obj in eligible:
                        transform_group(obj,sc,group.uid,*source,*dest,snap=s.snap_pixels,s=s)
                elif s.custom_box:
                    # Single mode: remap all faces through temporary group assignment
                    for obj in eligible:
                        bm=bmesh.new();bm.from_mesh(obj.data)
                        uv=bm.loops.layers.uv.active
                        for f in bm.faces:
                            for l in f.loops:
                                v=l[uv].uv.copy()
                                l[uv].uv=(s.box_min[0]+v.x*(s.box_max[0]-s.box_min[0]),
                                            s.box_min[1]+v.y*(s.box_max[1]-s.box_min[1]))
                        bm.to_mesh(obj.data);bm.free();obj.data.update()
                processed+=1
        except Exception as exc:
            self.report({'ERROR'},"Pack error: "+str(exc))
            return {'CANCELLED'}
        finally:
            if context.mode=='EDIT_MESH':bpy.ops.object.mode_set(mode='OBJECT')
            context.scene.tool_settings.use_uv_select_sync=old_sync
            bpy.ops.object.select_all(action='DESELECT')
            for obj in old_sel:
                if obj.name in bpy.data.objects:obj.select_set(True)
            if old_active and old_active.name in bpy.data.objects:
                context.view_layer.objects.active=old_active
        self.report({'INFO'},f"Packed {processed} sets")
        return {'FINISHED'}

class FABUV_OT_tools(Operator):
    bl_idname="fabuv2.tools"
    bl_label="UV Tool"
    bl_options={'REGISTER','UNDO'}
    action: EnumProperty(items=[(x,x,'') for x in ('CREATE_UV','ROTATE','SCALE','STACK','SNAP')])
    def execute(self,context):
        s=context.scene.fabuv2
        if self.action=='CREATE_UV' and context.mode!='OBJECT':
            self.report({'WARNING'},"Use Object Mode")
            return {'CANCELLED'}
        count=0
        stack_cache={}
        for obj in objects(context):
            if not obj.data.uv_layers:
                if self.action=='CREATE_UV':
                    obj.data.uv_layers.new(name="UVMap")
                    count+=1
                continue
            if self.action=='CREATE_UV':continue
            edit=context.mode=='EDIT_MESH'
            bm=read_bm(obj,edit)
            uv=bm.loops.layers.uv.active
            if not uv:continue
            for island in uv_islands(bm,uv):
                if s.selected_only and not any(f.select for f in island):continue
                loops=[l for f in island for l in f.loops]
                pts=[l[uv].uv.copy() for l in loops]
                if not pts:continue
                center=sum(pts,Vector((0,0)))/len(pts)
                if self.action in {'ROTATE','SCALE'}:
                    for l,v in zip(loops,pts):
                        d=v-center
                        if self.action=='ROTATE':
                            c,si=math.cos(s.angle),math.sin(s.angle)
                            l[uv].uv=center+Vector((d.x*c-d.y*si,d.x*si+d.y*c))
                        else:l[uv].uv=center+d*s.priority
                elif self.action=='SNAP':
                    for l,v in zip(loops,pts):
                        l[uv].uv=(round(v.x*s.tex_w)/s.tex_w,round(v.y*s.tex_h)/s.tex_h)
                elif self.action=='STACK':
                    x0=min(v.x for v in pts);y0=min(v.y for v in pts)
                    tol=s.stack_tolerance
                    key=(len(island),len(pts),tuple(sorted(len(f.verts) for f in island)),
                         tuple(sorted((round((v.x-x0)/tol),round((v.y-y0)/tol)) for v in pts)))
                    if key in stack_cache:
                        x,y=stack_cache[key]
                        for l,v in zip(loops,pts):
                            l[uv].uv=v+Vector((x-x0,y-y0))
                    else:stack_cache[key]=(x0,y0)
                count+=1
            finish_bm(obj,bm,edit)
        self.report({'INFO'},f"Processed: {count}")
        return {'FINISHED'}

def op(layout,action,icon='NONE',text=None):
    o=layout.operator('fabuv2.manage',text=text or action.replace('_',' ').title(),icon=icon)
    o.action=action

def tool(layout,action,text):
    o=layout.operator('fabuv2.tools',text=text)
    o.action=action

def draw_ui(layout,context):
    s=context.scene.fabuv2
    sc=scheme_of(s)
    group=group_of(sc)
    col=layout.column(align=True)
    col.label(text="FABULARIS  /  UV PACKER LAB",icon='UV')
    col.prop(s,'mode')
    col.operator('fabuv2.pack',text='PACK',icon='MOD_UVPROJECT')
    box=layout.box()
    box.label(text='Packing Options',icon='OPTIONS')
    box.prop(s,'tex_w');box.prop(s,'tex_h');box.prop(s,'margin')
    row=box.row(align=True);row.prop(s,'rotate');row.prop(s,'scale')
    box.prop(s,'shape')
    box.prop(s,'selected_only')
    if s.mode=='TILES':
        box.prop(s,'target_tile');box.prop(s,'tile_count')
    if s.mode=='SINGLE':
        box.prop(s,'custom_box')
        if s.custom_box:
            box.prop(s,'box_min');box.prop(s,'box_max')
    if s.mode in {'GROUP_TILES','TOGETHER','GROUP_SINGLE'}:
        box=layout.box()
        box.label(text='Island Grouping',icon='GROUP_UVS')
        box.prop(s,'grouping')
        if s.grouping=='MANUAL':
            row=box.row(align=True)
            row.template_list('FABUV_UL_schemes','',s,'schemes',s,'scheme_index',rows=2)
            buttons=row.column(align=True)
            op(buttons,'ADD_SCHEME','ADD','')
            op(buttons,'REMOVE_SCHEME','REMOVE','')
        else:
            box.label(text='Auto groups created during Pack',icon='INFO')
        box.prop(s,'density_policy')
        box.prop(s,'layout')
        if s.layout=='GRID':box.prop(s,'tiles_in_row')
        if sc:
            box=layout.box()
            box.label(text='Scheme Groups',icon='COLOR')
            row=box.row(align=True)
            row.template_list('FABUV_UL_groups','',sc,'groups',sc,'group_index',rows=5)
            buttons=row.column(align=True)
            for act,ico in [('ADD_GROUP','ADD'),('REMOVE_GROUP','REMOVE'),('UP_GROUP','TRIA_UP'),('DOWN_GROUP','TRIA_DOWN')]:
                op(buttons,act,ico,'')
            if group:
                box.prop(group,'tile_count')
                box.prop(group,'tile')
                if s.density_policy=='CUSTOM':box.prop(group,'density')
                if s.grouping=='MANUAL':
                    op(box,'ASSIGN','ADD','Assign Islands To Group')
                    row=box.row(align=True)
                    op(row,'SELECT','RESTRICT_SELECT_OFF','Select')
                    op(row,'DESELECT','X','Deselect')
                    op(box,'CLEAR','REMOVE','Clear Selected Assignment')
                if s.layout=='MANUAL' and s.mode=='GROUP_TILES':
                    sub=box.box()
                    sub.label(text='Group Target Boxes')
                    row=sub.row(align=True)
                    row.template_list('FABUV_UL_boxes','',group,'boxes',group,'box_index',rows=3)
                    buttons=row.column(align=True)
                    op(buttons,'ADD_BOX','ADD','')
                    op(buttons,'REMOVE_BOX','REMOVE','')
                    if group.boxes:
                        b=group.boxes[min(group.box_index,len(group.boxes)-1)]
                        sub.prop(b,'minimum')
                        sub.prop(b,'maximum')
    box=layout.box()
    box.label(text='Auxiliary Operations',icon='TOOL_SETTINGS')
    tool(box,'CREATE_UV','Create Missing UV Maps')
    tool(box,'STACK','Stack Identical UV Islands')
    box.prop(s,'stack_tolerance')
    box.prop(s,'angle');tool(box,'ROTATE','Rotate Islands')
    box.prop(s,'priority');tool(box,'SCALE','Scale Islands')
    tool(box,'SNAP','Snap UVs to Pixel Grid')
    layout.label(text='CPU / Blender native packing',icon='INFO')

class FABUV_PT_uv(Panel):
    bl_options = {'DEFAULT_CLOSED'}
    bl_label='UV Packer'
    bl_idname='FABUV_PT_uv'
    bl_space_type='IMAGE_EDITOR'
    bl_region_type='UI'
    bl_category='Fabularis Tools'
    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_uv_packer")


    def draw(self,context):draw_ui(self.layout,context)

class FABUV_PT_view(Panel):
    bl_options = {'DEFAULT_CLOSED'}
    bl_label='UV Packer'
    bl_idname='FABUV_PT_view'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Fabularis Tools'
    bl_parent_id='FABULARIS_SECTION_UV'
    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_uv_packer")


    def draw(self,context):draw_ui(self.layout,context)

REGISTERED=[FABUV_Box,FABUV_Group,FABUV_Scheme,FABUV_Settings,
            FABUV_UL_groups,FABUV_UL_schemes,FABUV_UL_boxes,
            FABUV_OT_manage,FABUV_OT_pack,FABUV_OT_tools,FABUV_PT_uv,FABUV_PT_view]

def register():
    # Re-running from Blender Text Editor should not leave stale registered classes.
    if hasattr(bpy.types.Scene,'fabuv2'):
        del bpy.types.Scene.fabuv2
    for cls in reversed(REGISTERED):
        old=getattr(bpy.types,cls.__name__,None)
        if old:
            try:bpy.utils.unregister_class(old)
            except Exception:pass
    for cls in REGISTERED:bpy.utils.register_class(cls)
    bpy.types.Scene.fabuv2=PointerProperty(type=FABUV_Settings)

def unregister():
    if hasattr(bpy.types.Scene,'fabuv2'):del bpy.types.Scene.fabuv2
    for cls in reversed(REGISTERED):
        try:bpy.utils.unregister_class(cls)
        except Exception:pass

if __name__=='__main__':
    register()
    print('Fabularis UV Packer Lab v2: N > Fabularis UV')
