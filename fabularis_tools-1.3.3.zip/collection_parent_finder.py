import bpy


# ============================================================
# FABULARIS TOOLS - COLLECTION PARENT FINDER
# ============================================================


# ============================================================
# OGGETTO SELEZIONATO
# ============================================================

def get_selected_object(context):

    try:
        for item in context.selected_ids:
            if isinstance(item, bpy.types.Object):
                return item
    except:
        pass

    return context.active_object


# ============================================================
# RISALI FINO ALLA COLLECTION INSTANCE
# ============================================================

def find_instance_object(obj):

    while obj is not None:

        if (
            obj.instance_type == 'COLLECTION'
            and obj.instance_collection is not None
        ):
            return obj

        obj = obj.parent

    return None


# ============================================================
# MESH DATABLOCK DIRETTI DI UNA COLLECTION
# ============================================================

def get_mesh_data(collection):

    return {
        obj.data
        for obj in collection.objects
        if obj.type == 'MESH' and obj.data is not None
    }


# ============================================================
# TROVA COLLECTION PADRE
# ============================================================

def find_parent_collection(referenced):

    reference_meshes = get_mesh_data(
        referenced
    )


    # --------------------------------------------------------
    # Se non ha Mesh dirette,
    # segue eventuali Instance interne
    # --------------------------------------------------------

    if not reference_meshes:

        for obj in referenced.objects:

            if (
                obj.instance_type == 'COLLECTION'
                and obj.instance_collection is not None
            ):

                result = find_parent_collection(
                    obj.instance_collection
                )

                if result is not None:
                    return result


        # ----------------------------------------------------
        # Cerca anche nelle sotto-Collection
        # ----------------------------------------------------

        for child in referenced.children:

            result = find_parent_collection(
                child
            )

            if result is not None:
                return result


        return None


    # --------------------------------------------------------
    # Cerca Collection che utilizzano gli stessi Mesh datablock
    # --------------------------------------------------------

    best_collection = referenced
    best_score = 0


    for collection in bpy.data.collections:

        if collection == referenced:
            continue


        collection_meshes = get_mesh_data(
            collection
        )


        if not collection_meshes:
            continue


        common = (
            reference_meshes
            &
            collection_meshes
        )


        score = len(common)


        if score > best_score:

            best_score = score
            best_collection = collection


            # Match completo
            if common == reference_meshes:
                break


    return best_collection


# ============================================================
# TROVA LAYER COLLECTION
# ============================================================

def find_layer_collection(
    layer,
    target
):

    if layer.collection == target:
        return layer


    for child in layer.children:

        result = find_layer_collection(
            child,
            target
        )

        if result is not None:
            return result


    return None


# ============================================================
# SELEZIONA CONTENUTO COLLECTION
# ============================================================

def select_collection_content(
    context,
    collection
):

    layer = find_layer_collection(
        context.view_layer.layer_collection,
        collection
    )


    if layer is None:
        return 0


    try:
        layer.exclude = False
        layer.hide_viewport = False
    except:
        pass


    try:
        context.view_layer.active_layer_collection = layer
    except:
        pass


    try:
        bpy.ops.object.select_all(
            action='DESELECT'
        )
    except:
        pass


    selected = []


    # --------------------------------------------------------
    # Solo oggetti DIRETTI.
    # Niente all_objects per mantenere lo script leggero.
    # --------------------------------------------------------

    for obj in collection.objects:

        if obj.type != 'MESH':
            continue


        if obj.name not in context.view_layer.objects:
            continue


        try:
            obj.select_set(True)
            selected.append(obj)
        except:
            pass


    if selected:

        try:
            context.view_layer.objects.active = selected[0]
        except:
            pass


    return len(selected)


# ============================================================
# INFO COLLECTION INSTANCE
# ============================================================

def get_collection_info(context):

    selected = get_selected_object(
        context
    )


    if selected is None:
        return None


    instance = find_instance_object(
        selected
    )


    if instance is None:
        return None


    referenced = (
        instance.instance_collection
    )


    parent = find_parent_collection(
        referenced
    )


    if parent is None:
        return None


    return {
        "selected": selected,
        "instance": instance,
        "referenced": referenced,
        "parent": parent,
    }


# ============================================================
# OPERATORE - SELEZIONA COLLECTION PADRE
# ============================================================

class FABULARIS_OT_select_collection_parent(
    bpy.types.Operator
):

    bl_idname = (
        "fabularis.select_collection_parent"
    )

    bl_label = (
        "Seleziona Collection padre"
    )

    bl_description = (
        "Seleziona le Mesh della Collection originale"
    )


    collection_name: bpy.props.StringProperty()


    def execute(
        self,
        context
    ):

        collection = bpy.data.collections.get(
            self.collection_name
        )


        if collection is None:

            self.report(
                {'ERROR'},
                "Collection non trovata"
            )

            return {'CANCELLED'}


        count = select_collection_content(
            context,
            collection
        )


        if count:

            self.report(
                {'INFO'},
                (
                    f"{collection.name} | "
                    f"{count} Mesh selezionate - "
                    "premi Numpad ."
                )
            )

        else:

            self.report(
                {'WARNING'},
                (
                    f"Collection trovata: "
                    f"{collection.name}, "
                    "ma non è disponibile nella Scene corrente"
                )
            )


        return {'FINISHED'}


# ============================================================
# OPERATORE - TROVA DA TASTO DESTRO
# ============================================================

class FABULARIS_OT_find_collection_parent(
    bpy.types.Operator
):

    bl_idname = (
        "fabularis.find_collection_parent"
    )

    bl_label = (
        "Trova Collection Originale"
    )

    bl_description = (
        "Trova e seleziona la Collection originale "
        "della Collection Instance"
    )


    def execute(
        self,
        context
    ):

        info = get_collection_info(
            context
        )


        if info is None:

            self.report(
                {'ERROR'},
                "Collection padre non trovata"
            )

            return {'CANCELLED'}


        collection = info[
            "parent"
        ]


        count = select_collection_content(
            context,
            collection
        )


        if count:

            self.report(
                {'INFO'},
                (
                    f"Collection padre: "
                    f"{collection.name} | "
                    f"{count} Mesh selezionate - "
                    "premi Numpad ."
                )
            )

        else:

            self.report(
                {'WARNING'},
                (
                    f"Collection padre trovata: "
                    f"{collection.name}"
                )
            )


        return {'FINISHED'}


# ============================================================
# PANNELLO
# FIGLIO DI CONVERTITORE
# ============================================================

class FABULARIS_PT_collection_finder(
    bpy.types.Panel
):

    bl_options = {'DEFAULT_CLOSED'}

    bl_label = "Trova Collection Originale"

    bl_idname = "FABULARIS_PT_collection_finder"

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = "Fabularis Tools"

    # --------------------------------------------------------
    # Pannello nella sezione Collection e gerarchie
    # --------------------------------------------------------

    bl_parent_id = "FABULARIS_SECTION_COLLECTIONS"


    @classmethod
    def poll(cls, context):
        from .preferences import is_section_enabled
        return is_section_enabled(context, "show_collection_finder")


    def draw(
        self,
        context
    ):

        layout = self.layout


        info = get_collection_info(
            context
        )


        if info is None:

            layout.label(
                text="Nessuna Collection Instance",
                icon='INFO'
            )

            return


        selected = info["selected"]
        instance = info["instance"]
        referenced = info["referenced"]
        parent = info["parent"]


        # ====================================================
        # OGGETTO SELEZIONATO
        # ====================================================

        if selected != instance:

            box = layout.box()

            box.label(
                text="Oggetto selezionato"
            )

            box.label(
                text=selected.name,
                icon='OBJECT_DATA'
            )


        # ====================================================
        # COLLECTION INSTANCE
        # ====================================================

        box = layout.box()

        box.label(
            text="Collection Instance"
        )

        box.label(
            text=instance.name,
            icon='EMPTY_DATA'
        )


        # ====================================================
        # COLLECTION REFERENZIATA
        # ====================================================

        box = layout.box()

        box.label(
            text="Collection referenziata"
        )

        box.label(
            text=referenced.name,
            icon='LINKED'
        )


        # ====================================================
        # COLLECTION PADRE
        # ====================================================

        box = layout.box()

        box.label(
            text="Collection padre"
        )

        box.label(
            text=parent.name,
            icon='OUTLINER_COLLECTION'
        )


        # ====================================================
        # PULSANTE
        # ====================================================

        layout.separator()


        op = layout.operator(
            "fabularis.select_collection_parent",
            text="Seleziona Collection padre",
            icon='RESTRICT_SELECT_OFF'
        )


        op.collection_name = (
            parent.name
        )


        layout.label(
            text="Poi premi Numpad .",
            icon='INFO'
        )


# ============================================================
# MENU TASTO DESTRO OUTLINER
# ============================================================

def draw_outliner_menu(
    self,
    context
):

    self.layout.separator()


    self.layout.operator(
        "fabularis.find_collection_parent",
        text="Trova Collection Originale",
        icon='VIEWZOOM'
    )


# ============================================================
# CLASSI
# ============================================================

classes = (

    FABULARIS_OT_find_collection_parent,

    FABULARIS_OT_select_collection_parent,

    FABULARIS_PT_collection_finder,

)


# ============================================================
# REGISTER
# ============================================================

def register():

    for cls in classes:

        bpy.utils.register_class(
            cls
        )


    bpy.types.OUTLINER_MT_object.append(
        draw_outliner_menu
    )


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    try:

        bpy.types.OUTLINER_MT_object.remove(
            draw_outliner_menu
        )

    except:

        pass


    for cls in reversed(classes):

        try:

            bpy.utils.unregister_class(
                cls
            )

        except:

            pass
