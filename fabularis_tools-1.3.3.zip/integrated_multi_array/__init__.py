bl_info = {'name':'Multi Array Cloner','author':'OpenAI','version':(1,18,0),'blender':(4,3,0),'location':'Properties > Modifiers / F3','description':'Non-destructive collection instancing cloner','category':'Object'}
import bpy
import itertools
from mathutils import Matrix, Euler, Vector
from bpy.props import PointerProperty, CollectionProperty, IntProperty, FloatVectorProperty, EnumProperty, BoolProperty, StringProperty

PREFIX='MAC | '
_BUILDING=set()
def changed(self, context):
    obj=getattr(self,'id_data',None) if self else None
    if obj is None and context:
        obj=context.object
    if obj and is_cloner(obj) and obj.as_pointer() not in _BUILDING:
        try: build(obj)
        except Exception as exc: print('Multi Array Cloner update:', exc)


def is_cloner(obj):
    return bool(obj and obj.get('mac_cloner'))

def socket(node, name, value):
    s=node.inputs.get(name)
    if s is not None: s.default_value=value

def indexed_vector(nodes, links, index_socket, base, step, location):
    combine=nodes.new('ShaderNodeCombineXYZ'); combine.location=location
    for axis in range(3):
        multiply=nodes.new('ShaderNodeMath'); multiply.operation='MULTIPLY'
        multiply.location=(location[0]-220,location[1]-axis*90)
        multiply.inputs[1].default_value=step[axis]
        links.new(index_socket,multiply.inputs[0])
        add=nodes.new('ShaderNodeMath'); add.operation='ADD'
        add.location=(location[0]-90,location[1]-axis*90)
        add.inputs[1].default_value=base[axis]
        links.new(multiply.outputs[0],add.inputs[0])
        links.new(add.outputs[0],combine.inputs[axis])
    return combine.outputs['Vector']

def build(obj):
    """Rebuild a flat source list, then instance it on a multi-dimensional point grid."""
    key=obj.as_pointer()
    if key in _BUILDING: return
    _BUILDING.add(key)
    ng=None
    try:
        settings=obj.mac_settings
        ng=bpy.data.node_groups.new('MAC | '+obj.name, 'GeometryNodeTree')
        ng.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry')
        ng.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
        nodes=ng.nodes; links=ng.links
        group_in=nodes.new('NodeGroupInput'); group_in.location=(-1050,700)
        out=nodes.new('NodeGroupOutput'); out.location=(1500,100)
        sources=[]
        if settings.source_mode=='SELF':
            sources=[('SELF',obj)]
        elif settings.source_mode=='COLLECTION':
            if settings.collection_source_type=='HIERARCHY':
                if settings.source_empty:
                    sources=[('HIERARCHY',settings.source_empty)]
            elif settings.collection:
                # One entry per direct object; nested collections are represented as a unit.
                sources=[('OBJECT',o) for o in settings.collection.objects if o!=obj]
                sources += [('COLLECTION',c) for c in settings.collection.children]
        elif settings.source_mode=='MANUAL':
            for item in settings.sources:
                if item.kind=='OBJECT' and item.obj:
                    sources.append(('SELF',obj) if item.obj==obj else ('OBJECT',item.obj))
                elif item.kind=='COLLECTION' and item.collection:
                    sources.append(('COLLECTION',item.collection))
                elif item.kind=='HIERARCHY' and item.obj:
                    sources.append(('HIERARCHY',item.obj))
        # Each source is ONE instance, including nested children of an Empty.
        # GeometryToInstance accepts multiple geometry sockets, each source's bundle
        # is a single nested instance. Source collection children remain instanced.
        pool=nodes.new('GeometryNodeGeometryToInstance'); pool.location=(-150,0)
        # Blender assigns instance indices in reverse connection order on this node.
        # Connect the source list backwards so Index 0 corresponds to Object 1 in the UI.
        for index,(kind,ref) in enumerate(reversed(sources)):
            if kind=='SELF':
                links.new(group_in.outputs['Geometry'],pool.inputs['Geometry'])
            elif kind=='COLLECTION':
                n=nodes.new('GeometryNodeCollectionInfo'); n.location=(-650,-index*250)
                n.transform_space='ORIGINAL'
                n.inputs['Collection'].default_value=ref
                socket(n, 'Separate Children', False)
                socket(n, 'Reset Children', False)
                links.new(n.outputs['Instances'],pool.inputs['Geometry'])
            elif ref.type=='EMPTY' and ref.instance_type=='COLLECTION' and ref.instance_collection:
                n=nodes.new('GeometryNodeCollectionInfo'); n.location=(-650,-index*250)
                n.inputs['Collection'].default_value=ref.instance_collection
                n.transform_space='ORIGINAL'; socket(n, 'Separate Children', False); socket(n, 'Reset Children', False)
                links.new(n.outputs['Instances'],pool.inputs['Geometry'])
            elif kind=='HIERARCHY' or ref.type=='EMPTY':
                if ref.type!='EMPTY':
                    raise ValueError('Hierarchy source must be an Empty with child objects')
                bundle=nodes.new('GeometryNodeGeometryToInstance'); bundle.location=(-380,-index*250)
                root_inverse=ref.matrix_world.inverted_safe()
                for child in ref.children_recursive:
                    matrix=root_inverse @ child.matrix_world
                    translation,rotation,scale=matrix.decompose()
                    if child.type=='EMPTY' and child.instance_type=='COLLECTION' and child.instance_collection:
                        n=nodes.new('GeometryNodeCollectionInfo'); n.location=(-900,-index*250)
                        n.transform_space='ORIGINAL'
                        n.inputs['Collection'].default_value=child.instance_collection
                        socket(n, 'Separate Children', False); socket(n, 'Reset Children', False)
                        geometry_output=n.outputs.get('Instances') or n.outputs.get('Geometry')
                    elif child.type in {'MESH','CURVE','CURVES','FONT','SURFACE','POINTCLOUD','VOLUME'}:
                        n=nodes.new('GeometryNodeObjectInfo'); n.location=(-900,-index*250)
                        n.transform_space='ORIGINAL'; n.inputs['Object'].default_value=child
                        geometry_output=n.outputs['Geometry']
                    else:
                        continue
                    transform=nodes.new('GeometryNodeTransform'); transform.location=(-620,-index*250)
                    socket(transform,'Translation',translation[:]); socket(transform,'Rotation',rotation.to_euler()[:]); socket(transform,'Scale',scale[:])
                    links.new(geometry_output,transform.inputs['Geometry'])
                    links.new(transform.outputs['Geometry'],bundle.inputs['Geometry'])
                links.new(bundle.outputs['Instances'],pool.inputs['Geometry'])
            else:
                n=nodes.new('GeometryNodeObjectInfo'); n.location=(-650,-index*250)
                n.transform_space='ORIGINAL'
                n.inputs['Object'].default_value=ref
                links.new(n.outputs['Geometry'],pool.inputs['Geometry'])
        if not sources:
            # Empty output is intentional until sources are assigned.
            links.new(group_in.outputs['Geometry'],out.inputs['Geometry'])
            modifier=next((m for m in obj.modifiers if m.type=='NODES' and m.name.startswith(PREFIX)),None)
            if modifier is None: modifier=obj.modifiers.new(PREFIX+'Cloner','NODES')
            old=modifier.node_group; modifier.node_group=ng
            if old and old.users==0 and old.name.startswith(PREFIX): bpy.data.node_groups.remove(old)
            return
        # Construct all points FIRST so Index/Random is evaluated per final cell.
        # First layer: Mesh Line. Later layers: nested instancing of point grids,
        # realized ONLY for the lightweight points, never for source geometry.
        point_geom=None
        for i,layer in enumerate(settings.layers):
            line=nodes.new('GeometryNodeMeshLine'); line.mode='OFFSET'
            line.location=(-250+i*260,500)
            socket(line,'Count',max(1,layer.count)); socket(line,'Offset',layer.offset)
            if point_geom is None:
                point_geom=line.outputs['Mesh']
            else:
                grid=nodes.new('GeometryNodeInstanceOnPoints'); grid.location=(20+i*260,460)
                links.new(line.outputs['Mesh'],grid.inputs['Points'])
                links.new(point_geom,grid.inputs['Instance'])
                realize=nodes.new('GeometryNodeRealizeInstances'); realize.location=(170+i*260,460)
                links.new(grid.outputs['Instances'],realize.inputs['Geometry'])
                point_geom=realize.outputs['Geometry']
        if point_geom is None:
            line=nodes.new('GeometryNodeMeshLine'); line.mode='OFFSET'; socket(line,'Count',1)
            point_geom=line.outputs['Mesh']
        inst=nodes.new('GeometryNodeInstanceOnPoints'); inst.location=(1100,250)
        links.new(point_geom,inst.inputs['Points'])
        links.new(pool.outputs['Instances'],inst.inputs['Instance'])
        inst.inputs['Pick Instance'].default_value=True
        idx=nodes.new('GeometryNodeInputIndex'); idx.location=(350,0)
        rotation_field=indexed_vector(nodes,links,idx.outputs['Index'],settings.rotation,settings.rotation_step,(850,-250))
        scale_field=indexed_vector(nodes,links,idx.outputs['Index'],settings.scale,settings.scale_step,(850,-650))
        links.new(rotation_field,inst.inputs['Rotation'])
        links.new(scale_field,inst.inputs['Scale'])
        if settings.mode=='SEQUENTIAL':
            idx.location=(350,0)
            mod=nodes.new('ShaderNodeMath'); mod.operation='FLOORED_MODULO'; mod.location=(570,0)
            mod.inputs[1].default_value=max(1,len(sources))
            links.new(idx.outputs['Index'],mod.inputs[0]); links.new(mod.outputs[0],inst.inputs['Instance Index'])
        elif settings.mode=='RANDOM':
            rand=nodes.new('FunctionNodeRandomValue'); rand.data_type='INT'; rand.location=(550,0)
            rand.inputs['Min'].default_value=0; rand.inputs['Max'].default_value=len(sources)-1
            rand.inputs['Seed'].default_value=settings.seed
            links.new(rand.outputs['Value'],inst.inputs['Instance Index'])
        join=nodes.new('GeometryNodeJoinGeometry'); join.location=(1300,100)
        if not any(kind=='SELF' for kind,_ref in sources):
            links.new(group_in.outputs['Geometry'],join.inputs['Geometry'])
        links.new(inst.outputs['Instances'],join.inputs['Geometry'])
        links.new(join.outputs['Geometry'],out.inputs['Geometry'])
        modifier=next((m for m in obj.modifiers if m.type=='NODES' and m.name.startswith(PREFIX)),None)
        if modifier is None: modifier=obj.modifiers.new(PREFIX+'Cloner','NODES')
        old=modifier.node_group; modifier.node_group=ng
        if old and old.users==0 and old.name.startswith(PREFIX): bpy.data.node_groups.remove(old)
    except Exception:
        if ng and ng.users==0: bpy.data.node_groups.remove(ng)
        raise
    finally:
        _BUILDING.discard(key)

class MAC_Source(bpy.types.PropertyGroup):
    kind: EnumProperty(name='Type',items=[('OBJECT','Object','Use one object'),('COLLECTION','Collection','Use a collection as one source'),('HIERARCHY','Empty Hierarchy','Bundle an Empty and all descendant meshes')],default='OBJECT',update=changed)
    obj: PointerProperty(name='Object / Empty',type=bpy.types.Object,update=changed)
    collection: PointerProperty(name='Collection',type=bpy.types.Collection,update=changed)

class MAC_Layer(bpy.types.PropertyGroup):
    count: IntProperty(name='Count',default=2,min=1,max=100000,update=changed)
    offset: FloatVectorProperty(name='Offset',size=3,subtype='TRANSLATION',default=(2.0,0.0,0.0),update=changed)

class MAC_Settings(bpy.types.PropertyGroup):
    source_mode: EnumProperty(name='Source',items=[('SELF','This Object','Use the object with the modifier as the source'),('COLLECTION','Collection','Use collection contents or one Empty hierarchy'),('MANUAL','Manual','Choose individual objects, collections, or Empty hierarchies')],default='COLLECTION',update=changed)
    collection_source_type: EnumProperty(name='Collection Source Type',items=[('COLLECTION','Collection','Use the objects and nested collections inside a collection'),('HIERARCHY','Empty Hierarchy','Use an Empty and its descendant objects as one source')],default='COLLECTION',update=changed)
    collection: PointerProperty(name='Source Collection',type=bpy.types.Collection,update=changed)
    source_empty: PointerProperty(name='Root Empty',type=bpy.types.Object,update=changed)
    sources: CollectionProperty(type=MAC_Source)
    layers: CollectionProperty(type=MAC_Layer)
    mode: EnumProperty(name='Distribution',items=[('IDENTICAL','Identical','Always first source'),('SEQUENTIAL','Sequential','Cycle sources in order'),('RANDOM','Random','Choose source per position')],default='SEQUENTIAL',update=changed)
    seed: IntProperty(name='Seed',default=42,min=0,max=10000,update=changed)
    rotation: FloatVectorProperty(name='Rotation',size=3,subtype='EULER',default=(0.0,0.0,0.0),update=changed)
    rotation_step: FloatVectorProperty(name='Rotation Step',size=3,subtype='EULER',default=(0.0,0.0,0.0),update=changed)
    scale: FloatVectorProperty(name='Scale',size=3,subtype='XYZ',default=(1.0,1.0,1.0),update=changed)
    scale_step: FloatVectorProperty(name='Scale Step',size=3,subtype='XYZ',default=(0.0,0.0,0.0),update=changed)
    ui_source_open: BoolProperty(name='Show Sources',default=True)
    ui_distribution_open: BoolProperty(name='Show Distribution',default=True)
    ui_array_open: BoolProperty(name='Show Array',default=True)
    ui_copy_transform_open: BoolProperty(name='Show Per Copy Transform',default=False)
    ui_advanced_open: BoolProperty(name='Show Advanced Controls',default=False)
    ui_cloner_transform_open: BoolProperty(name='Show Cloner Transform',default=False)
    ui_keyframes_open: BoolProperty(name='Show Keyframes',default=True)
    apply_container: EnumProperty(name='Applied Copies',items=[('COLLECTION','Collection','Put all applied copies in a new collection'),('EMPTY','Empty Parent','Parent all applied copies to a new Empty')],default='COLLECTION')

class MAC_OT_create(bpy.types.Operator):
    bl_idname='object.mac_create'; bl_label='Add Multi Array Cloner'; bl_description='Create a standalone Multi Array Cloner controller at the 3D Cursor'; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        # Capture selected sources before deselecting them for the new controller.
        selected=list(getattr(context,'selected_objects',[]) or [])
        selected_ids=list(getattr(context,'selected_ids',[]) or [])
        selected_collections=[item for item in selected_ids if isinstance(item,bpy.types.Collection)]
        selected_set=set(selected)
        roots=[]
        for source in selected:
            parent=source.parent
            inside_selected_hierarchy=False
            while parent:
                if parent in selected_set and parent.type=='EMPTY' and not (parent.instance_type=='COLLECTION' and parent.instance_collection):
                    inside_selected_hierarchy=True
                    break
                parent=parent.parent
            if not inside_selected_hierarchy:
                roots.append(source)
        mesh=bpy.data.meshes.new('MAC Controller Mesh'); obj=bpy.data.objects.new('Multi Array Cloner',mesh)
        context.collection.objects.link(obj)
        obj.location=context.scene.cursor.location.copy()
        obj.rotation_euler=(0.0,0.0,0.0); obj.scale=(1.0,1.0,1.0)
        obj['mac_controller']=True
        settings=obj.mac_settings
        layer=settings.layers.add(); layer.count=5; layer.offset=(2.0,0,0)
        if roots or selected_collections:
            settings.source_mode='MANUAL'
            seen=set()
            for source in roots:
                is_collection_instance=(source.type=='EMPTY' and source.instance_type=='COLLECTION' and source.instance_collection)
                if is_collection_instance:
                    collection=source.instance_collection
                    key=('COLLECTION',collection.as_pointer())
                    if key in seen: continue
                    seen.add(key)
                    item=settings.sources.add(); item.kind='COLLECTION'; item.collection=collection
                else:
                    key=('OBJECT',source.as_pointer())
                    if key in seen: continue
                    seen.add(key)
                    item=settings.sources.add()
                    if source.type=='EMPTY': item.kind='HIERARCHY'
                    else: item.kind='OBJECT'
                    item.obj=source
            for collection in selected_collections:
                key=('COLLECTION',collection.as_pointer())
                if key in seen: continue
                seen.add(key)
                item=settings.sources.add(); item.kind='COLLECTION'; item.collection=collection
        bpy.ops.object.select_all(action='DESELECT'); obj.select_set(True); context.view_layer.objects.active=obj
        obj['mac_cloner']=True
        build(obj)
        if roots or selected_collections:
            self.report({'INFO'},f'Created controller with {len(roots)+len(selected_collections)} selected sources')
        else:
            self.report({'INFO'},'Created an empty controller; add sources in its modifier panel')
        return {'FINISHED'}

class MAC_OT_add_modifier(bpy.types.Operator):
    bl_idname='object.mac_add_modifier'; bl_label='Multi Array Cloner'; bl_description='Add the Multi Array Cloner Geometry Nodes modifier to the selected object'; bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):
        return context.object is not None
    def execute(self,context):
        obj=context.object; settings=obj.mac_settings
        existing=next((m for m in obj.modifiers if m.type=='NODES' and m.name.startswith(PREFIX)),None)
        if existing:
            obj['mac_cloner']=True
            self.report({'INFO'},'Multi Array Cloner modifier is already on this object')
            return {'FINISHED'}
        if not settings.layers:
            layer=settings.layers.add(); layer.count=5; layer.offset=(2.0,0.0,0.0)
        settings.source_mode='SELF'
        obj['mac_cloner']=True
        build(obj)
        self.report({'INFO'},'Multi Array Cloner added to the selected object')
        return {'FINISHED'}

class MAC_OT_source_add(bpy.types.Operator):
    bl_idname='object.mac_source_add'; bl_label='Add Source'; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        context.object.mac_settings.sources.add(); return {'FINISHED'}
class MAC_OT_source_remove(bpy.types.Operator):
    bl_idname='object.mac_source_remove'; bl_label='Remove Source'; bl_options={'REGISTER','UNDO'}
    index:IntProperty()
    def execute(self,context):
        context.object.mac_settings.sources.remove(self.index); build(context.object); return {'FINISHED'}
class MAC_OT_source_move(bpy.types.Operator):
    bl_idname='object.mac_source_move'; bl_label='Move Source'; bl_options={'REGISTER','UNDO'}
    index:IntProperty(); direction:IntProperty()
    def execute(self,context):
        arr=context.object.mac_settings.sources; target=self.index+self.direction
        if 0<=target<len(arr): arr.move(self.index,target); build(context.object)
        return {'FINISHED'}
class MAC_OT_layer_add(bpy.types.Operator):
    bl_idname='object.mac_layer_add'; bl_label='Add Array Layer'; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        layer=context.object.mac_settings.layers.add(); layer.count=2; layer.offset=(0,2,0); build(context.object); return {'FINISHED'}
class MAC_OT_layer_remove(bpy.types.Operator):
    bl_idname='object.mac_layer_remove'; bl_label='Remove Array Layer'; bl_options={'REGISTER','UNDO'}
    index:IntProperty()
    def execute(self,context):
        arr=context.object.mac_settings.layers
        if len(arr)>1: arr.remove(self.index); build(context.object)
        return {'FINISHED'}
class MAC_OT_insert_keyframes(bpy.types.Operator):
    bl_idname='object.mac_insert_keyframes'; bl_label='Insert Keyframes'; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        obj=context.object; settings=obj.mac_settings; frame=context.scene.frame_current
        paths=['location','rotation_euler','scale','mac_settings.seed','mac_settings.rotation','mac_settings.rotation_step','mac_settings.scale','mac_settings.scale_step']
        paths += [f'mac_settings.layers[{i}].{name}' for i in range(len(settings.layers)) for name in ('count','offset')]
        inserted=0
        for path in paths:
            if obj.keyframe_insert(data_path=path,frame=frame,group='Multi Array Cloner'):
                inserted+=1
        self.report({'INFO'},f'Inserted {inserted} keyframe channels at frame {frame}')
        build(obj)
        return {'FINISHED'}

class MAC_OT_refresh(bpy.types.Operator):
    bl_idname='object.mac_refresh'; bl_label='Refresh Cloner'; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        build(context.object); self.report({'INFO'},'Multi Array Cloner updated'); return {'FINISHED'}

def evaluated_random_source_indices(obj, modifier, total):
    """Read the exact Random Value field used by this cloner from Blender itself."""
    original_group=modifier.node_group
    probe_group=original_group.copy()
    try:
        modifier.node_group=probe_group
        output=next(n for n in probe_group.nodes if n.bl_idname=='NodeGroupOutput')
        final_instance=next(n for n in probe_group.nodes
                            if n.bl_idname=='GeometryNodeInstanceOnPoints'
                            and n.inputs.get('Pick Instance')
                            and n.inputs['Pick Instance'].default_value)
        points_link=next(iter(final_instance.inputs['Points'].links),None)
        random_node=next(n for n in probe_group.nodes
                         if n.bl_idname=='FunctionNodeRandomValue' and n.data_type=='INT')
        if points_link is None: return None
        store=probe_group.nodes.new('GeometryNodeStoreNamedAttribute')
        store.domain='POINT'; store.data_type='INT'
        store.inputs['Name'].default_value='__mac_apply_source_index'
        probe_group.links.new(points_link.from_socket,store.inputs['Geometry'])
        probe_group.links.new(random_node.outputs['Value'],store.inputs['Value'])
        for link in list(output.inputs['Geometry'].links): probe_group.links.remove(link)
        probe_group.links.new(store.outputs['Geometry'],output.inputs['Geometry'])
        context=bpy.context
        context.view_layer.update()
        evaluated=obj.evaluated_get(context.evaluated_depsgraph_get())
        mesh=evaluated.to_mesh()
        try:
            attribute=mesh.attributes.get('__mac_apply_source_index')
            if attribute is None or len(attribute.data)!=total: return None
            return [int(item.value) for item in attribute.data]
        finally:
            evaluated.to_mesh_clear()
    except Exception as exc:
        print('Multi Array Cloner random Apply probe:',exc)
        return None
    finally:
        modifier.node_group=original_group
        if probe_group.users==0:
            bpy.data.node_groups.remove(probe_group)

class MAC_OT_apply(bpy.types.Operator):
    bl_idname='object.mac_apply'; bl_label='Apply Cloner (Make Real)'
    bl_description='Convert every generated copy into a separate scene object or collection instance and remove the cloner'
    bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):
        obj=context.object
        return bool(obj and is_cloner(obj) and any(m.type=='NODES' and m.name.startswith(PREFIX) for m in obj.modifiers))
    def execute(self,context):
        obj=context.object; settings=obj.mac_settings
        sources=[]
        if settings.source_mode=='SELF':
            sources=[('OBJECT',obj)]
        elif settings.source_mode=='COLLECTION':
            if settings.collection_source_type=='HIERARCHY':
                if settings.source_empty: sources=[('HIERARCHY',settings.source_empty)]
            elif settings.collection:
                sources=[('OBJECT',source) for source in settings.collection.objects if source!=obj]
                sources += [('COLLECTION',child) for child in settings.collection.children]
        else:
            for item in settings.sources:
                if item.kind=='OBJECT' and item.obj: sources.append(('OBJECT',item.obj))
                elif item.kind=='COLLECTION' and item.collection: sources.append(('COLLECTION',item.collection))
                elif item.kind=='HIERARCHY' and item.obj: sources.append(('HIERARCHY',item.obj))
        if not sources:
            self.report({'WARNING'},'Add at least one source before applying the cloner')
            return {'CANCELLED'}
        if not settings.layers:
            layer_counts=[1]; layer_offsets=[(0.0,0.0,0.0)]
        else:
            layer_counts=[max(1,layer.count) for layer in settings.layers]
            layer_offsets=[layer.offset[:] for layer in settings.layers]
        # The GN layout is a Cartesian product of the configured array layers.
        total=1
        for count in layer_counts: total*=count
        if total>100000:
            self.report({'ERROR'},'Applying more than 100,000 copies at once is blocked to avoid freezing Blender')
            return {'CANCELLED'}
        modifier=next((m for m in obj.modifiers if m.type=='NODES' and m.name.startswith(PREFIX)),None)
        random_indices=None
        if settings.mode=='RANDOM':
            random_indices=evaluated_random_source_indices(obj,modifier,total) if modifier else None
            if random_indices is None:
                self.report({'ERROR'},'Could not read Blender random source order; cloner was not applied')
                return {'CANCELLED'}
        point_indices=(tuple(reversed(indices)) for indices in itertools.product(*(range(n) for n in reversed(layer_counts))))
        linked=[]
        roots=[]
        scene_collection=context.scene.collection
        def add_collection_instance(collection, matrix, name):
            inst=bpy.data.objects.new(name, None)
            inst.empty_display_type='PLAIN_AXES'; inst.instance_type='COLLECTION'; inst.instance_collection=collection
            scene_collection.objects.link(inst); inst.matrix_world=matrix
            linked.append(inst); roots.append(inst)

        def duplicate_hierarchy(root, matrix, suffix):
            mapping={}
            originals=[root]+list(root.children_recursive)
            for original in originals:
                clone=original.copy()
                if original.data is not None: clone.data=original.data
                clone.name=f'{original.name} {suffix}'
                scene_collection.objects.link(clone); mapping[original]=clone; linked.append(clone)
            for original,clone in mapping.items():
                if original.parent in mapping:
                    clone.parent=mapping[original.parent]
                    clone.matrix_parent_inverse=original.matrix_parent_inverse.copy()
                    clone.matrix_basis=original.matrix_basis.copy()
                else:
                    clone.matrix_world=matrix
            roots.append(mapping[root])
            return mapping[root]

        source_count=len(sources)
        for index,indices in enumerate(point_indices):
            position=Vector((0.0,0.0,0.0))
            for axis,step in enumerate(layer_offsets):
                for axis_index in range(3): position[axis_index]+=indices[axis]*step[axis_index]
            rotation=Euler(tuple(settings.rotation[a]+index*settings.rotation_step[a] for a in range(3)),'XYZ')
            scale=Vector(tuple(settings.scale[a]+index*settings.scale_step[a] for a in range(3)))
            matrix=obj.matrix_world @ Matrix.LocRotScale(position,rotation,scale)
            if settings.mode=='IDENTICAL': source_index=0
            elif settings.mode=='RANDOM': source_index=random_indices[index]
            else: source_index=index % source_count
            kind,source=sources[source_index]
            suffix=f'Copy {index+1:03d}'
            if kind=='COLLECTION':
                add_collection_instance(source,matrix,f'{source.name} {suffix}')
            elif kind=='HIERARCHY':
                duplicate_hierarchy(source,matrix,suffix)
            elif source==obj and obj.get('mac_controller'):
                # A standalone controller has no source mesh to duplicate.
                continue
            else:
                clone=source.copy()
                if source.data is not None: clone.data=source.data
                clone.name=f'{source.name} {suffix}'
                if source==obj:
                    for modifier in list(clone.modifiers):
                        if modifier.type=='NODES' and modifier.name.startswith(PREFIX): clone.modifiers.remove(modifier)
                scene_collection.objects.link(clone); clone.parent=None; clone.matrix_world=matrix
                linked.append(clone); roots.append(clone)
        if settings.apply_container=='COLLECTION':
            target_collection=bpy.data.collections.new(f'{obj.name} Applied Copies')
            scene_collection.children.link(target_collection)
            for clone in linked:
                for collection in list(clone.users_collection): collection.objects.unlink(clone)
                target_collection.objects.link(clone)
        else:
            parent=bpy.data.objects.new(f'{obj.name} Applied Copies',None)
            parent.empty_display_type='PLAIN_AXES'; scene_collection.objects.link(parent)
            parent.matrix_world=obj.matrix_world.copy()
            for clone in roots:
                world=clone.matrix_world.copy(); clone.parent=parent; clone.matrix_world=world
        for modifier in list(obj.modifiers):
            if modifier.type=='NODES' and modifier.name.startswith(PREFIX): obj.modifiers.remove(modifier)
        # A standalone controller only holds an empty mesh; remove it after making copies.
        if obj.get('mac_controller'):
            bpy.data.objects.remove(obj,do_unlink=True)
        else:
            obj['mac_cloner']=False
        self.report({'INFO'},f'Applied cloner: created {len(linked)} scene objects from {total} positions')
        return {'FINISHED'}

@bpy.app.handlers.persistent
def mac_frame_change(scene, depsgraph=None):
    for obj in scene.objects:
        if is_cloner(obj) and obj.animation_data:
            try: build(obj)
            except Exception as exc: print('Multi Array Cloner animation update:', exc)

class MAC_PT_modifier(bpy.types.Panel):
    bl_label='Multi Array Cloner'; bl_idname='OBJECT_PT_mac_cloner'; bl_space_type='PROPERTIES'; bl_region_type='WINDOW'; bl_context='modifier'; bl_options={'DEFAULT_CLOSED'}
    @classmethod
    def poll(cls,context):
        return is_cloner(context.object) and any(m.type=='NODES' and m.name.startswith(PREFIX) for m in context.object.modifiers)
    def draw(self,context):
        layout=self.layout; obj=context.object; s=obj.mac_settings
        layout.use_property_split=True
        layout.use_property_decorate=True

        def foldout(container,prop,title,icon='NONE'):
            row=container.row(align=True); row.use_property_decorate=False
            opened=getattr(s,prop)
            row.prop(s,prop,text='',icon='TRIA_DOWN' if opened else 'TRIA_RIGHT',emboss=False)
            row.label(text=title,icon=icon)
            return opened

        def vector_fields(container,data,prop,label):
            for axis,name in enumerate(('X','Y','Z')):
                row=container.row()
                row.use_property_split=True
                row.use_property_decorate=True
                row.prop(data,prop,index=axis,text=f'{label} {name}')

        # Keep the source mode visible; collapse only the potentially long object list.
        source=layout.column(); source.use_property_decorate=False
        source.prop(s,'source_mode',text='Source')
        if s.source_mode=='SELF':
            source.label(text='This object is the source',icon='OBJECT_DATA')
        elif s.source_mode=='COLLECTION':
            source.prop(s,'collection_source_type',text='Type')
            if s.collection_source_type=='COLLECTION': source.prop(s,'collection')
            else:
                source.prop(s,'source_empty',text='Root Empty')
                if s.source_empty and s.source_empty.type!='EMPTY':
                    source.label(text='Choose an Empty object',icon='ERROR')
        else:
            objects=layout.box(); objects.use_property_decorate=False
            title=f'Objects ({len(s.sources)})'
            if foldout(objects,'ui_source_open',title,'OBJECT_DATA'):
                for i,item in enumerate(s.sources):
                    box=objects.box(); box.use_property_decorate=False
                    row=box.row(align=True); row.label(text=f'Object {i+1}')
                    op=row.operator('object.mac_source_move',text='',icon='TRIA_UP');op.index=i;op.direction=-1
                    op=row.operator('object.mac_source_move',text='',icon='TRIA_DOWN');op.index=i;op.direction=1
                    op=row.operator('object.mac_source_remove',text='',icon='X');op.index=i
                    box.prop(item,'kind',text='Type')
                    if item.kind in {'OBJECT','HIERARCHY'}:
                        box.prop(item,'obj',text='Empty' if item.kind=='HIERARCHY' else 'Object')
                        if item.kind=='HIERARCHY' and item.obj and item.obj.type!='EMPTY':
                            box.label(text='Choose an Empty object',icon='ERROR')
                    else: box.prop(item,'collection',text='Collection')
                objects.operator('object.mac_source_add',text='Add Object',icon='ADD')

        # Array and Advanced Controls are collapsible; advanced settings contain two sub-foldouts.
        array=layout.box(); array.use_property_decorate=True
        if foldout(array,'ui_array_open','Array','MOD_ARRAY'):
            array.prop(s,'mode',text='Distribution')
            if s.mode=='RANDOM': array.prop(s,'seed',text='Seed')
            for i,layer in enumerate(s.layers):
                box=array.box(); box.use_property_decorate=True
                row=box.row(align=True); row.label(text=f'Layer {i+1}')
                op=row.operator('object.mac_layer_remove',text='',icon='X');op.index=i
                box.prop(layer,'count',text='Count')
                vector_fields(box,layer,'offset','Distance')
            array.operator('object.mac_layer_add',text='Add Layer',icon='ADD')

        advanced=layout.box(); advanced.use_property_decorate=True
        if foldout(advanced,'ui_advanced_open','Advanced Controls','PREFERENCES'):
            per_copy=advanced.box(); per_copy.use_property_decorate=True
            if foldout(per_copy,'ui_copy_transform_open','Per Copy Transform','DUPLICATE'):
                vector_fields(per_copy,s,'rotation','Start Rotation')
                vector_fields(per_copy,s,'rotation_step','Rotation Step')
                vector_fields(per_copy,s,'scale','Start Scale')
                vector_fields(per_copy,s,'scale_step','Scale Step')
                per_copy.label(text='Step values accumulate across copies',icon='INFO')

            cloner=advanced.box(); cloner.use_property_decorate=True
            if foldout(cloner,'ui_cloner_transform_open','Cloner Transform','OBJECT_ORIGIN'):
                vector_fields(cloner,obj,'location','Position')
                vector_fields(cloner,obj,'rotation_euler','Rotation')
                vector_fields(cloner,obj,'scale','Scale')

        # Native property dots toggle keyframes at the current frame (add or remove).
        layout.label(text='Use the dots beside values to add/remove keyframes')
        layout.operator('object.mac_insert_keyframes',text='Keyframe All at Current Frame',icon='KEY_HLT')
        layout.operator('object.mac_refresh',text='Refresh Cloner',icon='FILE_REFRESH')
        layout.prop(s,'apply_container',text='Apply Copies To')
        layout.operator('object.mac_apply',text='Apply / Make Real',icon='CHECKMARK')

class MAC_PT_sidebar(bpy.types.Panel):
    bl_label='Multi Array Cloner'
    bl_idname='FABULARIS_PT_multi_array_cloner'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Fabularis Tools'
    bl_parent_id='FABULARIS_SECTION_OTHER'
    bl_options={'DEFAULT_CLOSED'}
    draw=MAC_PT_modifier.draw
    @classmethod
    def poll(cls,context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_multi_array") and MAC_PT_modifier.poll(context)


class VIEW3D_MT_fabularis_modifier(bpy.types.Menu):
    bl_label='Modifier'
    bl_idname='VIEW3D_MT_fabularis_modifier'
    def draw(self,context):
        self.layout.operator('object.mac_create', text='Multi Array Cloner', icon='MOD_ARRAY')

class VIEW3D_MT_fabularis_mac_root(bpy.types.Menu):
    bl_label='Fabularis Tools'
    bl_idname='VIEW3D_MT_fabularis_mac_root'
    def draw(self,context):
        self.layout.menu('VIEW3D_MT_fabularis_modifier', text='Modifier', icon='MODIFIER')

_INTEGRATED_MENU=None
_MODIFIER_ADD_MENU=None

def find_fabularis_menu():
    for name in dir(bpy.types):
        menu=getattr(bpy.types,name,None)
        try:
            if not isinstance(menu,type) or not issubclass(menu,bpy.types.Menu):
                continue
            if menu in {VIEW3D_MT_fabularis_modifier,VIEW3D_MT_fabularis_mac_root}:
                continue
            label=str(getattr(menu,'bl_label','') or '').strip().casefold()
            if label in {'fabularis tools','fabularis tool'}:
                return menu
        except (TypeError,AttributeError):
            continue
    return None

def draw_modifier_entry(self, context):
    self.layout.menu('VIEW3D_MT_fabularis_modifier', text='Modifier', icon='MODIFIER')

def draw_fabularis_root_entry(self, context):
    self.layout.menu('VIEW3D_MT_fabularis_mac_root', text='Fabularis Tools', icon='TOOL_SETTINGS')

def draw_native_modifier_entry(self, context):
    self.layout.operator('object.mac_add_modifier', text='Multi Array Cloner', icon='MOD_ARRAY')

classes=(MAC_Source,MAC_Layer,MAC_Settings,MAC_OT_create,MAC_OT_add_modifier,MAC_OT_source_add,MAC_OT_source_remove,MAC_OT_source_move,MAC_OT_layer_add,MAC_OT_layer_remove,MAC_OT_insert_keyframes,MAC_OT_refresh,MAC_OT_apply,MAC_PT_modifier,MAC_PT_sidebar,VIEW3D_MT_fabularis_modifier,VIEW3D_MT_fabularis_mac_root)
def register():
    global _INTEGRATED_MENU, _MODIFIER_ADD_MENU
    _INTEGRATED_MENU=find_fabularis_menu()
    _MODIFIER_ADD_MENU=getattr(bpy.types,'OBJECT_MT_modifier_add',None)
    for cls in classes:bpy.utils.register_class(cls)
    bpy.types.Object.mac_settings=PointerProperty(type=MAC_Settings)
    if _INTEGRATED_MENU is not None:
        _INTEGRATED_MENU.append(draw_modifier_entry)
    else:
        bpy.types.VIEW3D_MT_add.append(draw_fabularis_root_entry)
    if _MODIFIER_ADD_MENU is not None:
        _MODIFIER_ADD_MENU.append(draw_native_modifier_entry)
    if mac_frame_change not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(mac_frame_change)
def unregister():
    global _INTEGRATED_MENU, _MODIFIER_ADD_MENU
    if _MODIFIER_ADD_MENU is not None:
        _MODIFIER_ADD_MENU.remove(draw_native_modifier_entry)
    if _INTEGRATED_MENU is not None:
        _INTEGRATED_MENU.remove(draw_modifier_entry)
    else:
        bpy.types.VIEW3D_MT_add.remove(draw_fabularis_root_entry)
    if mac_frame_change in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(mac_frame_change)
    del bpy.types.Object.mac_settings
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
    _INTEGRATED_MENU=None
_MODIFIER_ADD_MENU=None
if __name__=='__main__':register()
