bl_info = {
    "name": "Fabularis Tools",
    "author": "Fabularis Lab",
    "version": (1, 3, 3),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Fabularis Tools",
    "description": "Raccolta di strumenti personalizzati Fabularis Lab",
    "category": "3D View",
}


from . import material_gallery
from . import material_add
from . import collection_to_empty
from . import empty_to_collection
from . import collection_parent_finder
from . import uv_tools
from . import preferences
from . import sections
from . import integrated_holes
from . import integrated_remesher
from . import integrated_quick_render
from . import integrated_uv_packer
from . import integrated_clone_manager
from . import integrated_multi_array
from . import integrated_scatter
from . import integrated_quick_group


modules = (
    preferences,
    sections,
    material_gallery,
    material_add,
    collection_to_empty,
    empty_to_collection,
    collection_parent_finder,
    uv_tools,
    integrated_holes,
    integrated_remesher,
    integrated_quick_render,
    integrated_uv_packer,
    integrated_clone_manager,
    integrated_multi_array,
    integrated_scatter,
    integrated_quick_group,
)


def register():

    for module in modules:
        module.register()


def unregister():

    for module in reversed(modules):
        module.unregister()
