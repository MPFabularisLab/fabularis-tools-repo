bl_info = {
    "name": "Quick Group (stile Cinema 4D)",
    "author": "Claude",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "3D Viewport > Object > Quick Group  |  Ctrl+Alt+G",
    "description": "Raggruppa gli oggetti selezionati sotto un Empty (nullo) con una shortcut, come Alt+G in Cinema 4D",
    "category": "Object",
}

import bpy
from mathutils import Matrix, Vector

# ---------------------------------------------------------------------------
# SHORTCUT: cambia qui se vuoi altri tasti
# (Alt+G in Blender e' gia' "Clear Location", per questo uso Ctrl+Alt+G)
# ---------------------------------------------------------------------------
GROUP_KEY = {"type": "G", "value": "PRESS", "ctrl": True, "alt": True}
UNGROUP_KEY = {"type": "G", "value": "PRESS", "ctrl": True, "alt": True, "shift": True}


def top_level_objects(objs):
    """Ritorna solo gli oggetti il cui antenato NON e' a sua volta selezionato."""
    selected = set(objs)
    result = []
    for o in objs:
        p = o.parent
        has_selected_ancestor = False
        while p:
            if p in selected:
                has_selected_ancestor = True
                break
            p = p.parent
        if not has_selected_ancestor:
            result.append(o)
    return result


class OBJECT_OT_quick_group(bpy.types.Operator):
    """Raggruppa gli oggetti selezionati sotto un nuovo Empty"""
    bl_idname = "object.quick_group"
    bl_label = "Quick Group"
    bl_options = {"REGISTER", "UNDO"}

    name: bpy.props.StringProperty(name="Nome", default="Group")
    pivot: bpy.props.EnumProperty(
        name="Posizione nullo",
        items=[
            ("CENTER", "Centro selezione", "Centro del bounding box delle origini degli oggetti"),
            ("ACTIVE", "Oggetto attivo", "Posiziona il nullo sull'origine dell'oggetto attivo"),
            ("ORIGIN", "Origine mondo", "Posiziona il nullo in (0, 0, 0)"),
        ],
        default="CENTER",
    )
    display_type: bpy.props.EnumProperty(
        name="Forma",
        items=[
            ("PLAIN_AXES", "Assi", ""),
            ("ARROWS", "Frecce", ""),
            ("CUBE", "Cubo", ""),
            ("SPHERE", "Sfera", ""),
            ("CIRCLE", "Cerchio", ""),
        ],
        default="PLAIN_AXES",
    )
    size: bpy.props.FloatProperty(name="Dimensione", default=0.05, min=0.001, unit="LENGTH")

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and len(context.selected_objects) > 0

    def execute(self, context):
        selected = list(context.selected_objects)
        roots = top_level_objects(selected)
        if not roots:
            self.report({"WARNING"}, "Nessun oggetto da raggruppare")
            return {"CANCELLED"}

        # --- posizione del nullo ---
        locs = [o.matrix_world.translation.copy() for o in roots]
        if self.pivot == "CENTER":
            mn = Vector((min(v.x for v in locs), min(v.y for v in locs), min(v.z for v in locs)))
            mx = Vector((max(v.x for v in locs), max(v.y for v in locs), max(v.z for v in locs)))
            pos = (mn + mx) / 2
        elif self.pivot == "ACTIVE" and context.active_object:
            pos = context.active_object.matrix_world.translation.copy()
        else:
            pos = Vector((0, 0, 0))

        # --- crea l'empty nella collezione dell'oggetto attivo ---
        empty = bpy.data.objects.new(self.name, None)
        empty.empty_display_type = self.display_type
        empty.empty_display_size = self.size

        act = context.active_object
        if act and act in roots and act.users_collection:
            coll = act.users_collection[0]
        else:
            coll = roots[0].users_collection[0] if roots[0].users_collection else context.collection
        coll.objects.link(empty)

        # --- se tutti i root condividono lo stesso genitore, il nullo lo eredita ---
        parents = {o.parent for o in roots}
        common_parent = parents.pop() if len(parents) == 1 else None
        if common_parent:
            empty.parent = common_parent
            empty.matrix_parent_inverse = common_parent.matrix_world.inverted()
        empty.matrix_world = Matrix.Translation(pos)
        context.view_layer.update()

        # --- parenting mantenendo la trasformazione globale ---
        inv = empty.matrix_world.inverted()
        for o in roots:
            mw = o.matrix_world.copy()
            o.parent = empty
            o.matrix_parent_inverse = inv
            o.matrix_world = mw

        # --- selezione: resta selezionato solo il nullo ---
        for o in selected:
            o.select_set(False)
        empty.select_set(True)
        context.view_layer.objects.active = empty

        self.report({"INFO"}, f"{len(roots)} oggetti raggruppati in '{empty.name}'")
        return {"FINISHED"}

    def invoke(self, context, event):
        result = self.execute(context)
        # Apre subito il pannello per rinominare il nullo (come in C4D)
        if result == {"FINISHED"}:
            try:
                bpy.ops.wm.call_panel("INVOKE_DEFAULT", name="TOPBAR_PT_name")
            except Exception:
                pass
        return result


class OBJECT_OT_quick_ungroup(bpy.types.Operator):
    """Scioglie il gruppo: elimina l'Empty selezionato e libera i figli mantenendo la posizione"""
    bl_idname = "object.quick_ungroup"
    bl_label = "Quick Ungroup"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and any(
            o.type == "EMPTY" for o in context.selected_objects
        )

    def execute(self, context):
        empties = [o for o in context.selected_objects if o.type == "EMPTY"]
        freed = []
        for e in empties:
            new_parent = e.parent
            for child in list(e.children):
                mw = child.matrix_world.copy()
                child.parent = new_parent
                if new_parent:
                    child.matrix_parent_inverse = new_parent.matrix_world.inverted()
                else:
                    child.matrix_parent_inverse = Matrix.Identity(4)
                child.matrix_world = mw
                freed.append(child)
            bpy.data.objects.remove(e, do_unlink=True)

        for o in freed:
            o.select_set(True)
        if freed:
            context.view_layer.objects.active = freed[0]

        self.report({"INFO"}, f"{len(empties)} gruppo/i sciolto/i")
        return {"FINISHED"}


class FABULARIS_PT_quick_group(bpy.types.Panel):
    bl_label = "Quick Group"
    bl_idname = "FABULARIS_PT_quick_group"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fabularis Tools"
    bl_parent_id = "FABULARIS_SECTION_COLLECTIONS"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_quick_group")


    def draw(self, context):
        col = self.layout.column(align=True)
        col.operator(OBJECT_OT_quick_group.bl_idname, text="Raggruppa in un Empty", icon="OUTLINER_OB_EMPTY")
        col.operator(OBJECT_OT_quick_ungroup.bl_idname, text="Sciogli gruppo", icon="UNLINKED")


def menu_func(self, context):
    self.layout.separator()
    self.layout.operator(OBJECT_OT_quick_group.bl_idname, text="Quick Group", icon="OUTLINER_OB_EMPTY")
    self.layout.operator(OBJECT_OT_quick_ungroup.bl_idname, text="Quick Ungroup")


def outliner_menu_func(self, context):
    self.layout.separator()
    self.layout.operator(OBJECT_OT_quick_group.bl_idname, text="Quick Group", icon="OUTLINER_OB_EMPTY")
    self.layout.operator(OBJECT_OT_quick_ungroup.bl_idname, text="Quick Ungroup")


addon_keymaps = []
classes = (OBJECT_OT_quick_group, OBJECT_OT_quick_ungroup, FABULARIS_PT_quick_group)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.VIEW3D_MT_object.append(menu_func)
    bpy.types.VIEW3D_MT_object_context_menu.append(menu_func)
    bpy.types.OUTLINER_MT_object.append(outliner_menu_func)

    wm = bpy.context.window_manager
    if wm.keyconfigs.addon:
        km = wm.keyconfigs.addon.keymaps.new(name="Object Mode", space_type="EMPTY")
        kmi = km.keymap_items.new(OBJECT_OT_quick_group.bl_idname, **GROUP_KEY)
        addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new(OBJECT_OT_quick_ungroup.bl_idname, **UNGROUP_KEY)
        addon_keymaps.append((km, kmi))


def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.types.VIEW3D_MT_object.remove(menu_func)
    bpy.types.VIEW3D_MT_object_context_menu.remove(menu_func)
    bpy.types.OUTLINER_MT_object.remove(outliner_menu_func)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
