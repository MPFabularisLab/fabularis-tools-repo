bl_info = {'name': 'Fabularis — Remesher', 'author': 'Fabularis Lab',
           'version': (0, 3, 14), 'blender': (5, 1, 0), 'category': 'Mesh'}

import traceback
import json
import math
import re
from contextlib import contextmanager
from functools import wraps
from . import primitives, parts, interior
from mathutils import Matrix
import bpy
from bpy.props import PointerProperty, CollectionProperty, FloatProperty, IntProperty, StringProperty, EnumProperty, BoolProperty

REPORT = 'Fabularis_Remesher_Report'
MODIFIER = 'Fabularis — Remesher'
_UPDATING = False


def release_edit_view(entry):
    obj = entry.object
    mesh = entry.edit_mesh
    if obj and mesh and obj.data == mesh and entry.edit_source:
        obj.data = entry.edit_source
        for uid, viewport, render in json.loads(entry.edit_visibility or '[]'):
            modifier = next((m for m in obj.modifiers if m.persistent_uid == uid), None)
            if modifier:
                modifier.show_viewport, modifier.show_render = viewport, render
    entry.edit_mesh = None
    entry.edit_source = None
    entry.edit_visibility = ''
    if mesh and mesh.users == 0:
        bpy.data.meshes.remove(mesh)


def bake_edit_views(state, objects, context):
    if state.method == 'PARTS':
        return
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    pending = []
    try:
        # Evaluate all inputs before changing objects used by other modifiers.
        for entry in state.targets:
            if entry.object in objects and not entry.error and effective_quality(entry, state) < 100:
                mesh = bpy.data.meshes.new_from_object(entry.object.evaluated_get(depsgraph),
                    preserve_all_data_layers=True, depsgraph=depsgraph)
                mesh.name = 'Fabularis — Topologia anteprima'
                pending.append((entry, mesh))
        for entry, mesh in pending:
            entry.edit_source = entry.object.data
            entry.edit_visibility = json.dumps([(m.persistent_uid, m.show_viewport, m.show_render)
                                                for m in entry.object.modifiers])
            entry.edit_mesh = mesh
            entry.object.data = mesh
            for modifier in entry.object.modifiers:
                modifier.show_viewport = modifier.show_render = False
    except Exception:
        for entry, mesh in pending:
            if entry.edit_mesh == mesh:
                release_edit_view(entry)
            elif mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        raise


@contextmanager
def preview_context(context):
    was_edit = context.mode == 'EDIT_MESH'
    objects = tuple(context.objects_in_mode) if was_edit else ()
    active = context.view_layer.objects.active
    select_mode = tuple(context.tool_settings.mesh_select_mode)
    if was_edit:
        bpy.ops.object.mode_set(mode='OBJECT')  # Flush edit BMeshes before evaluating/replacing data.
    try:
        for entry in context.scene.fab_remesh.targets:
            release_edit_view(entry)
        yield
    finally:
        if was_edit:
            try:
                bake_edit_views(context.scene.fab_remesh, objects, context)
            finally:
                for obj in list(context.selected_objects):
                    obj.select_set(False)
                surviving = [obj for obj in objects if obj.name in context.view_layer.objects]
                for obj in surviving:
                    obj.select_set(True)
                if surviving:
                    context.view_layer.objects.active = active if active in surviving else surviving[0]
                    context.tool_settings.mesh_select_mode = select_mode
                    bpy.ops.object.mode_set(mode='EDIT')
                    # Selected result edges make the rebuilt topology visible.
                    if context.scene.fab_remesh.targets:
                        bpy.ops.mesh.select_all(action='SELECT')


def supports_edit(function):
    @wraps(function)
    def execute(self, context):
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            self.report({'WARNING'}, 'Usa la modalità Oggetto o Modifica mesh')
            return {'CANCELLED'}
        with preview_context(context):
            return function(self, context)
    return execute


def triangle_count(mesh):
    mesh.calc_loop_triangles()
    return len(mesh.loop_triangles)


def result_name(name):
    """Remove the imported Finito suffix, keeping Blender duplicate numbers."""
    return re.sub(r'(?i)[ _-]+finito(?=(?:\.\d{3})?$)','',name) or name


def selected_meshes(context):
    """Explicit meshes and visible mesh descendants of selected hierarchy roots."""
    result=[];seen=set()
    for selected in context.selected_objects:
        candidates=(selected,) if selected.type=='MESH' else (
            selected.children_recursive if selected.type=='EMPTY' else ())
        for obj in candidates:
            if obj.type!='MESH' or obj in seen:continue
            if obj is not selected and (obj.name not in context.view_layer.objects
                    or not obj.visible_get(view_layer=context.view_layer) or obj.hide_select):continue
            seen.add(obj);result.append(obj)
    return result


@contextmanager
def original_inputs(state,context):
    """Count new targets against original dependencies, not existing previews."""
    snapshots=[]
    try:
        for entry in state.targets:
            obj=entry.object
            if not obj:continue
            snapshots.append((obj,obj.data,[(m,m.show_viewport,m.show_render) for m in obj.modifiers]))
            restore_base(entry)
            for modifier in (owned_modifier(entry),owned_proxy(entry)):
                if modifier:modifier.show_viewport=modifier.show_render=False
        context.view_layer.update()
        yield context.evaluated_depsgraph_get()
    finally:
        for obj,mesh,modifiers in snapshots:
            obj.data=mesh
            for modifier,viewport,render in modifiers:
                modifier.show_viewport=viewport;modifier.show_render=render
        if snapshots:context.view_layer.update()


def evaluated_triangles(obj, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        return triangle_count(mesh)
    finally:
        evaluated.to_mesh_clear()


def owned_modifier(entry):
    obj = entry.object
    if obj:
        return next((m for m in obj.modifiers
                     if m.type == 'DECIMATE' and m.persistent_uid == entry.modifier_uid), None)
    return None


def owned_proxy(entry):
    if entry.object:
        return next((m for m in entry.object.modifiers if m.type == 'NODES'
                     and m.persistent_uid == entry.proxy_uid), None)
    return None


def prepare_fits(state, context):
    missing = [entry for entry in state.targets if entry.object and not entry.fit_json]
    if not missing:
        return
    visibility = []
    try:
        for entry in state.targets:
            for modifier in (owned_modifier(entry), owned_proxy(entry)):
                if modifier:
                    visibility.append((modifier, modifier.show_viewport, modifier.show_render))
                    modifier.show_viewport = modifier.show_render = False
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        for entry in missing:
            evaluated = entry.object.evaluated_get(depsgraph)
            mesh = evaluated.to_mesh()
            try:
                result = primitives.fit(mesh, entry.object.matrix_world.to_3x3())
                entry.fit_json = json.dumps(result)
                if mesh.materials:
                    areas = {}
                    for face in mesh.polygons:
                        areas[face.material_index] = areas.get(face.material_index, 0) + face.area
                    index = max(areas, key=areas.get) if areas else 0
                    if index < len(mesh.materials):
                        material = mesh.materials[index]
                        entry.proxy_material = material.original if material else None
            except Exception as exc:
                entry.fit_json = json.dumps({'auto': 'NONE', 'box': None, 'cylinder': None})
                entry.fit_note = str(exc)
            finally:
                evaluated.to_mesh_clear()
    finally:
        for modifier, viewport, render in visibility:
            modifier.show_viewport, modifier.show_render = viewport, render


def clear_proxy(entry):
    modifier = owned_proxy(entry)
    if modifier:
        entry.object.modifiers.remove(modifier)
    group = entry.proxy_group
    entry.proxy_group = None
    entry.proxy_uid = 0
    entry.proxy_kind = ''
    if group and group.users == 0:
        bpy.data.node_groups.remove(group)


def restore_base(entry):
    obj = entry.object
    if obj and entry.base_mesh:
        if entry.part_mesh and obj.data == entry.part_mesh:
            obj.data = entry.base_mesh
        for uid, viewport, render in json.loads(entry.mod_visibility or '[]'):
            modifier = next((m for m in obj.modifiers if m.persistent_uid == uid), None)
            if modifier:
                modifier.show_viewport, modifier.show_render = viewport, render


def clear_parts(entry):
    release_edit_view(entry)
    restore_base(entry)
    for field in ('part_mesh', 'input_mesh'):
        mesh = getattr(entry, field)
        setattr(entry, field, None)
        if mesh and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    entry.base_mesh = None
    entry.part_analysis = ''
    entry.part_stats = ''
    entry.parts_linear = ''
    entry.mod_visibility = ''


def prepare_parts(state, context):
    missing = [e for e in state.targets if e.object and not e.input_mesh]
    if not missing:
        return
    visibility = []
    try:
        for entry in state.targets:
            for modifier in (owned_modifier(entry), owned_proxy(entry)):
                if modifier:
                    visibility.append((modifier, modifier.show_viewport, modifier.show_render))
                    modifier.show_viewport = modifier.show_render = False
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        for entry in missing:
            entry.base_mesh = entry.object.data
            entry.parts_linear = json.dumps([list(row) for row in entry.object.matrix_world.to_3x3()])
            entry.mod_visibility = json.dumps([(m.persistent_uid, m.show_viewport, m.show_render)
                for m in entry.object.modifiers if m not in (owned_modifier(entry), owned_proxy(entry))])
            entry.input_mesh = bpy.data.meshes.new_from_object(entry.object.evaluated_get(depsgraph),
                preserve_all_data_layers=True, depsgraph=depsgraph)
            entry.input_mesh.name = 'Fabularis — Input anteprima'
    finally:
        for modifier, viewport, render in visibility:
            modifier.show_viewport, modifier.show_render = viewport, render


def effective_quality(entry, state):
    return entry.local_quality if entry.use_local_quality else state.quality


def scan_parts(state,context):
    """Analyze every preserved input before constructing any preview."""
    pending=[e for e in state.targets if e.object and e.input_mesh and effective_quality(e, state)<100 and
        (not e.part_analysis or e.parts_revision!=313)]
    if not pending:return
    wm=context.window_manager;wm.progress_begin(0,len(pending))
    try:
        for i,entry in enumerate(pending):
            try:
                linear=Matrix(json.loads(entry.parts_linear))
                entry.part_analysis=json.dumps(parts.analyze(entry.input_mesh,linear))
                entry.parts_revision=313
            except Exception as exc:entry.error=str(exc)
            wm.progress_update(i+1)
    finally:wm.progress_end()


def write_report(lines):
    report = bpy.data.texts.get(REPORT) or bpy.data.texts.new(REPORT)
    report.clear()
    report.write('\n'.join(lines))


def set_quality(entry, quality):
    modifier = owned_modifier(entry)
    if modifier is None:
        raise ValueError('Anteprima rimossa manualmente; usa Ripristina per terminare la sessione')
    state = entry.id_data.fab_remesh
    proxy = owned_proxy(entry)
    if proxy:
        proxy.show_viewport = proxy.show_render = False
    modifier.show_viewport = modifier.show_render = False
    if state.method == 'PARTS':
        if quality >= 100 or not entry.input_mesh:
            return
        linear = Matrix(json.loads(entry.parts_linear))
        if not entry.part_analysis or entry.parts_revision != 313:
            entry.part_analysis = json.dumps(parts.analyze(entry.input_mesh, linear))
            entry.parts_revision = 313
        analysis = json.loads(entry.part_analysis)
        result, stats = parts.build(entry.input_mesh, analysis, quality,
                                    linear, bpy.context, stepped=True)
        cleaned,cleanup_stats=interior.clean(result,linear)
        if cleaned is not result:
            try:
                finished=parts.finish_normals(cleaned,bpy.context)
                finished['_fab_profile_seeds']=cleaned.get('_fab_profile_seeds','[]')
            finally:
                bpy.data.meshes.remove(cleaned)
            bpy.data.meshes.remove(result)
            result=finished
        stats.update(cleanup_stats)
        entry.part_analysis = json.dumps(analysis)
        previous_mesh = entry.part_mesh
        clean_name=result_name(entry.object.name)
        if clean_name!=entry.object.name:entry.object.name=clean_name
        result.name=entry.object.name
        entry.object.data = result
        entry.part_mesh = result
        entry.part_stats = json.dumps(stats)
        if previous_mesh and previous_mesh.users == 0:
            bpy.data.meshes.remove(previous_mesh)
        # The preview is built from the evaluated input; do not run the user's
        # stack a second time on its baked result. Visibility is restored on exit.
        for item in entry.object.modifiers:
            item.show_viewport = item.show_render = False
        return
    if state.method == 'SIMPLIFY':
        modifier.ratio = max(quality / 100, min(1.0, 12 / max(1, entry.before)))
        modifier.show_viewport = modifier.show_render = quality < 100
        return
    if quality >= 100 or not entry.fit_json:
        return
    data = json.loads(entry.fit_json)
    selected = primitives.chosen_fit(data, state.primitive)
    if selected is None:
        return  # Ambiguous objects keep their complete input geometry.
    segments = 4 * math.ceil((12 + quality * .36) / 4)
    segments = max(3, min(segments, (entry.before + 4) // 4))
    if proxy is None or entry.proxy_kind != selected['kind']:
        clear_proxy(entry)
        group = primitives.make_group(data, selected, segments, entry.proxy_material)
        try:
            proxy = entry.object.modifiers.new('Fabularis — Forma semplice', 'NODES')
            proxy.node_group = group
            proxy.show_expanded = False
            proxy.show_in_editmode = True
            entry.proxy_uid = proxy.persistent_uid
            entry.proxy_group = group
            entry.proxy_kind = selected['kind']
        except Exception:
            if group.users == 0:
                bpy.data.node_groups.remove(group)
            raise
    elif selected['kind'] == 'CYLINDER':
        node = next(n for n in entry.proxy_group.nodes if n.bl_idname == 'GeometryNodeMeshCylinder')
        node.inputs['Vertices'].default_value = segments
    proxy.show_viewport = proxy.show_render = True


def refresh(state, context, entries=None):
    affected = list(state.targets) if entries is None else list(entries)
    for entry in affected:
        entry.error = ''
    # Analyze original dependencies without replacing unrelated preview meshes.
    with original_inputs(state, context):
        if state.method == 'PARTS':
            prepare_parts(state, context)
            scan_parts(state, context)
        if state.method == 'PRIMITIVES':
            prepare_fits(state, context)
    for entry in affected:
        restore_base(entry)
        if entry.error:
            continue
        try:
            if entry.object is None:
                raise ValueError('Oggetto rimosso dalla scena')
            set_quality(entry, effective_quality(entry, state))
        except Exception as exc:
            entry.error = str(exc)
    update_totals(state, context)


def update_totals(state, context):
    """Count/report current previews without rebuilding any geometry."""
    lines = [f'Qualità generale: {state.quality:g}%; metodo: {state.method}']
    errors = before = after = changed = 0
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    for entry in state.targets:
        name = entry.object.name if entry.object else '(rimosso)'
        if not entry.error:
            try:
                entry.after = evaluated_triangles(entry.object, depsgraph)
            except Exception as exc:
                entry.error = str(exc)
        if entry.error:
            errors += 1
            lines.append(f'{name}: {entry.error}')
        else:
            before += entry.before
            after += entry.after
            changed += entry.after < entry.before
            detail = ''
            if state.method == 'PARTS' and entry.part_stats:
                stats = json.loads(entry.part_stats)
                detail = f'; parti {stats["parts"]}, profili assiali {stats["profiles"]}, parallelepipedi {stats["boxes"]}, forme conservate/ridotte {stats["details"]}'
            if state.method == 'PRIMITIVES':
                data = json.loads(entry.fit_json) if entry.fit_json else {'auto': 'NONE'}
                kind = data['auto'] if state.primitive == 'AUTO' else state.primitive
                detail = f'; forma {kind}'
                if kind == 'NONE':
                    detail += '; conservato originale (forma non riconosciuta)'
                if entry.fit_note:
                    detail += '; ' + entry.fit_note
            local = f'; qualità personale {entry.local_quality:g}%' if entry.use_local_quality else ''
            lines.append(f'{name}: {entry.before} → {entry.after} triangoli{local}{detail}')
    state.before = before
    state.after = after
    state.changed = changed
    state.message = f'Errori: {errors}. Vedi dettagli.' if errors else ''
    if not errors and state.method == 'PARTS':
        count = sum(json.loads(e.part_stats).get('parts', 0) for e in state.targets if e.part_stats)
        state.message = f'Parti analizzate: {count}.'
    if not errors and state.method == 'PRIMITIVES' and state.primitive == 'AUTO':
        recognized = sum(bool(e.fit_json) and json.loads(e.fit_json)['auto'] != 'NONE' for e in state.targets)
        state.message = f'Forme riconosciute: {recognized}/{len(state.targets)}.'
    lines.append(f'Oggetti ridotti: {changed}; errori: {errors}')
    write_report(lines)


def quality_changed(self, context):
    global _UPDATING
    if self.targets and context is not None and context.mode in {'OBJECT', 'EDIT_MESH'} and not _UPDATING:
        _UPDATING = True
        try:
            with preview_context(context):
                refresh(self, context)
        except Exception as exc:
            self.message = f'Anteprima non aggiornata: {exc}'
            write_report([self.message, traceback.format_exc()])
        finally:
            _UPDATING = False


class FABREMESH_Target(bpy.types.PropertyGroup):
    object: PointerProperty(type=bpy.types.Object)
    modifier_uid: IntProperty()
    before: IntProperty()
    after: IntProperty()
    error: StringProperty()
    use_local_quality: BoolProperty(default=False)
    local_quality: FloatProperty(default=70, min=1, max=100, precision=1)
    fit_json: StringProperty()
    fit_note: StringProperty()
    proxy_uid: IntProperty()
    proxy_group: PointerProperty(type=bpy.types.NodeTree)
    proxy_material: PointerProperty(type=bpy.types.Material)
    proxy_kind: StringProperty()
    base_mesh: PointerProperty(type=bpy.types.Mesh)
    input_mesh: PointerProperty(type=bpy.types.Mesh)
    part_mesh: PointerProperty(type=bpy.types.Mesh)
    part_analysis: StringProperty()
    parts_revision: IntProperty(default=0)
    part_stats: StringProperty()
    mod_visibility: StringProperty()
    parts_linear: StringProperty()
    edit_mesh: PointerProperty(type=bpy.types.Mesh)
    edit_source: PointerProperty(type=bpy.types.Mesh)
    edit_visibility: StringProperty()


class FABREMESH_Settings(bpy.types.PropertyGroup):
    method: EnumProperty(name='Metodo', default='PARTS', update=quality_changed,
                         items=[('PARTS', 'Forme composte', 'Analizza separatamente le parti della mesh; ricostruisce profili assiali e conserva le forme complesse'),
                                ('SIMPLIFY', 'Riduci poligoni', 'Decimazione della geometria originale'),
                                ('PRIMITIVES', 'Forme semplici', 'Ricostruisce primitive pulite, senza decimare i pezzi non riconosciuti')])
    primitive: EnumProperty(name='Forma', default='AUTO', update=quality_changed,
                            items=[('AUTO', 'Automatica', 'Sceglie cilindro o parallelepipedo solo per forme riconosciute; altrimenti conserva l’originale'),
                                   ('CYLINDER', 'Cilindro', 'Forza un cilindro sull’intero oggetto, eliminando i dettagli'),
                                   ('BOX', 'Parallelepipedo', 'Forza un parallelepipedo sull’intero oggetto, riempiendo anche concavità e spazi vuoti')])
    quality: FloatProperty(name='Qualità (%)', default=70, min=1, max=100,
                           precision=1, update=quality_changed,
                           description='100 = originale. Forme composte: 75–99 Dettagli, 50–74 Pulito, 25–49 Volumi, 1–24 Essenziale. Riduci poligoni controlla il rapporto di triangoli; Forme semplici i lati dei cilindri')
    targets: CollectionProperty(type=FABREMESH_Target)
    selected_quality: FloatProperty(name='Dettaglio selezionati (%)', default=70, min=1, max=100,
        precision=1, description='Percentuale personale da applicare solo alle mesh selezionate già in anteprima. 100 = originale')
    before: IntProperty()
    after: IntProperty()
    changed: IntProperty()
    message: StringProperty()


def select_results(context, state):
    previous = context.view_layer.objects.active
    targets = [e.object for e in state.targets if e.object and not e.error
               and e.after < e.before and e.object.name in context.view_layer.objects
               and not e.object.hide_get() and not e.object.hide_select]
    for obj in list(context.selected_objects):
        obj.select_set(False)
    for obj in targets:
        obj.select_set(True)
    context.view_layer.objects.active = previous if previous in targets else targets[0] if targets else None


class FABREMESH_OT_start(bpy.types.Operator):
    bl_idname = 'fab_remesh.start'
    bl_label = 'Ottimizza selezionati'
    bl_description = 'Ottimizza le mesh selezionate e i figli visibili degli Empty selezionati. Aggiunge le nuove mesh a un’anteprima già attiva'
    bl_options = {'REGISTER', 'UNDO'}

    @supports_edit
    def execute(self, context):
        state = context.scene.fab_remesh
        if context.mode != 'OBJECT':
            self.report({'WARNING'}, 'Passa alla modalità Oggetto')
            return {'CANCELLED'}
        sources = selected_meshes(context)
        if not sources:
            self.report({'WARNING'}, 'Seleziona una o più mesh oppure il loro Empty padre')
            return {'CANCELLED'}
        existing={e.object for e in state.targets if e.object}
        sources=[o for o in sources if o not in existing]
        if not sources:
            self.report({'INFO'}, 'Le mesh selezionate sono già tutte in anteprima')
            return {'CANCELLED'}
        logs = []
        # Count every original before adding modifiers, including objects used
        # by Boolean dependencies elsewhere in the selection.
        candidates = []
        with original_inputs(state,context) as depsgraph:
            for obj in sources:
                try:
                    if not obj.is_editable or not obj.data.is_editable:
                        raise ValueError('oggetto collegato non modificabile')
                    if obj.data.shape_keys or obj.animation_data or any(m.type == 'ARMATURE' for m in obj.modifiers):
                        raise ValueError('oggetto animato / armatura / shape key')
                    if any(e.object == obj for scene in bpy.data.scenes for e in scene.fab_remesh.targets):
                        raise ValueError('anteprima già attiva in un’altra scena')
                    count = evaluated_triangles(obj, depsgraph)
                    if count <= 12:
                        raise ValueError('mesh già molto semplice (12 triangoli o meno)')
                    candidates.append((obj, count))
                except Exception as exc:
                    logs.append(f'{obj.name}: ignorato, {exc}')
        added=0
        for obj, count in candidates:
            modifier = None
            entry = None
            try:
                modifier = obj.modifiers.new(MODIFIER, 'DECIMATE')
                modifier.decimate_type = 'COLLAPSE'
                modifier.use_collapse_triangulate = False
                modifier.show_expanded = False
                modifier.show_in_editmode = True
                entry = state.targets.add()
                entry.object = obj
                entry.modifier_uid = modifier.persistent_uid
                entry.before = count
                entry.after = count
                set_quality(entry, state.quality)
                added+=1
            except Exception as exc:
                if modifier:
                    obj.modifiers.remove(modifier)
                if entry is not None:
                    state.targets.remove(len(state.targets) - 1)
                logs.append(f'{obj.name}: errore, {exc}')
        if not added:
            state.message = 'Nessuna nuova mesh aggiunta. Vedi dettagli.' if existing else 'Nessuna mesh da ottimizzare. Vedi dettagli.'
            write_report(logs)
            self.report({'WARNING'}, state.message)
            return {'CANCELLED'}
        refresh(state, context)
        if logs:
            bpy.data.texts[REPORT].write('\n' + '\n'.join(logs))
            state.message = f'Oggetti ignorati: {len(logs)}. Vedi dettagli.'
        select_results(context, state)
        self.report({'INFO'}, f'Anteprima attiva su {len(state.targets)} mesh')
        return {'FINISHED'}


class FABREMESH_OT_restore(bpy.types.Operator):
    bl_idname = 'fab_remesh.restore'
    bl_label = 'Ripristina originale'
    bl_description = 'Rimuove solo l’anteprima Fabularis e termina la sessione, mantenendo tutti gli altri modifier'
    bl_options = {'REGISTER', 'UNDO'}

    @supports_edit
    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'WARNING'}, 'Passa alla modalità Oggetto')
            return {'CANCELLED'}
        state = context.scene.fab_remesh
        restored = 0
        for entry in state.targets:
            clear_parts(entry)
            clear_proxy(entry)
            modifier = owned_modifier(entry)
            if modifier:
                entry.object.modifiers.remove(modifier)
                restored += 1
        state.targets.clear()
        state.before = state.after = state.changed = 0
        state.message = ''
        context.view_layer.update()
        write_report([f'Anteprime rimosse: {restored}. Mesh di partenza conservate.'])
        self.report({'INFO'}, 'Geometria originale ripristinata')
        return {'FINISHED'}


class FABREMESH_OT_selected(bpy.types.Operator):
    bl_idname = 'fab_remesh.selected'
    bl_label = 'Applica ai selezionati'
    bl_description = 'Regola o ripristina solo le mesh selezionate già in anteprima, mantenendo gli altri pezzi'
    bl_options = {'REGISTER', 'UNDO'}

    action: EnumProperty(items=[
        ('APPLY', 'Applica ai selezionati', 'Assegna la percentuale personale alle mesh selezionate'),
        ('GENERAL', 'Usa generale', 'Ricollega le mesh selezionate alla percentuale generale'),
        ('RESTORE', 'Ripristina selezionati', 'Ripristina gli originali selezionati e li rimuove dall’anteprima')],
        default='APPLY', options={'SKIP_SAVE'})

    @supports_edit
    def execute(self, context):
        state = context.scene.fab_remesh
        selected = set(selected_meshes(context))
        indices = [i for i, entry in enumerate(state.targets) if entry.object in selected]
        if not indices:
            self.report({'WARNING'}, 'Seleziona almeno una mesh con anteprima attiva')
            return {'CANCELLED'}
        if self.action == 'RESTORE':
            for i in reversed(indices):
                entry = state.targets[i]
                clear_parts(entry)
                clear_proxy(entry)
                modifier = owned_modifier(entry)
                if modifier:
                    entry.object.modifiers.remove(modifier)
                state.targets.remove(i)
            update_totals(state, context)
        else:
            entries = [state.targets[i] for i in indices]
            for entry in entries:
                entry.use_local_quality = self.action == 'APPLY'
                if entry.use_local_quality:
                    entry.local_quality = state.selected_quality
            refresh(state, context, entries)
        self.report({'INFO'}, f'Mesh aggiornate: {len(indices)}')
        return {'FINISHED'}


class FABREMESH_OT_select(bpy.types.Operator):
    bl_idname = 'fab_remesh.select'
    bl_label = 'Seleziona ottimizzati'
    bl_options = {'REGISTER', 'UNDO'}

    @supports_edit
    def execute(self, context):
        if context.mode != 'OBJECT':
            return {'CANCELLED'}
        state = context.scene.fab_remesh
        update_totals(state, context)
        select_results(context, state)
        return {'FINISHED'}


class FABREMESH_OT_report(bpy.types.Operator):
    bl_idname = 'fab_remesh.copy_report'
    bl_label = 'Copia dettagli'

    def execute(self, context):
        report = bpy.data.texts.get(REPORT)
        context.window_manager.clipboard = report.as_string() if report else ''
        return {'FINISHED'}


class FABREMESH_PT_panel(bpy.types.Panel):
    bl_label = 'Remesher'
    bl_idname = 'FABREMESH_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Fabularis Tools'
    bl_parent_id = 'FABULARIS_SECTION_OPTIMIZATION'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_remesher")


    def draw(self, context):
        layout = self.layout
        layout.use_property_decorate = False
        state = context.scene.fab_remesh
        controls = layout.column()
        controls.enabled = context.mode in {'OBJECT', 'EDIT_MESH'}
        controls.prop(state, 'method', text='Metodo')
        if state.method == 'PRIMITIVES':
            controls.prop(state, 'primitive', text='Forma')
        controls.prop(state, 'quality', text='Generale (%)', slider=True)
        if state.method == 'PARTS':
            controls.label(text=parts.detail_stage(state.quality)[0])
        elif state.method != 'SIMPLIFY':
            controls.label(text='100% = originale', icon='INFO')
        if state.targets:
            controls.label(text=f'Anteprima: {len(state.targets)} mesh')
            existing={e.object for e in state.targets if e.object}
            pending=sum(o not in existing for o in selected_meshes(context))
            add=controls.row();add.enabled=bool(pending)
            add.operator('fab_remesh.start',text=f'Aggiungi selezionate ({pending})',icon='ADD')
            selected = set(selected_meshes(context))
            entries = [e for e in state.targets if e.object in selected]
            local = controls.box()
            local.enabled = bool(entries)
            local.label(text=f'Solo selezionati: {len(entries)} mesh')
            if entries:
                values = {round(effective_quality(e, state), 1) for e in entries}
                current = f'{next(iter(values)):g}%' if len(values) == 1 else 'Valori diversi'
                local.label(text=f'Attuale: {current}')
            local.prop(state, 'selected_quality', text='Dettaglio (%)', slider=True)
            local.operator('fab_remesh.selected', text='Applica ai selezionati', icon='CHECKMARK').action = 'APPLY'
            local.operator('fab_remesh.selected', text='Usa generale').action = 'GENERAL'
            local.operator('fab_remesh.selected', text='Ripristina selezionati', icon='LOOP_BACK').action = 'RESTORE'
            box = controls.box()
            box.label(text=f'Triangoli: {state.before:,} → {state.after:,}'.replace(',', '.'))
            if state.before:
                box.label(text=f'Riduzione: {100 * (1 - state.after / state.before):.1f}%')
            controls.operator('fab_remesh.select', icon='RESTRICT_SELECT_OFF')
            controls.operator('fab_remesh.restore', text='Ripristina tutto', icon='LOOP_BACK')
        else:
            action = controls.column()
            action.scale_y = 1.3
            count = len(selected_meshes(context))
            action.enabled = bool(count)
            action.operator('fab_remesh.start', icon='MOD_DECIM')
            controls.label(text=f'Mesh selezionate: {count}' if count else 'Seleziona una o più mesh')
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            layout.label(text='Usa Oggetto o Modifica mesh', icon='INFO')
        if state.message:
            layout.label(text=state.message, icon='INFO')


class FABREMESH_PT_details(bpy.types.Panel):
    bl_label = 'Dettagli'
    bl_idname = 'FABREMESH_PT_details'
    bl_parent_id = 'FABREMESH_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Fabularis Tools'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        self.layout.operator('fab_remesh.copy_report', icon='COPYDOWN')


CLASSES = (FABREMESH_Target, FABREMESH_Settings, FABREMESH_OT_start,
           FABREMESH_OT_restore, FABREMESH_OT_selected, FABREMESH_OT_select, FABREMESH_OT_report,
           FABREMESH_PT_panel, FABREMESH_PT_details)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fab_remesh = PointerProperty(type=FABREMESH_Settings)


def unregister():
    # Keep native modifiers and their ID-property session data in saved files.
    # Disabling an extension must not destructively change the user's scene.
    del bpy.types.Scene.fab_remesh
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
