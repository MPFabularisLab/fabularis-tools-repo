"""Geometric proxy fitting; independent implementation, no external binaries.

PCA supplies candidate axes, dominant surface normals supply mechanical axes.
Candidate envelopes are checked against both samples and support directions.
This is whole-object approximation, not semantic part segmentation or RANSAC.
"""
import math
import numpy as np
import bpy
from mathutils import Matrix


def unique_axes(axes, maximum=18):
    result = []
    for axis in axes:
        axis = np.asarray(axis, dtype=float)
        length = np.linalg.norm(axis)
        if length < 1e-10:
            continue
        axis = axis / length
        if not any(abs(np.dot(axis, other)) > .998 for other in result):
            result.append(axis)
        if len(result) >= maximum:
            break
    return result


def frame(axis):
    z = axis / np.linalg.norm(axis)
    ref = np.eye(3)[np.argmin(np.abs(z))]
    x = np.cross(ref, z); x /= np.linalg.norm(x)
    return np.column_stack((x, np.cross(z, x), z))


def supports(points, basis, half, center):
    # Include oblique directions: surface distance alone would accept an L
    # bracket as a box or a thin square plate as a circular disk.
    directions = np.array([(x, y, z) for x in (-1, 0, 1)
                           for y in (-1, 0, 1) for z in (-1, 0, 1)
                           if x or y or z], dtype=float)
    directions /= np.linalg.norm(directions, axis=1)[:, None]
    local = (points - center) @ basis
    actual = np.max(local @ directions.T, axis=0)
    expected = np.abs(directions) @ half
    return np.mean(np.abs(expected - actual))


def fit(mesh, linear):
    coords = np.empty(len(mesh.vertices) * 3)
    mesh.vertices.foreach_get('co', coords)
    points = coords.reshape(-1, 3) @ np.asarray(linear, dtype=float).T
    if len(points) < 4 or not np.isfinite(points).all():
        raise ValueError('Geometria insufficiente o non valida')
    origin = (points.min(axis=0) + points.max(axis=0)) / 2
    points -= origin
    diagonal = np.linalg.norm(np.ptp(points, axis=0))
    if diagonal < 1e-10:
        raise ValueError('Ingombro nullo')
    samples = points[np.linspace(0, len(points) - 1, min(len(points), 4096), dtype=int)]
    _, vectors = np.linalg.eigh(np.cov(samples.T))
    dominant = []
    inverse_normal = np.linalg.inv(np.asarray(linear, dtype=float)).T
    # Dominant face normals stabilize equal-sided boxes, where PCA alone has
    # no unique orientation and may follow triangulation-biased diagonals.
    for face in sorted(mesh.polygons, key=lambda f: f.area, reverse=True)[:2048]:
        n = inverse_normal @ np.asarray(face.normal)
        length = np.linalg.norm(n)
        if length < 1e-12:
            continue
        n /= length
        match = next((item for item in dominant if abs(np.dot(n, item[0])) > .995), None)
        if match is None:
            dominant.append([n, face.area * length])
        else:
            match[1] += face.area * length
    normals = [item[0] for item in sorted(dominant, key=lambda item: item[1], reverse=True)[:8]]
    axes = unique_axes(normals + list(vectors.T) + list(np.asarray(linear).T) + list(np.eye(3)))
    frames = [vectors, np.eye(3)]
    for i, z in enumerate(axes):
        for x in axes[i+1:]:
            if abs(np.dot(x, z)) < .05:
                y = np.cross(z, x); y /= np.linalg.norm(y)
                frames.append(np.column_stack((np.cross(y, z), y, z)))
    best = None
    for basis in frames:
        local = samples @ basis
        lo, hi = local.min(axis=0), local.max(axis=0)
        volume = np.prod(hi - lo)
        if best is None or volume < best[0]:
            best = (volume, basis)
    basis = best[1].copy()
    if np.linalg.det(basis) < 0:
        basis[:, 0] *= -1
    local = points @ basis
    lo, hi = local.min(axis=0), local.max(axis=0)
    half = (hi - lo) / 2
    if half.min() <= diagonal * 1e-7:
        raise ValueError('Forma piatta: servono tre dimensioni non nulle')
    center = basis @ ((hi + lo) / 2)
    distance = np.min(np.abs(np.abs((samples - center) @ basis) - half), axis=1)
    score = 4 * (float(distance.mean()) + supports(samples, basis, half, center)) / diagonal
    box = {'kind': 'BOX', 'basis': basis.tolist(), 'center': (center + origin).tolist(),
           'size': (half * 2).tolist(), 'score': score}
    cylinder = None
    for axis in axes:
        basis = frame(axis)
        local = points @ basis
        lo, hi = local.min(axis=0), local.max(axis=0)
        middle = (lo + hi) / 2
        radial = np.linalg.norm(local[:, :2] - middle[:2], axis=1)
        radius = float(radial.max())
        depth = float(hi[2] - lo[2])
        if min(radius, depth) < diagonal * 1e-7:
            continue
        sample_local = samples @ basis - middle
        radial_error = np.abs(np.linalg.norm(sample_local[:, :2], axis=1) - radius)
        cap_error = np.abs(np.abs(sample_local[:, 2]) - depth / 2)
        surface_error = np.minimum(radial_error, cap_error).mean() / radius
        angles = np.arange(32) * (2 * math.pi / 32)
        directions = np.column_stack((np.cos(angles), np.sin(angles)))
        outline = np.max(sample_local[:, :2] @ directions.T, axis=0)
        outline_error = np.mean(np.abs(radius - outline)) / radius
        score = float(3 * surface_error + outline_error)
        if cylinder is None or score < cylinder['score']:
            cylinder = {'kind': 'CYLINDER', 'basis': basis.tolist(),
                        'center': (basis @ middle + origin).tolist(),
                        'size': [radius * 2, radius * 2, depth], 'score': score}
    result = {'box': box, 'cylinder': cylinder,
              'inverse': np.linalg.inv(np.asarray(linear, dtype=float)).tolist()}
    candidates = [p for p in (box, cylinder) if p is not None]
    selected = min(candidates, key=lambda p: p['score'])
    tolerance = .16 if selected['kind'] == 'CYLINDER' else .08
    result['auto'] = selected['kind'] if selected['score'] <= tolerance else 'NONE'
    return result


def chosen_fit(data, requested):
    kind = data['auto'] if requested == 'AUTO' else requested
    if kind == 'NONE':
        return None
    return data['box' if kind == 'BOX' else 'cylinder']


def local_matrix(data, selected):
    inverse = np.array(data['inverse'])
    basis = np.array(selected['basis'])
    transform = np.eye(4)
    # Primitive box has size 1; cylinder has radius 1 and depth 2.
    scale = np.array(selected['size'])
    if selected['kind'] == 'CYLINDER':
        scale /= 2
    transform[:3, :3] = inverse @ basis @ np.diag(scale)
    transform[:3, 3] = inverse @ np.array(selected['center'])
    return Matrix(transform.tolist())


def make_group(data, selected, segments, material):
    group = bpy.data.node_groups.new('Fabularis — Forma semplice', 'GeometryNodeTree')
    try:
        group.interface.new_socket(name='Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
        group.interface.new_socket(name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
        output = group.nodes.new('NodeGroupOutput')
        if selected['kind'] == 'CYLINDER':
            primitive = group.nodes.new('GeometryNodeMeshCylinder')
            primitive.inputs['Vertices'].default_value = segments
            primitive.inputs['Side Segments'].default_value = 1
            primitive.inputs['Fill Segments'].default_value = 1
            primitive.inputs['Radius'].default_value = 1
            primitive.inputs['Depth'].default_value = 2
            primitive.fill_type = 'NGON'
        else:
            primitive = group.nodes.new('GeometryNodeMeshCube')
            primitive.inputs['Size'].default_value = (1, 1, 1)
        transform = group.nodes.new('GeometryNodeTransform')
        transform.inputs['Mode'].default_value = 'Matrix'
        matrix = local_matrix(data, selected)
        combine = group.nodes.new('FunctionNodeCombineMatrix')
        for column in range(4):
            for row in range(4):
                combine.inputs[column * 4 + row].default_value = matrix[row][column]
        group.links.new(combine.outputs[0], transform.inputs['Transform'])
        if selected['kind'] == 'CYLINDER':
            smooth = group.nodes.new('GeometryNodeSetShadeSmooth')
            smooth.domain = 'FACE'
            smooth.inputs['Shade Smooth'].default_value = True
            group.links.new(primitive.outputs['Mesh'], smooth.inputs['Geometry'])
            group.links.new(primitive.outputs['Side'], smooth.inputs['Selection'])
            group.links.new(smooth.outputs['Geometry'], transform.inputs['Geometry'])
        else:
            group.links.new(primitive.outputs['Mesh'], transform.inputs['Geometry'])
        assign = group.nodes.new('GeometryNodeSetMaterial')
        assign.inputs['Material'].default_value = material
        group.links.new(transform.outputs['Geometry'], assign.inputs['Geometry'])
        group.links.new(assign.outputs['Geometry'], output.inputs['Geometry'])
        return group
    except Exception:
        bpy.data.node_groups.remove(group)
        raise
