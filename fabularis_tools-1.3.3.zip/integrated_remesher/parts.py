"""Component-wise reconstruction and guarded simplification of CAD meshes.

Connected components are processed independently without creating persistent
scene objects. Axial bodies use a sampled radial profile, not a global cylinder.
The hand-optimized reference is not read or copied by this implementation.
"""
import json
import math
import numpy as np
import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from . import primitives


def face_components(mesh):
    owners = {}
    parents = list(range(len(mesh.polygons)))
    def root(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i
    for face in mesh.polygons:
        for vertex in face.vertices:
            if vertex in owners:
                parents[root(face.index)] = root(owners[vertex])
            else:
                owners[vertex] = face.index
    groups = {}
    for i in range(len(parents)):
        groups.setdefault(root(i), []).append(i)
    return list(groups.values())


def copy_materials(source, destination):
    for material in source.materials:
        destination.materials.append(material.original if material else None)


def extract(mesh, indices):
    vertices = sorted({i for fi in indices for i in mesh.polygons[fi].vertices})
    mapping = {v: i for i, v in enumerate(vertices)}
    result = bpy.data.meshes.new('Fabularis temporary component')
    result.from_pydata([mesh.vertices[i].co for i in vertices], [],
                       [[mapping[v] for v in mesh.polygons[i].vertices] for i in indices])
    copy_materials(mesh, result)
    for face, index in zip(result.polygons, indices):
        source = mesh.polygons[index]
        face.material_index = source.material_index
        face.use_smooth = source.use_smooth
    for layer in mesh.uv_layers:
        new = result.uv_layers.new(name=layer.name)
        for face, index in zip(result.polygons, indices):
            for target_loop, source_loop in zip(face.loop_indices, mesh.polygons[index].loop_indices):
                new.data[target_loop].uv = layer.data[source_loop].uv
    return result


def geometry(mesh, linear):
    points = [linear @ v.co for v in mesh.vertices]
    faces = [list(face.vertices) for face in mesh.polygons]
    return points, faces, BVHTree.FromPolygons(points, faces)


def radial_profile(mesh, linear, selected, sample_count=65, angle_count=16, relaxed=False):
    points, faces, tree = geometry(mesh, linear)
    basis = np.array(selected['basis'])
    center = np.array(selected['center'])
    radius = selected['size'][0] / 2
    depth = selected['size'][2]
    # Sample the actual outer skin. Merely taking vertex radii per axial level
    # creates false grooves where only internal vertices happen to exist.
    stations = np.linspace(-depth / 2, depth / 2, sample_count)
    profile = []
    spreads = []
    coverage = []
    for z in stations:
        query_z = min(depth / 2 - depth * 1e-5, max(-depth / 2 + depth * 1e-5, z))
        radii = []
        for angle in np.arange(angle_count) * (2 * math.pi / angle_count):
            direction = basis[:, 0] * math.cos(angle) + basis[:, 1] * math.sin(angle)
            axis_point = center + basis[:, 2] * query_z
            start = Vector(axis_point + direction * radius * 1.3)
            hit = tree.ray_cast(start, Vector(-direction), radius * 2.6)
            if hit[0] is not None:
                radii.append(float(np.dot(np.array(hit[0]) - axis_point, direction)))
        if radii:
            profile.append([float(z), float(np.quantile(radii, .65)) if relaxed else max(radii)])
            spreads.append((max(radii) - min(radii)) / radius)
            coverage.append(len(radii) / angle_count)
    if len(profile) < 3:
        return None
    # A wheel with a protruding hub is not one cylinder, but is still a body
    # of revolution. Test rotational support instead of a single-radius fit.
    # Reject open brackets and square/rectangular sections.
    if np.mean(coverage) < .95 or np.quantile(spreads, .9) > (.65 if relaxed else .18) or np.mean(spreads) > (.42 if relaxed else .12):
        return None
    return profile


def robust_circle(points):
    """Find a supported circular cross section despite feet, fins and bosses."""
    samples = points[np.linspace(0,len(points)-1,min(len(points),2048),dtype=int)]
    span = np.linalg.norm(np.ptp(samples,axis=0))
    if span < 1e-12:
        return None
    rng=np.random.default_rng(1741)
    best=None
    for _ in range(128):
        tri=samples[rng.choice(len(samples),3,replace=False)]
        matrix=2*(tri[1:]-tri[0])
        if abs(np.linalg.det(matrix)) < span*span*1e-5:
            continue
        center=np.linalg.solve(matrix,np.sum(tri[1:]**2,axis=1)-np.sum(tri[0]**2))
        radii=np.linalg.norm(samples-center,axis=1)
        radius=np.linalg.norm(tri[0]-center)
        if not .08*span < radius < .8*span:
            continue
        inliers=np.abs(radii-radius) < radius*.12
        if np.mean(inliers) < .35:
            continue
        angles=np.arctan2(*(samples[inliers]-center).T[::-1])
        bins=np.unique(np.floor((angles+math.pi)*24/(2*math.pi)).astype(int)%24)
        coverage=len(bins)/24
        if coverage < .9:
            continue
        score=float(np.mean(inliers))*coverage
        if best is None or score > best[0]:
            best=(score,center,float(radius))
    return best


def mass_axial_fit(mesh, linear, fit):
    """Low-detail body axis, independent of a box shifted by lateral feet."""
    points=np.array([tuple(linear@v.co) for v in mesh.vertices],dtype=float)
    directions=[np.array(fit['cylinder']['basis'])[:,2]]+list(np.array(fit['box']['basis']).T)
    for axis in primitives.unique_axes(directions):
        basis=primitives.frame(axis)
        local=points@basis
        circle=robust_circle(local[:,:2])
        if circle is None:
            continue
        _, middle, radius=circle
        lo,hi=float(local[:,2].min()),float(local[:,2].max())
        center=basis@np.array([middle[0],middle[1],(lo+hi)/2])
        # Cast from outside all protrusions; angular quantiles recover the
        # supported main skin instead of stretching to a foot or a fin tip.
        cast_radius=float(np.linalg.norm(local[:,:2]-middle,axis=1).max())
        selected={'kind':'CYLINDER','basis':basis.tolist(),'center':center.tolist(),
                  'size':[cast_radius*2,cast_radius*2,hi-lo],'score':0}
        _,_,tree=geometry(mesh,linear)
        supported=[]
        # Sparse tie rods and mounting screws must not set the depth of the
        # main body. Keep the longest axially continuous, round-supported span.
        for z in np.linspace(lo,hi,65):
            query_z=min(hi-(hi-lo)*1e-5,max(lo+(hi-lo)*1e-5,z))
            radii=[]
            for angle in np.arange(24)*math.tau/24:
                direction=basis[:,0]*math.cos(angle)+basis[:,1]*math.sin(angle)
                p=basis@np.array([middle[0],middle[1],query_z])
                hit=tree.ray_cast(Vector(p+direction*cast_radius*1.3),Vector(-direction),cast_radius*2.6)
                if hit[0] is not None:
                    radii.append(float(np.dot(np.array(hit[0])-p,direction)))
            if (len(radii)>=22 and min(radii)>0
                    and (np.quantile(radii,.9)-np.quantile(radii,.1))/radius<.55):
                supported.append([float(z-(lo+hi)/2),float(np.quantile(radii,.65))])
            else:
                supported.append(None)
        runs=[[]]
        for station in supported:
            if station is None:
                if runs[-1]:runs.append([])
            else:runs[-1].append(station)
        profile=max(runs,key=len)
        if len(profile)<6 or profile[-1][0]-profile[0][0]<(hi-lo)*.12:
            profile=None
        if profile:
            if profile[-1][0]-profile[0][0]>(hi-lo)*.6:
                profile[0][0]=float(-(hi-lo)/2)
                profile[-1][0]=float((hi-lo)/2)
            selected['size'][:2]=[radius*2,radius*2]
            return dict(fit,auto='CYLINDER',cylinder=selected),profile
    return None


def box_projection_support(source, fit, linear):
    """Reject open brackets and bent tubes before replacing a compact housing.

    Check rays across all three principal views, including the middle of the
    projected envelope; merely checking its bounding corners would fill an L.
    """
    _,_,tree=geometry(source,linear)
    selected=fit['box'];basis=np.array(selected['basis']);center=np.array(selected['center'])
    size=np.array(selected['size'])
    coverage=[]
    for axis in range(3):
        other=[i for i in range(3) if i!=axis]
        hits=0
        for u in np.linspace(-.44,.44,9):
            for v in np.linspace(-.44,.44,9):
                p=center-basis[:,axis]*size[axis]*.65
                p=p+basis[:,other[0]]*size[other[0]]*u+basis[:,other[1]]*size[other[1]]*v
                if tree.ray_cast(Vector(p),Vector(basis[:,axis]),float(size[axis]*1.3))[0] is not None:
                    hits+=1
        coverage.append(hits/81)
    return min(coverage)


def box_boundary_supported(source, fit, linear):
    """A filled bore may be simplified; large perimeter cutouts must stay."""
    _,_,tree=geometry(source,linear)
    box=fit['box'];basis=np.array(box['basis']);center=np.array(box['center']);size=np.array(box['size'])
    for axis in range(3):
        other=[i for i in range(3) if i!=axis]
        probes={(round(u,6),round(v,6)) for u in np.linspace(-.46,.46,9)
                for v in np.linspace(-.46,.46,9) if abs(u)>.45 or abs(v)>.45}
        for sign in (-1,1):
            supported=0
            for u,v in probes:
                origin=center+basis[:,axis]*size[axis]*sign*.6
                origin+=basis[:,other[0]]*size[other[0]]*u+basis[:,other[1]]*size[other[1]]*v
                hit=tree.ray_cast(Vector(origin),Vector(-sign*basis[:,axis]),float(size[axis]*1.3))
                if hit[0] is not None:
                    depth=size[axis]*.5-sign*float((np.array(hit[0])-center)@basis[:,axis])
                    supported+=depth<=size[axis]*.055
            if supported/len(probes)<.90:return False
    return True


def mass_strength(quality):
    return max(0.,(12.-quality)/12.)**1.2


def axial_fit(mesh, linear, fit, relaxed=False):
    points = np.array([tuple(linear @ v.co) for v in mesh.vertices])
    directions = [np.array(fit['cylinder']['basis'])[:, 2]] + list(np.array(fit['box']['basis']).T)
    for axis in primitives.unique_axes(directions):
        basis = primitives.frame(axis)
        local = points @ basis
        lo, hi = local.min(axis=0), local.max(axis=0)
        middle = (lo + hi) / 2
        radius = float(np.linalg.norm(local[:, :2] - middle[:2], axis=1).max())
        selected = {'kind': 'CYLINDER', 'basis': basis.tolist(), 'center': (basis @ middle).tolist(),
                    'size': [radius*2, radius*2, float(hi[2]-lo[2])], 'score': 0}
        if min(selected['size']) < 1e-10:
            continue
        if radial_profile(mesh, linear, selected, 9, 8, relaxed) is not None:
            profile = radial_profile(mesh, linear, selected, relaxed=relaxed)
            if profile:
                updated = dict(fit)
                updated.update(auto='CYLINDER', cylinder=selected)
                return updated, profile
    return None


def analyze(mesh, linear):
    result = []
    seeds=json.loads(mesh.get('_fab_profile_seeds','[]'))
    seed_ids=mesh.attributes.get('_fab_profile_id')
    for indices in face_components(mesh):
        part = extract(mesh, indices)
        try:
            part.calc_loop_triangles()
            data = {'faces': indices, 'triangles': len(part.loop_triangles), 'kind': 'DETAIL'}
            if seed_ids:
                ids={seed_ids.data[i].value for i in indices}
                if len(ids)==1 and 0<next(iter(ids))<=len(seeds):
                    seed=seeds[next(iter(ids))-1]
                    data.update(kind='PROFILE',fit=seed['fit'],profile=seed['profile'],proxy_profile=True)
                    result.append(data)
                    continue
            if data['triangles'] > 12:
                try:
                    fit = primitives.fit(part, linear)
                    data['detail_fit'] = fit
                    if fit['box']['score'] <= .04:
                        fit['auto'] = 'BOX'
                        data.update(kind='BOX', fit=fit)
                    elif fit['cylinder']:
                        axial = axial_fit(part, linear, fit)
                        if axial:
                            data.update(kind='PROFILE', fit=axial[0], profile=axial[1])
                except (ValueError, np.linalg.LinAlgError):
                    pass
            points=np.array([tuple(linear@v.co) for v in part.vertices])
            _,axes=np.linalg.eigh(np.cov(points.T));extent=np.ptp(points@axes,axis=0)
            wall=wall_geometry(part,linear)
            fit=data.get('detail_fit') or data.get('fit')
            planar=box_alignment(part,fit,linear) if fit else 1.
            prismatic=0.
            if fit and fit.get('cylinder'):
                directions=[np.array(fit['cylinder']['basis'])[:,2]]+list(np.array(fit['box']['basis']).T)
                normal_matrix=np.linalg.inv(np.array(linear)).T
                for axis in directions:
                    good=total=0.
                    for f in part.polygons:
                        n=normal_matrix@np.array(f.normal);length=float(np.linalg.norm(n))
                        if length<1e-15:continue
                        area=f.area*length;total+=area;alignment=abs(float((n/length)@axis))
                        if alignment<.04 or alignment>.999:good+=area
                    prismatic=max(prismatic,good/max(total,1e-15))
            protect_curve=bool(data['kind']=='DETAIL' and data['triangles']>24 and planar<.35 and prismatic<.94 and min(extent)<max(extent)*.75)
            family='PROFILE' if data['kind']=='PROFILE' else 'SHELL' if wall else 'CURVED' if protect_curve else 'PLATE' if extent[0]<extent[1]*.08 else 'COMPACT' if extent[0]>extent[2]*.20 else data['kind']
            data['scan']={'family':family,'extent':extent.tolist(),
                'materials':sorted({f.material_index for f in part.polygons}),
                'planar_support':planar,'prismatic_support':prismatic,'protect_curve':protect_curve,
                'wall':list(wall) if wall else None}
            result.append(data)
        finally:
            bpy.data.meshes.remove(part)
    return result


def simplify_profile(points, tolerance):
    if len(points) <= 2:
        return points
    start, end = np.array(points[0]), np.array(points[-1])
    direction = end - start
    coords = np.array(points[1:-1]) - start
    norm = np.dot(direction, direction)
    projection = np.clip(coords @ direction / max(norm, 1e-30), 0, 1)
    distance = np.linalg.norm(coords - projection[:, None] * direction, axis=1)
    index = int(np.argmax(distance)) + 1
    if distance[index - 1] <= tolerance:
        return [points[0], points[-1]]
    return simplify_profile(points[:index+1], tolerance)[:-1] + simplify_profile(points[index:], tolerance)


def detail_strength(quality):
    # Additional feature removal fades in below 35; high detail keeps the
    # conservative path. Always reconstruct from the stored original.
    return max(0., (35. - quality) / 35.) ** 1.3


def detail_stage(quality):
    """Continuous requested detail; labels describe the current range only."""
    q=max(1.,min(100.,float(quality)))
    if q>=100:return 'Originale',100,None,False
    effective=float(np.interp(q,[1,30,50,75,100],[1,9.7,30,70,100]))
    sides=max(12,int(round(12+(q-1)*.24)))
    label='Dettagli' if q>=75 else 'Pulito' if q>=50 else 'Volumi' if q>=25 else 'Essenziale'
    return label,effective,sides,q<50


def collar_envelope(source, selected, profile, linear, sides, minimal=False):
    basis=np.array(selected['basis']);center=np.array(selected['center'])
    coords=(np.array([tuple(linear@v.co) for v in source.vertices])-center)@basis
    radii=np.linalg.norm(coords[:,:2],axis=1)
    radius=float(radii.max());lo=float(coords[:,2].min());hi=float(coords[:,2].max())
    profile_radius=max(p[1] for p in profile)
    # Do not turn long shafts, rods, or a motor's lateral feet into a wide
    # straight sleeve. Compact supported collars can use their outer envelope.
    if (hi-lo > profile_radius*2.4 or (not minimal and profile[-1][0]-profile[0][0] < (hi-lo)*.6)
            or radius > float(np.quantile(radii,.9))*1.18):
        return profile,False
    # Inscribed polygon: never enlarge the measured diameter to enclose it.
    return [[lo,radius],[hi,radius]],True


def lateral_boxes(source, selected, profile, linear):
    """Keep substantial one-sided housings attached to an axial body.

    Radial ribs surround the axis and are intentionally ignored. A terminal
    housing has a localized direction and broad planar faces; represent it as
    a box intersecting the body rather than dropping it with the cooling fins.
    """
    basis=np.array(selected['basis']);center=np.array(selected['center'])
    points=np.array([tuple(linear@v.co) for v in source.vertices])
    local=(points-center)@basis
    radii=np.linalg.norm(local[:,:2],axis=1)
    skin=np.interp(local[:,2],[p[0] for p in profile],[p[1] for p in profile])
    outside=radii>skin*1.25
    indices=[f.index for f in source.polygons if any(outside[i] for i in f.vertices)]
    if not indices:
        return []
    patch=extract(source,indices)
    result=[]
    try:
        total_area=sum(f.area for f in source.polygons)
        for group in face_components(patch):
            part=extract(patch,group)
            try:
                if sum(f.area for f in part.polygons)<total_area*.02:
                    continue
                world=np.array([tuple(linear@v.co) for v in part.vertices])
                coords=(world-center)@basis
                r=np.linalg.norm(coords[:,:2],axis=1)
                reference=np.interp(coords[:,2],[p[0] for p in profile],[p[1] for p in profile])
                out=r>reference*1.25
                if np.count_nonzero(out)<4:
                    continue
                directions=coords[out,:2]/r[out,None]
                direction=directions.mean(axis=0)
                if np.linalg.norm(direction)<.8 or np.ptp(coords[:,2])<selected['size'][2]*.15:
                    continue
                # Long narrow cooling ribs must not turn into lateral boxes
                # just because an inscribed cylinder no longer covers them.
                tangent=np.array([-direction[1],direction[0]])/np.linalg.norm(direction)
                width=float(np.ptp(coords[:,:2]@tangent))
                if width<float(np.median(reference))*.35:
                    continue
                try:
                    fit=primitives.fit(part,linear)
                except (ValueError,np.linalg.LinAlgError):
                    continue
                if fit['box']['score']>.5 or box_alignment(part,fit,linear)<.55:
                    continue
                box=fit['box'];axes=np.array(box['basis'])
                transformed=world@axes;lo=transformed.min(axis=0);hi=transformed.max(axis=0)
                z=float(np.mean(coords[out,2]));radius=float(np.interp(z,[p[0] for p in profile],[p[1] for p in profile]))
                axis_point=center+basis[:,2]*z
                radial=basis[:,:2]@(direction/np.linalg.norm(direction))
                alignment=axes.T@radial;j=int(np.argmax(np.abs(alignment)))
                if abs(alignment[j])>.8:
                    inner=float((axis_point+radial*radius*.85)@axes[:,j])
                    if alignment[j]>0:lo[j]=min(lo[j],inner)
                    else:hi[j]=max(hi[j],inner)
                box=dict(box,center=(axes@((lo+hi)/2)).tolist(),size=(hi-lo).tolist())
                result.append(box_mesh(part,{'fit':dict(fit,auto='BOX',box=box)}))
            finally:
                bpy.data.meshes.remove(part)
        return result
    except Exception:
        for mesh in result:bpy.data.meshes.remove(mesh)
        raise
    finally:
        bpy.data.meshes.remove(patch)


def profile_mesh(source, item, quality, linear, envelope=False, sides=None, minimal=False, profile_quality=None):
    selected = primitives.chosen_fit(item['fit'], 'AUTO')
    radius = selected['size'][0] / 2
    profile_quality=quality if profile_quality is None else profile_quality
    tolerance = radius * (.003 + .065 * (1 - profile_quality / 100) ** 1.5 + .23 * detail_strength(profile_quality))
    profile = simplify_profile(item['profile'], tolerance)
    sides = sides or max(8, 4 * math.ceil((8 + quality * .24) / 4))
    if envelope:
        profile,_=collar_envelope(source,selected,profile,linear,sides,minimal)
    basis = np.array(selected['basis'])
    center = np.array(selected['center'])
    inverse = np.linalg.inv(np.asarray(linear))
    _, _, tree = geometry(source, linear)
    if len({face.material_index for face in source.polygons}) > 1:
        # Insert collinear stations at material transitions. Without these,
        # one wide strip between hub and tire would get just one material.
        def material_at(point):
            z, r = point
            votes = {}
            for angle in np.arange(8) * (2*math.pi/8):
                p = center + basis @ np.array([r*math.cos(angle), r*math.sin(angle), z])
                hit = tree.find_nearest(Vector(p))
                if hit[2] is not None:
                    material = source.polygons[hit[2]].material_index
                    votes[material] = votes.get(material, 0) + 1
            return max(votes, key=votes.get) if votes else 0
        expanded = [profile[0]]
        for a, b in zip(profile[:-1], profile[1:]):
            a, b = np.array(a), np.array(b)
            previous = material_at(a)
            for k in range(1, 17):
                t = k / 16
                material = material_at(a + (b-a)*t)
                if material != previous:
                    expanded.append((a + (b-a)*(t-1/32)).tolist())
                previous = material
            expanded.append(b.tolist())
        profile = expanded
    vertices = []
    for z, r in profile:
        for k in range(sides):
            angle = k * 2 * math.pi / sides
            p = center + basis @ np.array([r * math.cos(angle), r * math.sin(angle), z])
            vertices.append(tuple(inverse @ p))
    faces = []
    for j in range(len(profile) - 1):
        for k in range(sides):
            nxt = (k + 1) % sides
            faces.append((j*sides+k, j*sides+nxt, (j+1)*sides+nxt, (j+1)*sides+k))
    side_faces = len(faces)
    # Recessed hubs and tire sidewalls need separate radial bands. One ngon
    # would assign the center's metal material to the entire wheel face.
    for end in (0, len(profile)-1):
        z_end, r_end = profile[end]
        sign = -1 if end == 0 else 1
        outer = [end*sides+k for k in range(sides)]
        if len({face.material_index for face in source.polygons}) <= 1:
            faces.append(tuple(reversed(outer)) if sign < 0 else tuple(outer))
            continue
        # Scan actual radial material transitions instead of adding three
        # arbitrary concentric rings to every multi-material end cap.
        fractions=np.linspace(.02,.98,33)
        labels=[]
        for fraction in fractions:
            votes={}
            for angle in np.arange(8)*(2*math.pi/8):
                p=center+basis@np.array([r_end*fraction*math.cos(angle),r_end*fraction*math.sin(angle),sign*selected['size'][2]*.7])
                hit=tree.ray_cast(Vector(p),Vector(-sign*basis[:,2]),selected['size'][2]*1.5)
                if hit[2] is not None:
                    material=source.polygons[hit[2]].material_index
                    votes[material]=votes.get(material,0)+1
            labels.append(max(votes,key=votes.get) if votes else None)
        boundaries=[]
        previous=labels[0]
        for k in range(1,len(labels)-1):
            material=labels[k]
            # A sustained band, rather than isolated noisy samples.
            if material is not None and material!=previous and material==labels[k+1]:
                boundaries.append(float((fractions[k-1]+fractions[k])/2));previous=material
        rings = []
        for fraction in boundaries:
            r = r_end * fraction
            depths = []
            for angle in np.arange(8) * (2*math.pi/8):
                p = center + basis @ np.array([r*math.cos(angle), r*math.sin(angle), sign*selected['size'][2]*.7])
                hit = tree.ray_cast(Vector(p), Vector(-sign*basis[:, 2]), selected['size'][2]*1.5)
                if hit[0] is not None:
                    depths.append(float(np.dot(np.array(hit[0])-center, basis[:, 2])))
            z = z_end if envelope else max(depths) if sign > 0 and depths else min(depths) if depths else z_end
            ring = []
            for k in range(sides):
                angle = k*2*math.pi/sides
                p = center + basis @ np.array([r*math.cos(angle), r*math.sin(angle), z])
                ring.append(len(vertices)); vertices.append(tuple(inverse @ p))
            rings.append(ring)
        rings.append(outer)
        for inner, outer_ring in zip(rings[:-1], rings[1:]):
            for k in range(sides):
                nxt = (k+1) % sides
                face = (inner[k], outer_ring[k], outer_ring[nxt], inner[nxt])
                faces.append(tuple(reversed(face)) if sign < 0 else face)
        faces.append(tuple(reversed(rings[0])) if sign < 0 else tuple(rings[0]))
    mesh = bpy.data.meshes.new('Fabularis axial profile')
    mesh.from_pydata(vertices, [], faces)
    copy_materials(source, mesh)
    for face in mesh.polygons:
        center = sum((linear @ mesh.vertices[v].co for v in face.vertices), Vector()) / len(face.vertices)
        nearest = tree.find_nearest(center)
        if nearest[2] is not None:
            face.material_index = source.polygons[nearest[2]].material_index
        face.use_smooth = face.index < side_faces
    layer=mesh.attributes.new(name='_fab_proxy_kind',type='INT',domain='FACE')
    for value in layer.data:value.value=1
    if envelope:
        additions=lateral_boxes(source,selected,profile,linear)
        if additions:
            bm=bmesh.new()
            try:
                bm.from_mesh(mesh)
                for addition in additions:bm.from_mesh(addition)
                bm.to_mesh(mesh);mesh.update()
                mesh['fab_lateral_boxes']=len(additions)
            finally:
                bm.free()
                for addition in additions:bpy.data.meshes.remove(addition)
    mesh['_fab_profile_seed']=json.dumps({'fit':item['fit'],'profile':profile})
    return mesh


def box_alignment(source, fit, linear):
    """Broad planar faces distinguish beveled housings from round pipes."""
    basis = np.array(fit['box']['basis'])
    normal_matrix = np.linalg.inv(np.array(linear)).T
    aligned = total = 0.
    for face in source.polygons:
        n = normal_matrix @ np.array(face.normal)
        length = np.linalg.norm(n)
        if length > 1e-15:
            area = face.area * length
            total += area
            if np.max(np.abs((n / length) @ basis)) > .995:
                aligned += area
    return float(aligned / max(total, 1e-15))


def detail_candidate(source, item, quality, linear, envelope=False, sides=None, minimal=False, profile_quality=None):
    """Try a coarse housing/profile only when geometric evidence supports it.

    This never fits a whole bent pipe to a straight cylinder. Each axial
    station needs near-complete support around the same axis; surface/bounds
    checks in build still reject bridged bends and important openings.
    """
    if item.get('proxy_profile'):
        return profile_mesh(source,item,quality,linear,envelope,sides,minimal,profile_quality),'PROFILE'
    fit = item.get('detail_fit') or item.get('fit')
    if not fit:
        try:
            fit = primitives.fit(source, linear)
        except (ValueError, np.linalg.LinAlgError):
            return None, None
    item['detail_fit'] = fit
    if 'box_alignment' not in item:
        item['box_alignment'] = box_alignment(source, fit, linear)
    if mass_strength(quality)>0:
        if 'mass_axial' not in item:
            item['mass_axial']=mass_axial_fit(source,linear,fit) if fit.get('cylinder') else None
        if 'mass_axial_v2_checked' not in item:
            if item['mass_axial'] is None and fit.get('cylinder') and fit['cylinder']['score']<.12:
                item['mass_axial']=axial_fit(source,linear,fit)
            item['mass_axial_v2_checked']=True
        if 'mass_box_support' not in item:
            item['mass_box_support']=box_projection_support(source,fit,linear)
        if item['mass_axial']:
            if 'mass_round_v1' not in item:
                selected=item['mass_axial'][0]['cylinder']
                basis=np.array(selected['basis']);center=np.array(selected['center'])
                coords=(np.array([tuple(linear@v.co) for v in source.vertices])-center)@basis
                radius=float(np.linalg.norm(coords[:,:2],axis=1).max())
                probe=dict(selected,size=[radius*2,radius*2,selected['size'][2]])
                item['mass_round_v1']=radial_profile(source,linear,probe,9,16) is not None
            if item['mass_round_v1']:
                axial=item['mass_axial']
                return profile_mesh(source,{'fit':axial[0],'profile':axial[1]},quality,linear,envelope,sides,minimal,profile_quality),'PROFILE'
        if (fit['box']['score']<.35 and fit['cylinder']['score']>.3
                and item['box_alignment']>.4 and item['mass_box_support']>=.78):
            return box_mesh(source,{'fit':dict(fit,auto='BOX')}),'BOX'
        if (item['mass_axial'] and (fit['cylinder']['score']<.25
                or item['box_alignment']<.72 or item['mass_box_support']<.78)):
            axial=item['mass_axial']
            return profile_mesh(source,{'fit':axial[0],'profile':axial[1]},quality,linear,envelope,sides,minimal,profile_quality),'PROFILE'
        # Dense cuboid housings may contain deep bores and mounting ribs.
        # Their silhouettes must support a box in every principal view.
        if (fit['box']['score']<.5 and item['box_alignment']>.4
                and item['mass_box_support']>=.78):
            return box_mesh(source,{'fit':dict(fit,auto='BOX')}),'BOX'
        if item['mass_axial']:
            axial=item['mass_axial']
            return profile_mesh(source,{'fit':axial[0],'profile':axial[1]},quality,linear,envelope,sides,minimal,profile_quality),'PROFILE'
    if fit['box']['score'] < .16 and item['box_alignment'] > .72:
        box_fit = dict(fit, auto='BOX')
        return box_mesh(source, {'fit': box_fit}), 'BOX'
    if fit.get('cylinder'):
        if 'coarse_axial' not in item:
            item['coarse_axial'] = axial_fit(source, linear, fit, relaxed=True)
        axial = item['coarse_axial']
        if axial:
            return profile_mesh(source, {'fit': axial[0], 'profile': axial[1]}, quality, linear,envelope,sides,minimal,profile_quality), 'PROFILE'
    return None, None


def detail_limits(source, quality, linear):
    allowed, bounds = shape_limits(source, quality, linear)
    strength = detail_strength(quality)
    # A larger allowance is reserved for supported primitive candidates;
    # generic decimation (in particular curved pipes) retains strict limits.
    points = np.array([tuple(linear @ v.co) for v in source.vertices])
    _, axes = np.linalg.eigh(np.cov(points.T))
    extents = sorted(np.ptp((points - points.mean(axis=0)) @ axes, axis=0))
    diagonal = max(float(np.linalg.norm(np.ptp(points, axis=0))), 1e-15)
    thickness = extents[0] if extents[0] > diagonal * 1e-6 else extents[1]
    mass=mass_strength(quality)
    return (allowed + min(.045, thickness / diagonal * .18) * strength
            + min(.23,thickness/diagonal*.80)*mass,
            bounds + min(.015, thickness / diagonal * .06) * strength
            + min(.10,thickness/diagonal*.30)*mass)


def box_mesh(source, item):
    selected = primitives.chosen_fit(item['fit'], 'AUTO')
    matrix = primitives.local_matrix(item['fit'], selected)
    bm = bmesh.new()
    try:
        bmesh.ops.create_cube(bm, size=1, matrix=matrix)
        result = bpy.data.meshes.new('Fabularis box component')
        bm.to_mesh(result)
    finally:
        bm.free()
    copy_materials(source, result)
    area = {}
    for face in source.polygons:
        area[face.material_index] = area.get(face.material_index, 0) + face.area
    material_index = max(area, key=area.get) if area else 0
    for face in result.polygons:
        face.material_index = material_index
    layer=result.attributes.new(name='_fab_proxy_kind',type='INT',domain='FACE')
    for value in layer.data:value.value=2
    return result


def measured_error(source, result, linear):
    a, _, ta = geometry(source, linear)
    b, _, tb = geometry(result, linear)
    if not a or not b:
        return float('inf'), float('inf')
    lo_a = np.min(a, axis=0); hi_a = np.max(a, axis=0)
    lo_b = np.min(b, axis=0); hi_b = np.max(b, axis=0)
    diagonal = float(np.linalg.norm(hi_a - lo_a))
    bounds_error = float(max(np.max(np.abs(lo_a - lo_b)), np.max(np.abs(hi_a - hi_b)))) / max(diagonal, 1e-15)
    error = 0
    # Vertices plus triangle centroids catch missing plate areas and gaps that
    # vertex-only checks miss. This is sampled validation, not a Hausdorff proof.
    for mesh, points, tree in ((source, a, tb), (result, b, ta)):
        mesh.calc_loop_triangles()
        samples = [points[i] for i in np.linspace(0, len(points)-1, min(len(points), 1024), dtype=int)]
        for i in np.linspace(0, len(mesh.loop_triangles)-1, min(len(mesh.loop_triangles), 512), dtype=int):
            tri = mesh.loop_triangles[i]
            corners = [points[v] for v in tri.vertices]
            samples.append(sum(corners, Vector()) / 3)
            # Large reconstructed faces need interior probes too: a cap or a
            # box can bridge an opening while all its corners still look valid.
            if len(mesh.loop_triangles) <= 128:
                for j in range(3):
                    samples.append(corners[j] * .6 + corners[(j+1)%3] * .2 + corners[(j+2)%3] * .2)
        for point in samples:
            nearest = tree.find_nearest(point)
            if nearest[3] is None:
                return float('inf'), bounds_error
            error = max(error, nearest[3] / max(diagonal, 1e-15))
    return error, bounds_error


def wall_geometry(mesh, linear):
    """Physical wall estimate for closed thin shells, not their bounding box."""
    bm=bmesh.new()
    try:
        bm.from_mesh(mesh)
        if not bm.faces or not all(e.is_manifold for e in bm.edges):return None
        for v in bm.verts:v.co=linear@v.co
        area=sum(f.calc_area() for f in bm.faces)
        volume=abs(bm.calc_volume())
        if area<=1e-20 or volume<=1e-20:return None
        points=np.array([tuple(v.co) for v in bm.verts])
        _,axes=np.linalg.eigh(np.cov(points.T));extent=sorted(np.ptp(points@axes,axis=0))
        wall=2*volume/area
        # Fins can have a large surface area without being thin sheet walls.
        fill=volume/max(float(np.prod(extent)),1e-30)
        return (wall,volume) if wall<extent[0]*.2 and fill<.1 else None
    finally:bm.free()



def shape_limits(source, quality, linear):
    """Per-component distances; a long pipe must be judged by its thickness.

    PCA makes the scale independent of object orientation. For effectively
    planar surfaces use their in-plane width instead of a zero thickness.
    The diagonal cap retains the earlier guard on compact generic objects.
    """
    points = np.array([tuple(linear @ v.co) for v in source.vertices])
    diagonal = float(np.linalg.norm(np.ptp(points, axis=0)))
    _, axes = np.linalg.eigh(np.cov(points.T))
    extents = sorted(np.ptp((points - points.mean(axis=0)) @ axes, axis=0))
    thickness = extents[0] if extents[0] > diagonal * 1e-6 else extents[1]
    # Flat extruded plates can simplify their in-plane contour independently
    # of physical thickness. Folded shells and tubes keep the thickness guard.
    flat=extents[0] < extents[1]*.08
    relative = (extents[1] if flat else thickness) / max(diagonal, 1e-15)
    amount = 1 - quality / 100
    allowed=min(.002 + .018 * amount, relative * (.01 + .07 * amount))
    bounds=min(.003 + .027 * amount, relative * (.015 + .085 * amount))
    wall=wall_geometry(source,linear)
    if wall and not flat:allowed=min(allowed,wall[0]/max(diagonal,1e-15)*.18)
    # At the very bottom of the slider compact solid parts may lose grooves
    # and small recesses. This allowance never applies to pipes or thin shells.
    protected=bool(source.get('_fab_guard_curve',False))
    if protected:
        allowed=min(allowed,thickness/max(diagonal,1e-15)*(.01+.015*amount))
    if not wall and not protected and extents[0]>extents[2]*.20:
        allowed+=.04*mass_strength(quality)
    return allowed,bounds


def decimate(source, ratio, context):
    obj = bpy.data.objects.new('Fabularis temporary simplification', source)
    context.scene.collection.objects.link(obj)
    obj.hide_render = True
    try:
        mod = obj.modifiers.new('Simplify component', 'DECIMATE')
        mod.decimate_type = 'COLLAPSE'
        mod.ratio = ratio
        mod.use_collapse_triangulate=bool(source.get('_fab_guard_curve',False))
        context.view_layer.update()
        return bpy.data.meshes.new_from_object(obj.evaluated_get(context.evaluated_depsgraph_get()),
                                              preserve_all_data_layers=True,
                                              depsgraph=context.evaluated_depsgraph_get())
    finally:
        bpy.data.objects.remove(obj, do_unlink=True)


def flatten_small_steps(source, quality, linear):
    """Merge nearby parallel face levels, without smoothing the whole object.

    Only supported planar faces participate. Curved tube vertices therefore
    do not get globally quantized or moved onto a bounding primitive.
    """
    try:
        fit = primitives.fit(source, linear)
    except (ValueError, np.linalg.LinAlgError):
        return None
    if source.get('_fab_guard_curve',False) or box_alignment(source,fit,linear)<.65:return None
    basis = np.array(fit['box']['basis'])
    coords = np.array([tuple(linear @ v.co) for v in source.vertices]) @ basis
    normal_matrix = np.linalg.inv(np.array(linear)).T
    distance = min(fit['box']['size']) * .08 * detail_strength(quality)
    changed = False
    for axis in range(3):
        levels = []
        for face in source.polygons:
            n = normal_matrix @ np.array(face.normal)
            length = np.linalg.norm(n)
            if length > 1e-15 and abs(np.dot(n/length, basis[:,axis])) > .9995:
                level = float(np.mean(coords[list(face.vertices),axis]))
                sign=1 if np.dot(n,basis[:,axis])>0 else -1
                levels.append((level,face.area*length,list(face.vertices),sign))
        levels.sort(key=lambda row: (row[3],row[0]))
        clusters = []
        for row in levels:
            if not clusters or row[3]!=clusters[-1][0][3] or row[0] - clusters[-1][0][0] > distance:
                clusters.append([row])
            else:
                clusters[-1].append(row)
        for cluster in clusters:
            if len(cluster) < 2 or cluster[-1][0]-cluster[0][0] < max(distance*1e-3,1e-10):
                continue
            target = max(cluster,key=lambda row:row[1])[0]
            for _, _, indices, _ in cluster:
                coords[indices,axis] = target
            changed = True
    if not changed:
        return None
    inverse = np.linalg.inv(np.array(linear))
    local = coords @ basis.T @ inverse.T
    result = source.copy()
    for vertex, point in zip(result.vertices,local):
        vertex.co = point
    bm=bmesh.new()
    try:
        bm.from_mesh(result)
        bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=max(distance*1e-5,1e-10))
        bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=max(distance*1e-5,1e-10))
        bmesh.ops.dissolve_limit(bm,angle_limit=.001,verts=list(bm.verts),edges=list(bm.edges),delimit={'MATERIAL'})
        bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
        bm.to_mesh(result)
        result.update()
        return result
    except Exception:
        bpy.data.meshes.remove(result)
        raise
    finally:
        bm.free()


def solid_volume(mesh,linear):
    bm=bmesh.new()
    try:
        bm.from_mesh(mesh)
        if not bm.edges or any(len(e.link_faces)!=2 for e in bm.edges):return None
        return abs(bm.calc_volume(signed=True))*abs(linear.determinant())
    finally:bm.free()


def compact_hull_mesh(source,quality,linear):
    if quality>=12 or source.get('_fab_guard_curve',False):return None
    points=np.array([tuple(linear@v.co) for v in source.vertices])
    _,axes=np.linalg.eigh(np.cov(points.T));extent=np.ptp(points@axes,axis=0)
    if extent[0]<=extent[2]*.20 or wall_geometry(source,linear):return None
    bm=bmesh.new();result=None
    try:
        for v in source.vertices:bm.verts.new(v.co)
        bmesh.ops.convex_hull(bm,input=list(bm.verts),use_existing_faces=False)
        loose=[v for v in bm.verts if not v.link_faces]
        if loose:bmesh.ops.delete(bm,geom=loose,context='VERTS')
        bmesh.ops.dissolve_limit(bm,angle_limit=.001,verts=list(bm.verts),edges=list(bm.edges))
        result=bpy.data.meshes.new('Fabularis compact envelope');bm.to_mesh(result)
        copy_materials(source,result);result.update();result.calc_loop_triangles()
        error,bounds=measured_error(source,result,linear);allowed,allowed_bounds=shape_limits(source,quality,linear)
        if len(result.loop_triangles)>=len(source.loop_triangles) or error>allowed or bounds>allowed_bounds:
            bpy.data.meshes.remove(result);return None
        _,_,tree=geometry(source,linear)
        for face in result.polygons:
            center=sum((linear@result.vertices[v].co for v in face.vertices),Vector())/len(face.vertices)
            hit=tree.find_nearest(center)
            if hit[2] is not None:face.material_index=source.polygons[hit[2]].material_index
        return result
    except Exception:
        if result and result.users==0:bpy.data.meshes.remove(result)
        raise
    finally:bm.free()


def flat_outline_mesh(source, quality, linear):
    """Simplify the two-dimensional boundary, then extrude its original depth."""
    from mathutils.geometry import tessellate_polygon
    points=np.array([tuple(linear@v.co) for v in source.vertices])
    if len(points)<6:return None
    _,axes=np.linalg.eigh(np.cov(points.T));coords=points@axes
    lo,hi=coords.min(axis=0),coords.max(axis=0);span=hi-lo
    if span[0]<=1e-10 or span[0]>=span[1]*.08:return None
    eps=max(span[0]*.002,1e-9)
    # Only genuine straight extrusions, never folded shells or rounded tubes.
    if np.mean(np.minimum(abs(coords[:,0]-lo[0]),abs(coords[:,0]-hi[0]))<eps)<.98:return None
    caps=[f for f in source.polygons if all(abs(coords[v,0]-hi[0])<eps for v in f.vertices)]
    if not caps:return None
    edges={}
    for f in caps:
        ids=list(f.vertices)
        for a,b in zip(ids,ids[1:]+ids[:1]):
            key=tuple(sorted((a,b)));edges.setdefault(key,[]).append((a,b))
    boundary=[v[0] for v in edges.values() if len(v)==1]
    links={}
    for a,b in boundary:
        links.setdefault(a,[]).append(b);links.setdefault(b,[]).append(a)
    if any(len(v)!=2 for v in links.values()):return None
    loops=[];unused=set(links)
    while unused:
        start=min(unused);loop=[start];prev=None;cur=start
        while True:
            nxt=next((v for v in links[cur] if v!=prev),None)
            if nxt==start:break
            if nxt is None or nxt in loop:return None
            loop.append(nxt);prev,cur=cur,nxt
        unused.difference_update(loop);loops.append(coords[loop,1:].copy())
    tolerance=float(np.linalg.norm(span[1:]))*(.0001+.007*(1-quality/100)**2)
    def rdp(p):
        if len(p)<3:return p
        d=p[-1]-p[0];dd=float(d@d)
        t=np.clip((p-p[0])@d/max(dd,1e-30),0,1)
        distances=np.linalg.norm(p-(p[0]+t[:,None]*d),axis=1);k=int(np.argmax(distances))
        if distances[k]<=tolerance:return p[[0,-1]]
        return np.concatenate((rdp(p[:k+1])[:-1],rdp(p[k:])))
    reduced=[]
    for loop in loops:
        k=int(np.argmax(np.linalg.norm(loop-loop[0],axis=1)))
        ring=np.concatenate((rdp(loop[:k+1])[:-1],rdp(np.concatenate((loop[k:],loop[:1])))[:-1]))
        if len(ring)<3:return None
        reduced.append(ring)
    # Consistent outer/inner winding for the triangulator.
    def area(p):return float(np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1)))/2
    reduced.sort(key=lambda p:abs(area(p)),reverse=True)
    def inside(point,ring):
        x,y=point;hit=False
        for a,b in zip(ring,np.roll(ring,-1,axis=0)):
            if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:hit=not hit
        return hit
    oriented=[]
    for i,ring in enumerate(reduced):
        depth=sum(inside(ring[0],other) for j,other in enumerate(reduced) if i!=j)
        oriented.append(ring if (area(ring)>0)==(depth%2==0) else ring[::-1])
    reduced=oriented
    polylines=[[Vector((float(v[0]),float(v[1]),0)) for v in ring] for ring in reduced]
    triangles=tessellate_polygon(polylines)
    flat=[p for loop in polylines for p in loop];lookup={tuple(p):i for i,p in enumerate(flat)};n=len(flat)
    inverse=np.linalg.inv(np.array(linear))
    vertices=[tuple(np.array([depth,v.x,v.y])@axes.T@inverse.T) for depth in (lo[0],hi[0]) for v in flat]
    faces=[]
    for tri in triangles:
        ids=tuple(int(v) if isinstance(v,(int,np.integer)) else lookup[tuple(v)] for v in tri);faces.append(tuple(reversed(ids)));faces.append(tuple(i+n for i in ids))
    offset=0
    for loop in polylines:
        for i in range(len(loop)):
            a=offset+i;b=offset+(i+1)%len(loop);faces.append((a,b,b+n,a+n))
        offset+=len(loop)
    result=bpy.data.meshes.new('Fabularis extruded outline');result.from_pydata(vertices,[],faces)
    copy_materials(source,result)
    # Transfer material by nearest source surface in physical coordinates.
    _,_,tree=geometry(source,linear)
    for f in result.polygons:
        center=sum((linear@result.vertices[v].co for v in f.vertices),Vector())/len(f.vertices)
        hit=tree.find_nearest(center)
        if hit[2] is not None:f.material_index=source.polygons[hit[2]].material_index
    bm=bmesh.new()
    try:
        bm.from_mesh(result);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(result)
    finally:bm.free()
    result.update();result.calc_loop_triangles()
    # Certification rejects triangulated holes accidentally filled and lost walls.
    before=solid_volume(source,linear);after=solid_volume(result,linear)
    error,bounds=measured_error(source,result,linear)
    if (not before or not after or not .85<=after/before<=1.15
            or error>shape_limits(source,quality,linear)[0]
            or len(result.loop_triangles)>=len(source.loop_triangles)):
        bpy.data.meshes.remove(result);return None
    return result


def curve_normals_preserved(source,result,linear):
    """Distance alone misses thin folded triangles close to the original skin."""
    _,_,tree=geometry(source,linear)
    matrix=np.linalg.inv(np.array(linear)).T
    normals=[]
    for f in source.polygons:
        n=matrix@np.array(f.normal);length=float(np.linalg.norm(n))
        normals.append(n/max(length,1e-30))
    points=np.array([tuple(linear@v.co) for v in result.vertices])
    result.calc_loop_triangles()
    for triangle in result.loop_triangles:
        corners=points[list(triangle.vertices)]
        n=np.cross(corners[1]-corners[0],corners[2]-corners[0]);length=float(np.linalg.norm(n))
        if length<1e-18:continue
        hit=tree.find_nearest(Vector(corners.mean(axis=0)))
        if hit[2] is None or abs(float((n/length)@normals[hit[2]]))<.70710678:return False
    return True


def conservative_mesh(source, quality, linear, context, remove_steps=True, legacy=None):
    if legacy is None:legacy=wall_geometry(source,linear) is None and not source.get('_fab_guard_curve',False)
    source.calc_loop_triangles()
    count = len(source.loop_triangles)
    if count <= 12:
        return source.copy(), 0
    ratio = max((quality / 100) ** 2, 12 / count)
    if not legacy:ratio=min(1.,2.**math.ceil(math.log2(ratio)))
    allowed, allowed_bounds = shape_limits(source, quality, linear)
    points=np.array([tuple(linear@v.co) for v in source.vertices])
    _,axes=np.linalg.eigh(np.cov(points.T));extents=np.ptp(points@axes,axis=0)
    flat_axis=axes[:,0] if extents[0]<extents[1]*.08 else None
    original_volume=solid_volume(source,linear) if flat_axis is not None else None
    step_result = None
    step_error = 0
    if quality<12:
        step_result=compact_hull_mesh(source,quality,linear)
        if step_result:step_error=measured_error(source,step_result,linear)[0]
    if quality<100 and step_result is None:
        step_result=flat_outline_mesh(source,quality,linear)
        if step_result:step_error=measured_error(source,step_result,linear)[0]
    # Remove redundant CAD tessellation without moving vertices or crossing
    # material boundaries. This candidate remains available even when collapse
    # must retain fine silhouette features elsewhere on the component.
    bm=bmesh.new()
    planar=None
    try:
        bm.from_mesh(source)
        bmesh.ops.dissolve_limit(bm,angle_limit=.0001,verts=list(bm.verts),
            edges=list(bm.edges),use_dissolve_boundaries=False,delimit={'MATERIAL'})
        planar=bpy.data.meshes.new('Fabularis planar reduction');bm.to_mesh(planar)
        copy_materials(source,planar);planar.update();planar.calc_loop_triangles()
        if len(planar.loop_triangles)<count:
            error,bounds=measured_error(source,planar,linear)
            if error<=allowed and bounds<=allowed_bounds:
                if step_result:step_result.calc_loop_triangles()
                if not step_result or len(planar.loop_triangles)<len(step_result.loop_triangles):
                    if step_result:bpy.data.meshes.remove(step_result)
                    step_result,step_error=planar,error;planar=None
    finally:
        bm.free()
        if planar:bpy.data.meshes.remove(planar)
    if remove_steps and detail_strength(quality) > 0:
        cleaned = flatten_small_steps(source, quality, linear)
        if cleaned:
            try:
                result, _ = conservative_mesh(cleaned, quality, linear, context, remove_steps=False, legacy=legacy)
                error, bounds = measured_error(source, result, linear)
                if error <= allowed and bounds <= allowed_bounds and len(face_components(result)) == 1:
                    result.calc_loop_triangles()
                    if step_result:step_result.calc_loop_triangles()
                    if not step_result or len(result.loop_triangles)<len(step_result.loop_triangles):
                        if step_result:bpy.data.meshes.remove(step_result)
                        step_result,step_error=result,error
                    else:bpy.data.meshes.remove(result)
                else:
                    bpy.data.meshes.remove(result)
            finally:
                bpy.data.meshes.remove(cleaned)
    protected=bool(source.get('_fab_guard_curve',False))
    for attempt in range(32 if protected else 9 if legacy else 18):
        result = decimate(source, ratio, context)
        error, bounds = measured_error(source, result, linear)
        wall=wall_geometry(source,linear)
        thickness_ok=True
        if flat_axis is not None and original_volume:
            depth=np.ptp(np.array([tuple(linear@v.co) for v in result.vertices])@flat_axis)
            volume=solid_volume(result,linear)
            thickness_ok=bool(depth>=extents[0]*.98 and volume and .85<=volume/original_volume<=1.15)
        if wall:
            result_wall=wall_geometry(result,linear)
            thickness_ok=thickness_ok and bool(result_wall and .85<=result_wall[1]/wall[1]<=1.15)
        if source.get('_fab_guard_curve',False) and thickness_ok and error<=allowed and bounds<=allowed_bounds:
            thickness_ok=curve_normals_preserved(source,result,linear)
        if error <= allowed and bounds <= allowed_bounds and thickness_ok:
            if step_result:
                step_result.calc_loop_triangles(); result.calc_loop_triangles()
                if len(step_result.loop_triangles) <= len(result.loop_triangles):
                    bpy.data.meshes.remove(result)
                    return step_result, step_error
                bpy.data.meshes.remove(step_result)
            return result, error
        bpy.data.meshes.remove(result)
        # A coarse jump from 50% straight to 100% misses usable reductions
        # on curved fittings; search the upper range in smaller steps.
        factor=1.25 if protected and ratio>=.25 else 2.
        ratio = min(1, max(.03 if legacy else 0, ratio * factor))
    return (step_result, step_error) if step_result else (source.copy(), 0)


def finish_normals(mesh, context):
    mesh.set_sharp_from_angle(angle=math.radians(45))
    if mesh.get('_fab_no_weighted_normals',False):return mesh.copy()
    obj = bpy.data.objects.new('Fabularis temporary normals', mesh)
    context.scene.collection.objects.link(obj)
    try:
        mod = obj.modifiers.new('Surface normals', 'WEIGHTED_NORMAL')
        mod.keep_sharp = True
        mod.mode = 'FACE_AREA'
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        result = bpy.data.meshes.new_from_object(obj.evaluated_get(depsgraph),
            preserve_all_data_layers=True, depsgraph=depsgraph)
        result.name = 'Fabularis — Forme composte'
        return result
    finally:
        bpy.data.objects.remove(obj, do_unlink=True)


def preserves_generic_parts(source, analysis, candidate, linear):
    """A second reconstruction must still retain generic pipe routes locally."""
    _,_,tree=geometry(candidate,linear)
    for item in analysis:
        protect_curve=item.get('scan',{}).get('protect_curve',False)
        if item['kind']!='DETAIL' or (item.get('mass_axial') and not protect_curve):
            continue
        fit=item.get('detail_fit') or item.get('fit')
        if (not protect_curve and fit and fit['box']['score']<.5 and item.get('box_alignment',0)>.4
                and item.get('mass_box_support',0)>=.78):
            continue
        part=extract(source,item['faces'])
        part['_fab_guard_curve']=protect_curve
        try:
            points=[linear@v.co for v in part.vertices]
            diagonal=float(np.linalg.norm(np.ptp(np.array(points),axis=0)))
            limit=shape_limits(part,1,linear)[0]*diagonal
            samples=[points[i] for i in np.linspace(0,len(points)-1,min(len(points),512),dtype=int)]
            part.calc_loop_triangles()
            for i in np.linspace(0,len(part.loop_triangles)-1,min(len(part.loop_triangles),256),dtype=int):
                samples.append(sum((points[v] for v in part.loop_triangles[i].vertices),Vector())/3)
            for p in samples:
                distance=tree.find_nearest(p)[3]
                if distance is None or distance>limit+1e-8:
                    return False
        finally:bpy.data.meshes.remove(part)
    return True


def sealed_box_supported(source, box, linear):
    """Test all six visible envelope faces using only this object's mesh."""
    points,_,tree=geometry(source,linear);a=np.array(points)
    distance=max(float(np.linalg.norm(np.ptp(a,axis=0))),1e-12)*3
    basis=np.array(box['basis']);center=np.array(box['center']);size=np.array(box['size'])
    for axis in range(3):
        other=[i for i in range(3) if i!=axis]
        for sign in (-1,1):
            hits=0
            for u in np.linspace(-.44,.44,9):
                for v in np.linspace(-.44,.44,9):
                    origin=center+sign*basis[:,axis]*(size[axis]*.5+distance*.4)
                    origin+=basis[:,other[0]]*size[other[0]]*u+basis[:,other[1]]*size[other[1]]*v
                    hit=tree.ray_cast(Vector(origin),Vector(-sign*basis[:,axis]),distance)
                    if hit[0] is not None:
                        depth=size[axis]*.5-sign*float((np.array(hit[0])-center)@basis[:,axis])
                        hits+=depth<=size[axis]*.04
            if hits/81<.80:return False
    return True


def housing_plan(source, analysis, linear):
    """Opaque closed housings and layered panels can have a simple rear body.

    Layers are preserved in their original geometry/materials. This never
    examines another scene object, and does not fill an open sheet enclosure.
    """
    if len(analysis)<2:return {},set()
    try:whole=primitives.fit(source,linear)
    except (ValueError,np.linalg.LinAlgError):return {},set()
    box=whole['box'];basis=np.array(box['basis']);size=np.array(box['size']);axis=int(np.argmin(size))
    other=[i for i in range(3) if i!=axis]
    all_points=np.array([tuple(linear@v.co) for v in source.vertices]);projected=all_points@basis
    data=[]
    for i,item in enumerate(analysis):
        ids=list({v for f in item['faces'] for v in source.polygons[f].vertices})
        coords=projected[ids];lo=coords.min(axis=0);hi=coords.max(axis=0)
        data.append((i,ids,lo,hi))
    layers=set()
    if size[axis]<min(size[other])*.30:
        layers={i for i,ids,lo,hi in data if hi[axis]-lo[axis]<size[axis]*.23
                and all(hi[j]-lo[j]>.60*size[j] for j in other)}
    bodies={}
    for i,ids,lo,hi in data:
        extent=hi-lo
        panel=len(layers)>=2 and i not in layers and extent[axis]>.55*size[axis] and all(extent[j]>.70*size[j] for j in other)
        large=bool(np.all(extent>size*.65))
        if not panel and not large:continue
        part=extract(source,analysis[i]['faces'])
        try:
            fit=analysis[i].get('detail_fit') or analysis[i].get('fit') or primitives.fit(part,linear)
            candidate=dict(fit['box'])
            if panel:
                axes=np.array(candidate['basis']);center=np.array(candidate['center']);sizes=np.array(candidate['size'])
                thin=int(np.argmin(sizes));direction=axes[:,thin]
                covers=[all_points[data[j][1]]@direction for j in sorted(layers)]
                reference=float(np.mean([c.mean() for c in covers]));middle=float(center@direction)
                sign=1 if reference>middle else -1
                lower=middle-sizes[thin]/2;upper=middle+sizes[thin]/2
                gap=max(sizes[thin]*1e-4,1e-8)
                if sign>0:upper=min(upper,min(c.min() for c in covers)-gap)
                else:lower=max(lower,max(c.max() for c in covers)+gap)
                if upper<=lower:continue
                center+=direction*((lower+upper)/2-middle);sizes[thin]=upper-lower
                # Fit a RECTANGULAR rear core inside the original envelope.
                # Scale only its two in-plane dimensions; do not bend vertices.
                available=np.minimum(center-all_points.min(axis=0),all_points.max(axis=0)-center)
                fixed=np.abs(axes[:,thin])*sizes[thin]/2
                variable=sum((np.abs(axes[:,k])*sizes[k]/2 for k in range(3) if k!=thin),np.zeros(3))
                usable=variable>1e-12
                factor=min(1.,float(np.min((available[usable]-fixed[usable])/variable[usable])))
                if factor<.80:continue
                for k in range(3):
                    if k!=thin:sizes[k]*=max(0.,factor*.99999)
                candidate.update(center=center.tolist(),size=sizes.tolist())
                bodies[i]=dict(fit,auto='BOX',box=candidate)
            elif large and wall_geometry(part,linear) and sealed_box_supported(source,candidate,linear):
                # Extend the interior core only as far as the INNER face of a
                # matching door/lid in this same mesh, never into its front skin.
                axes=np.array(candidate['basis']);center=np.array(candidate['center']);sizes=np.array(candidate['size'])
                local_center=center@axes;low=local_center-sizes/2;high=local_center+sizes/2
                for j,cover_ids,_,_ in data:
                    if j==i:continue
                    cover=all_points[cover_ids]@axes;c_lo=cover.min(axis=0);c_hi=cover.max(axis=0);e=c_hi-c_lo
                    for k in range(3):
                        other_axes=[n for n in range(3) if n!=k]
                        if e[k]>sizes[k]*.20 or not all(e[n]>sizes[n]*.70 for n in other_axes):continue
                        middle=(c_lo[k]+c_hi[k])/2
                        if middle>local_center[k]+sizes[k]*.40 and c_lo[k]>high[k]:high[k]=c_lo[k]-sizes[k]*1e-4
                        elif middle<local_center[k]-sizes[k]*.40 and c_hi[k]<low[k]:low[k]=c_hi[k]+sizes[k]*1e-4
                candidate.update(center=(axes@((low+high)/2)).tolist(),size=(high-low).tolist())
                bodies[i]=dict(fit,auto='BOX',box=candidate)
        except (ValueError,np.linalg.LinAlgError):pass
        finally:bpy.data.meshes.remove(part)
    return bodies,layers if bodies else set()


def within_original_bounds(source, candidate, linear, tolerance_ratio=.005):
    """Validate a proxy; never reshape vertices to force a fit."""
    if not candidate.vertices:return False
    a=np.array([tuple(linear@v.co) for v in source.vertices])
    b=np.array([tuple(linear@v.co) for v in candidate.vertices])
    tolerance=np.maximum(np.ptp(a,axis=0)*tolerance_ratio,1e-9)
    return bool(np.all(b.min(axis=0)>=a.min(axis=0)-tolerance)
                and np.all(b.max(axis=0)<=a.max(axis=0)+tolerance))



def lettering_parts(source, analysis, linear):
    """Find small, thin coplanar glyph groups within this object's mesh.

    A single plate/bolt is insufficient; recognized round washers are excluded.
    No name matching, scene occlusion, or deletion of Object datablocks.
    """
    if len(analysis)<5:return set()
    points=np.array([tuple(linear@v.co) for v in source.vertices])
    diagonal=max(float(np.linalg.norm(np.ptp(points,axis=0))),1e-12)
    candidates=[]
    for i,item in enumerate(analysis):
        if item.get('kind')=='PROFILE':continue
        ids=list({v for fi in item['faces'] for v in source.polygons[fi].vertices})
        p=points[ids]
        if len(p)<4:continue
        _,axes=np.linalg.eigh(np.cov(p.T));e=np.ptp(p@axes,axis=0)
        if e[0]<=max(e[1]*.08,diagonal*1e-7) and e[2]<diagonal*.3:
            candidates.append((i,p,axes[:,0],e))
    accepted=set()
    for _,points_a,normal,e in candidates:
        center=points_a.mean(axis=0)
        group=[c for c in candidates if abs(float(c[2]@normal))>.98
               and abs(float((c[1].mean(axis=0)-center)@normal))<max(e[1]*.15,diagonal*.0001)]
        if len(group)<5:continue
        combined=np.concatenate([c[1] for c in group]);_,axes=np.linalg.eigh(np.cov(combined.T))
        span=sorted(np.ptp(combined@axes,axis=0))
        if span[2]>span[1]*2 and span[0]<span[1]*.1:
            accepted.update(c[0] for c in group)
    return accepted


def build(source, analysis, quality, linear, context, stepped=False, _refine=False, _coarse_base=False):
    user_quality=quality
    stage,requested_quality,sides,envelope=detail_stage(quality) if stepped else ('Continuo',quality,None,False)
    housing,display_layers=housing_plan(source,analysis,linear) if stepped and quality<25 and not _coarse_base else ({},set())
    if _coarse_base:stage,requested_quality,sides,envelope='Volumi',1,16,True
    if stage=='Essenziale' and not _refine and len(analysis)>1 and not lettering_parts(source,analysis,linear) and not housing:
        intermediate=refined=None
        try:
            # Rebuild Volumi from the ORIGINAL each time, then consolidate its
            # recognizable volumes. Never simplify the user's previous preview.
            intermediate,first_stats=build(source,analysis,25,linear,context,stepped=True,_coarse_base=True)
            derived=analyze(intermediate,linear)
            refined,stats=build(intermediate,derived,quality,linear,context,stepped=True,_refine=True)
            error,bounds=measured_error(source,refined,linear)
            allowed,allowed_bounds=detail_limits(source,1,linear)
            intermediate.calc_loop_triangles();refined.calc_loop_triangles()
            if (len(refined.loop_triangles)<len(intermediate.loop_triangles)
                    and error<=allowed and bounds<=allowed_bounds
                    and preserves_generic_parts(source,analysis,refined,linear)):
                stats.update(parts=len(analysis),refinement_parts=len(derived),
                             max_sampled_error=error,lateral_boxes=first_stats['lateral_boxes'])
                result=refined;refined=None
                return result,stats
        finally:
            if refined:bpy.data.meshes.remove(refined)
            if intermediate:bpy.data.meshes.remove(intermediate)
    quality=requested_quality
    minimal=stage=='Essenziale'
    reduction_quality=20 if _coarse_base else quality
    profile_detail=20 if _coarse_base else quality
    output = bmesh.new()
    profile_seeds=[]
    stats = {'parts': len(analysis), 'stage':stage, 'profiles': 0, 'boxes': 0, 'details': 0, 'guarded': 0, 'defeatured': 0, 'lateral_boxes':0, 'max_sampled_error': 0, 'items': [], 'small_details_removed':0}
    result = None
    try:
        lettering=lettering_parts(source,analysis,linear) if stepped and not _refine else set()
        # Smaller glyphs disappear first; thresholds depend only on the base.
        sizes={}
        for i in lettering:
            ids={v for fi in analysis[i]['faces'] for v in source.polygons[fi].vertices}
            extent=np.ptp(np.array([tuple(linear@source.vertices[v].co) for v in ids]),axis=0)
            sizes[i]=float(np.linalg.norm(extent))
        ranks={i:k for k,i in enumerate(sorted(lettering,key=lambda i:(sizes[i],i)))}
        for item_index,item in enumerate(analysis):
            if item_index in lettering and user_quality < 8 + 14*(1-ranks[item_index]/max(1,len(lettering)-1)):
                stats['small_details_removed']+=1
                continue
            original = extract(source, item['faces'])
            protect_curve=item.get('scan',{}).get('protect_curve',False)
            original['_fab_guard_curve']=protect_curve
            simplified = None
            try:
                kind = item['kind']
                error=0.
                item['accepted_profile']=False
                shell=(item['scan'].get('wall') if 'scan' in item else wall_geometry(original,linear)) if item_index not in housing else None
                if shell:kind='DETAIL'
                if item_index in housing:
                    simplified=box_mesh(original,{'fit':housing[item_index]});kind='BOX'
                elif item_index in display_layers:
                    simplified=original.copy();kind='DETAIL'
                coarse = detail_strength(quality) > 0
                if coarse and simplified is None and not shell and not protect_curve and item['triangles'] > 12:
                    simplified, candidate_kind = detail_candidate(original, item, quality, linear,envelope,sides,minimal,profile_detail)
                    if simplified:
                        error, bounds = measured_error(original, simplified, linear)
                        allowed, allowed_bounds = detail_limits(original, quality, linear)
                        box_ok=True
                        if candidate_kind=='BOX':
                            item['box_boundary_ok']=box_boundary_supported(original,item.get('detail_fit') or item['fit'],linear)
                            box_ok=item['box_boundary_ok']
                            # A complex compact housing with strong support in
                            # every projection may discard bores/ribs at minimum
                            # detail. Keep the notch guard on near-prismatic parts.
                            fit=item.get('detail_fit') or item['fit']
                            size=fit['box']['size']
                            if ((user_quality<3 or _coarse_base) and min(size)>max(size)*.25
                                    and .15<fit['box']['score']<.35
                                    and item.get('box_alignment',0)>.45
                                    and item.get('mass_box_support',0)>.90
                                    and len(item.get('scan',{}).get('materials',[]))>1):
                                box_ok=True
                        if error <= allowed and bounds <= allowed_bounds and box_ok:
                            kind = candidate_kind
                            stats['defeatured'] += 1
                        else:
                            bpy.data.meshes.remove(simplified)
                            simplified = None
                accepted_coarse = simplified is not None
                if simplified is None and not shell and item['kind'] == 'PROFILE':
                    simplified = profile_mesh(original, item, quality, linear,envelope,sides,minimal,profile_detail)
                elif simplified is None and not shell and item['kind'] == 'BOX':
                    simplified = box_mesh(original, item)
                elif simplified is None:
                    simplified, error = conservative_mesh(original, reduction_quality, linear, context)
                if kind in {'PROFILE', 'BOX'} and not accepted_coarse:
                    error, bounds = measured_error(original, simplified, linear)
                    allowed, allowed_bounds = shape_limits(original, quality, linear)
                    if error > allowed or bounds > allowed_bounds:
                        bpy.data.meshes.remove(simplified)
                        simplified = None
                        simplified, error = conservative_mesh(original, reduction_quality, linear, context)
                        kind = 'DETAIL'
                        stats['guarded'] += 1
                if stepped and not _coarse_base and item_index not in housing and kind=='PROFILE':
                    coords=np.array([tuple(linear@v.co) for v in original.vertices])
                    _,axes=np.linalg.eigh(np.cov(coords.T));extents=sorted(np.ptp(coords@axes,axis=0))
                    if extents[0]>1e-12 and extents[2]/extents[0]>8:
                        actual,bounds=measured_error(original,simplified,linear)
                        allowed,allowed_bounds=shape_limits(original,user_quality,linear)
                        if actual>allowed or bounds>allowed_bounds:
                            bpy.data.meshes.remove(simplified)
                            simplified,error=conservative_mesh(original,user_quality,linear,context)
                            stats['guarded']+=1
                if shell:
                    candidate_wall=wall_geometry(simplified,linear)
                    if not candidate_wall or not .85<=candidate_wall[1]/shell[1]<=1.15:
                        bpy.data.meshes.remove(simplified);simplified=original.copy();stats['guarded']+=1
                item['accepted_profile']=kind=='PROFILE' and simplified.get('_fab_profile_seed') is not None
                stats['max_sampled_error'] = max(stats['max_sampled_error'], error)
                stats[{'PROFILE': 'profiles', 'BOX': 'boxes', 'DETAIL': 'details'}[kind]] += 1
                stats['lateral_boxes']+=simplified.get('fab_lateral_boxes',0)
                simplified.calc_loop_triangles(); original.calc_loop_triangles()
                if not simplified.polygons or len(simplified.loop_triangles) > len(original.loop_triangles):
                    bpy.data.meshes.remove(simplified)
                    simplified = original.copy()
                simplified.calc_loop_triangles()
                stats['items'].append({'kind': kind, 'before': item['triangles'], 'after': len(simplified.loop_triangles)})
                before_faces=set(output.faces)
                output.from_mesh(simplified)
                if simplified.get('_fab_profile_seed'):
                    profile_seeds.append(json.loads(simplified['_fab_profile_seed']))
                    ids=output.faces.layers.int.get('_fab_profile_id') or output.faces.layers.int.new('_fab_profile_id')
                    kinds=output.faces.layers.int.get('_fab_proxy_kind')
                    for face in output.faces:
                        if face not in before_faces and kinds and face[kinds]==1:
                            face[ids]=len(profile_seeds)
            finally:
                if simplified:
                    bpy.data.meshes.remove(simplified)
                bpy.data.meshes.remove(original)
        result = bpy.data.meshes.new('Fabularis — Forme composte')
        output.to_mesh(result)
        copy_materials(source, result)
        result.update()
        result['_fab_no_weighted_normals']=any(i.get('scan',{}).get('protect_curve',False) for i in analysis)
        finished = finish_normals(result, context)
        bpy.data.meshes.remove(result)
        result = finished
        result['_fab_profile_seeds']=json.dumps(profile_seeds)
        return result, stats
    except Exception:
        if result and result.users == 0:
            bpy.data.meshes.remove(result)
        raise
    finally:
        output.free()
