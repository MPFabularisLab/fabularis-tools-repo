"""Conservative removal of sealed internal components and buried whole faces.

Works on a disposable preview mesh, never on the original or on scene objects.
Containment requires a closed container and no boundary overlap. Whole-face
removal additionally requires a certified convex container. Intersecting faces
are kept rather than cutting away potentially visible geometry.
"""
import numpy as np
import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from .parts import face_components


def component(mesh, indices, points, epsilon):
    vertices=sorted({v for i in indices for v in mesh.polygons[i].vertices})
    mapping={v:i for i,v in enumerate(vertices)}
    coords=[points[v] for v in vertices]
    faces=[[mapping[v] for v in mesh.polygons[i].vertices] for i in indices]
    edges={}
    for face in faces:
        for a,b in zip(face,face[1:]+face[:1]):
            key=tuple(sorted((a,b)));edges[key]=edges.get(key,0)+1
    array=np.array(coords)
    closed=bool(edges) and all(n==2 for n in edges.values())
    data={'faces':indices,'vertices':vertices,'lo':array.min(axis=0),
          'hi':array.max(axis=0),'closed':closed,'planes':None,'tree':None}
    if not closed:
        return data
    data['tree']=BVHTree.FromPolygons(coords,faces)
    # For a convex shell each face plane supports every vertex. Orient each
    # plane away from the interior vertex mean, independent of source winding.
    middle=array.mean(axis=0);planes={}
    for face in faces:
        p=array[face];normal=np.zeros(3)
        for a,b in zip(p,np.roll(p,-1,axis=0)):normal+=np.cross(a-middle,b-middle)
        length=np.linalg.norm(normal)
        if length<epsilon*epsilon:continue
        normal/=length;origin=p.mean(axis=0)
        if np.dot(normal,origin-middle)<0:normal=-normal
        offset=float(np.dot(normal,origin))
        key=tuple(np.round(normal,7))+ (round(offset/max(epsilon,1e-15),1),)
        planes[key]=(*normal,offset)
        if len(planes)>256:break
    if planes and len(planes)<=256:
        planes=np.array(list(planes.values()))
        if np.max(array@planes[:,:3].T-planes[:,3])<=epsilon*4:
            data['planes']=planes
    return data


def strictly_inside(data, point, epsilon, distance):
    tree=data['tree'];nearest=tree.find_nearest(point)
    if nearest[3] is None or nearest[3]<=epsilon*8:return False
    votes=[]
    for vector in ((1,.371,.529),(.219,1,.413),(.337,.157,1)):
        direction=Vector(vector).normalized();origin=point.copy();crossings=0
        for _ in range(256):
            hit=tree.ray_cast(origin,direction,distance)
            if hit[0] is None:
                votes.append(crossings%2==1);break
            crossings+=1;origin=hit[0]+direction*epsilon*4
        else:return False
    return all(votes)


def clean(mesh, linear):
    """Return (mesh, stats); unchanged results retain the original mesh ID."""
    stats={'internal_faces_removed':0,'internal_components_removed':0}
    if not mesh.polygons or not mesh.vertices:return mesh,stats
    points=[linear@v.co for v in mesh.vertices]
    array=np.array(points);diagonal=float(np.linalg.norm(np.ptp(array,axis=0)))
    if diagonal<1e-12:return mesh,stats
    epsilon=max(diagonal*1e-7,1e-10)
    groups=[component(mesh,indices,points,epsilon) for indices in face_components(mesh)]
    containers=[g for g in groups if g['closed']]
    if not containers:return mesh,stats
    removed=set();erased=set()
    # A connected component cannot leave a closed container without crossing
    # its boundary. BVH overlap is conservative: ambiguous pairs are retained.
    for i,child in enumerate(groups):
        for parent in containers:
            if parent is child or not (np.all(child['lo']>parent['lo']+epsilon)
                    and np.all(child['hi']<parent['hi']-epsilon)):
                continue
            if child['tree'] is None:
                local_vertices=child['vertices'];lookup={v:k for k,v in enumerate(local_vertices)}
                child_tree=BVHTree.FromPolygons([points[v] for v in local_vertices],
                    [[lookup[v] for v in mesh.polygons[f].vertices] for f in child['faces']])
            else:child_tree=child['tree']
            if parent['tree'].overlap(child_tree):continue
            if strictly_inside(parent,points[child['vertices'][0]],epsilon,diagonal*3):
                removed.update(child['faces']);erased.add(i);break
    # A polygon whose complete convex hull lies strictly inside another convex
    # closed shell has no exterior portion. No centroid-only visibility guess.
    convex=[g for g in containers if g['planes'] is not None]
    for i,group in enumerate(groups):
        if i in erased:continue
        for fi in group['faces']:
            face=array[list(mesh.polygons[fi].vertices)]
            lo=face.min(axis=0);hi=face.max(axis=0)
            for parent in convex:
                if parent is group or not (np.all(lo>parent['lo']+epsilon)
                        and np.all(hi<parent['hi']-epsilon)):
                    continue
                planes=parent['planes']
                if np.max(face@planes[:,:3].T-planes[:,3]) < -epsilon:
                    removed.add(fi);break
    # Matching contact caps on opposite sides of two closed solids are internal
    # dividers. Same-side duplicates are kept, so an outside skin cannot vanish.
    contacts={}
    for group in convex:
        middle=(group['lo']+group['hi'])/2
        for fi in group['faces']:
            if fi in removed:continue
            coords=array[list(mesh.polygons[fi].vertices)]
            key=tuple(sorted(tuple(np.rint(p/epsilon).astype(np.int64)) for p in coords))
            normal=np.zeros(3)
            for a,b in zip(coords,np.roll(coords,-1,axis=0)):normal+=np.cross(a-middle,b-middle)
            length=np.linalg.norm(normal)
            if length<epsilon*epsilon:continue
            normal/=length
            if np.dot(normal,coords.mean(axis=0)-middle)<0:normal=-normal
            if key in contacts:
                old_fi,old_group,old_normal=contacts[key]
                if old_group is not group and np.dot(normal,old_normal)<-.999:
                    removed.update((old_fi,fi))
            else:contacts[key]=(fi,group,normal)
    if not removed or len(removed)>=len(mesh.polygons):return mesh,stats
    result=mesh.copy();bm=bmesh.new()
    try:
        bm.from_mesh(result);bm.faces.ensure_lookup_table()
        bmesh.ops.delete(bm,geom=[bm.faces[i] for i in sorted(removed)],context='FACES_ONLY')
        loose_edges=[e for e in bm.edges if not e.link_faces]
        if loose_edges:bmesh.ops.delete(bm,geom=loose_edges,context='EDGES')
        loose_vertices=[v for v in bm.verts if not v.link_faces]
        if loose_vertices:bmesh.ops.delete(bm,geom=loose_vertices,context='VERTS')
        bm.to_mesh(result);result.update()
        stats.update(internal_faces_removed=len(removed),internal_components_removed=len(erased))
        return result,stats
    except Exception:
        bpy.data.meshes.remove(result);raise
    finally:bm.free()
