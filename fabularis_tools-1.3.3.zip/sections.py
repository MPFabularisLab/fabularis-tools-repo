import bpy


class FABULARIS_PT_section_collections(bpy.types.Panel):
    bl_label = "Collection e gerarchie"
    bl_idname = "FABULARIS_SECTION_COLLECTIONS"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fabularis Tools"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 2
    @classmethod
    def poll(cls, context):
        from .preferences import is_section_enabled
        return is_section_enabled(context, "show_collections")
    def draw(self, context): pass

class FABULARIS_PT_section_optimization(bpy.types.Panel):
    bl_label = "Ottimizzazione"
    bl_idname = "FABULARIS_SECTION_OPTIMIZATION"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fabularis Tools"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 3
    @classmethod
    def poll(cls, context):
        from .preferences import is_section_enabled
        return is_section_enabled(context, "show_optimization")
    def draw(self, context): pass

class FABULARIS_PT_section_render(bpy.types.Panel):
    bl_label = "Render"
    bl_idname = "FABULARIS_SECTION_RENDER"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fabularis Tools"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 4
    @classmethod
    def poll(cls, context):
        from .preferences import is_section_enabled
        return is_section_enabled(context, "show_render")
    def draw(self, context): pass

class FABULARIS_PT_section_uv(bpy.types.Panel):
    bl_label = "UV"
    bl_idname = "FABULARIS_SECTION_UV"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fabularis Tools"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 5
    @classmethod
    def poll(cls, context):
        from .preferences import is_section_enabled
        return is_section_enabled(context, "show_uv")
    def draw(self, context): pass

class FABULARIS_PT_section_other(bpy.types.Panel):
    bl_label = "Altro"
    bl_idname = "FABULARIS_SECTION_OTHER"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fabularis Tools"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 7
    @classmethod
    def poll(cls, context):
        from .preferences import is_section_enabled
        return is_section_enabled(context, "show_other")
    def draw(self, context): pass

classes = (FABULARIS_PT_section_collections,
           FABULARIS_PT_section_optimization, FABULARIS_PT_section_render,
           FABULARIS_PT_section_uv, FABULARIS_PT_section_other)

def register():
    for cls in classes: bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
