"""One wall-clock measurement per execution; no background Blender access."""
from time import perf_counter
import bpy


def format_elapsed(seconds):
    minutes,seconds=divmod(max(0,seconds),60)
    if minutes>=60:
        hours,minutes=divmod(int(minutes),60)
        return f'{hours:d} h {minutes:02d} min {seconds:04.1f} s'
    if minutes:return f'{int(minutes)} min {seconds:04.1f} s'
    return f'{seconds:.1f} s'


class CalculationTimer:
    def __init__(self,context,clock=perf_counter):
        self.context=context;self.clock=clock;self.started=clock();self.last=-float('inf')
        self.elapsed=0;self.finished=False;self.interval=1.5;self._next_check=0;self.stage=''
        self.update(force=True)

    def update(self,force=False):
        now=self.clock()
        if not force and now<self._next_check:return
        self.last=now;self.elapsed=now-self.started
        scene=self.context.scene
        scene.fab_holes_elapsed=self.elapsed
        scene.fab_holes_time=('Tempo: 'if self.finished else'Calcolo: ')+format_elapsed(self.elapsed)
        if self.stage and not self.finished:scene.fab_holes_time+=' · '+self.stage
        if bpy.app.background:
            self._next_check=now+self.interval;return
        for window in self.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type=='VIEW_3D':area.tag_redraw()
        # Redraw only, without processing input or allowing a second command
        # to edit a mesh while its BMesh transaction is still running.
        try:bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP',iterations=1)
        except RuntimeError:pass
        # Measure redraw overhead and start the quiet interval AFTER drawing.
        # In a heavy viewport, drawing can itself take longer than the old
        # interval: timestamping before it caused another redraw every pulse.
        done=self.clock();cost=max(0,done-now)
        self.interval=max(1.5,cost*40)
        self._next_check=done+self.interval

    def set_stage(self,stage):
        self.stage=stage

    def finish(self):
        self.finished=True;self.update(force=True)
