"""Selected mesh hole removal: boundary caps and planar/curved CAD cavities.

CAD recognition is topological: inner loops of coplanar face patches delimit
cavity faces. Cylindrical profiles recover mouths across CAD seams.
The exterior surface is not remeshed or decimated.
"""
import math
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree

_progress = None

def pulse():
    if _progress is not None:_progress()


def polygon_area(points):
    return abs(sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(points, points[1:] + points[:1]))) / 2


def polygon_bounds(polygon):
    return (min(p[0]for p in polygon),max(p[0]for p in polygon),
            min(p[1]for p in polygon),max(p[1]for p in polygon))


def containing_loops(polygons,areas):
    # Bounding-box rejection is exact: an enclosed polygon cannot extend
    # beyond its container. Most CAD holes are disjoint and fail this cheap
    # test, avoiding millions of full point-in-polygon walks.
    bounds=[polygon_bounds(p)for p in polygons]
    def containers(i):
        pulse();polygon=polygons[i];a=bounds[i];candidates=[]
        for j,(outer,b)in enumerate(zip(polygons,bounds)):
            if areas[j]<=areas[i]or i==j:continue
            if a[0]<b[0]or a[1]>b[1]or a[2]<b[2]or a[3]>b[3]:continue
            if all(point_inside(v,outer)for v in polygon):candidates.append(j)
        return candidates
    return containers


def point_inside(point, polygon):
    x, y = point
    inside = False
    for a, b in zip(polygon, polygon[1:] + polygon[:1]):
        if (a[1] > y) != (b[1] > y):
            cross_x = a[0] + (y - a[1]) * (b[0] - a[0]) / (b[1] - a[1])
            if x < cross_x:
                inside = not inside
    return inside


def ordered_loops(edges):
    """Reject branched/open edge components; return ordered vertices + edges."""
    remaining = set(edges)
    seeds = iter(sorted(remaining, key=lambda e:e.index))
    result = []
    while remaining:
        first = next(e for e in seeds if e in remaining); remaining.remove(first)
        component = {first}
        stack = [first]
        while stack:
            for v in stack.pop().verts:
                for e in v.link_edges:
                    if e in remaining:
                        remaining.remove(e)
                        component.add(e)
                        stack.append(e)
        verts = {v for e in component for v in e.verts}
        if len(verts) < 3 or any(sum(e in component for e in v.link_edges) != 2 for v in verts):
            continue
        start = first.verts[0]
        current, previous = start, None
        ordered, path = [], []
        while True:
            ordered.append(current)
            edge = next(e for e in current.link_edges if e in component and e != previous)
            path.append(edge)
            current = edge.other_vert(current)
            if current == start:
                break
            previous = edge
        result.append((ordered, path))
    return result


def planar(verts, tolerance):
    a = verts[0].co
    b = max((v.co - a for v in verts), key=lambda d: d.length_squared)
    n = max((b.cross(v.co - a) for v in verts), key=lambda d: d.length_squared)
    if n.length_squared == 0:
        return False
    n.normalize()
    return all(abs((v.co - a).dot(n)) <= tolerance for v in verts)


def graph_cycles(edges, maximum=None):
    """Short fundamental cycles, including contours attached to CAD seams."""
    adjacency = {}
    for edge in sorted(edges, key=lambda e:e.index):
        for vertex in edge.verts:
            adjacency.setdefault(vertex, []).append(edge)
    seen = set(); active = set(); parent = {}; depth = {}; result = []
    for root in adjacency:
        pulse()
        if root in seen:
            continue
        seen.add(root); active.add(root); depth[root] = 0
        stack = [(root, iter(sorted(adjacency[root], key=lambda e: (e.calc_length(),e.index))))]
        while stack:
            vertex, iterator = stack[-1]
            edge = next(iterator, None)
            if edge is None:
                active.remove(vertex); stack.pop(); continue
            other = edge.other_vert(vertex)
            if other not in seen:
                parent[other] = (vertex, edge); depth[other] = depth[vertex]+1
                seen.add(other); active.add(other)
                stack.append((other, iter(sorted(adjacency[other], key=lambda e: (e.calc_length(),e.index)))))
            elif other in active and depth[other] < depth[vertex]-1:
                if maximum is not None and depth[vertex]-depth[other]+1 > maximum:
                    continue
                vertices = [vertex]; path = []; current = vertex
                while current != other:
                    current, previous = parent[current]
                    path.append(previous); vertices.append(current)
                path.append(edge)
                result.append((vertices, path))
    return result


def projected_cycles(bm, edges):
    """Walk the faces of projected crease graphs, rather than arbitrary DFS paths."""
    normals = []
    for face in sorted(bm.faces, key=lambda f: f.calc_area(), reverse=True):
        normal = face.normal.copy()
        if normal.length_squared and all(abs(normal.dot(n)) < .98 for n in normals):
            normals.append(normal)
        if len(normals) == 6:
            break
    result = []; known = set()
    for normal in normals + [-n for n in normals]:
        pulse()
        u = normal.orthogonal().normalized(); v = normal.cross(u)
        adjacency = {}
        for edge in edges:
            direction = edge.verts[1].co-edge.verts[0].co
            if abs(direction.dot(normal)) > direction.length*.95:
                continue
            if max(f.normal.dot(normal) for f in edge.link_faces) < .55:
                continue
            for vertex in edge.verts:
                tangent = edge.other_vert(vertex).co-vertex.co
                adjacency.setdefault(vertex, []).append((math.atan2(tangent.dot(v), tangent.dot(u)), edge))
        ordered = {vertex: [e for angle,e in sorted(items, key=lambda p:p[0])]
                   for vertex,items in adjacency.items()}
        visited = set()
        for start, neighbors in ordered.items():
            for first in neighbors:
                if (start, first) in visited:
                    continue
                vertex, edge = start, first; verts = []; path = []
                local = set()
                while (vertex, edge) not in local:
                    local.add((vertex, edge)); visited.add((vertex, edge))
                    verts.append(vertex); path.append(edge)
                    other = edge.other_vert(vertex)
                    links = ordered[other]
                    edge = links[(links.index(edge)-1) % len(links)]
                    vertex = other
                if vertex == start and edge == first and len(verts)>=3 and len(set(verts))==len(verts):
                    key=frozenset(path)
                    if key not in known:
                        known.add(key); result.append((verts,path))
    return result


def filled_contour(verts, edges):
    """Existing triangles/ngons spanning a contour are a surface, not a hole."""
    vertices = set(verts)
    faces = {f for v in verts for f in v.link_faces if all(p in vertices for p in f.verts)}
    if not faces:
        return False
    boundary = {e for f in faces for e in f.edges if sum(other in faces for other in e.link_faces)==1}
    return boundary == set(edges)


def silhouette_rims(bm, tolerance, layer, existing):
    """Recover through-openings in thin metal parts using only their own skin."""
    bounds = [(min(v.co[k] for v in bm.verts),max(v.co[k] for v in bm.verts)) for k in range(3)]
    spans = [b-a for a,b in bounds]; drop = min(range(3),key=lambda k:spans[k])
    axes = [k for k in range(3) if k!=drop]
    if spans[drop] >= min(spans[k] for k in axes)*.15:
        return []
    normal = Vector(); normal[drop] = 1
    tree = BVHTree.FromBMesh(bm)
    padding = max(spans)*.01+tolerance
    distance = spans[drop]+padding*2

    def occupied(point):
        point = point.copy(); point[drop] = bounds[drop][0]-padding
        return tree.ray_cast(point,normal,distance)[0] is not None

    boundary = []
    for edge in bm.edges:
        if not edge.is_manifold:
            continue
        tangent = edge.verts[1].co-edge.verts[0].co; tangent[drop] = 0
        if tangent.length <= tolerance:
            continue
        inward = normal.cross(tangent).normalized()
        step = min(tangent.length*1e-3,max(spans)*1e-4)
        middle = (edge.verts[0].co+edge.verts[1].co)*.5
        if occupied(middle+inward*step) != occupied(middle-inward*step):
            boundary.append(edge)
    contours = ordered_loops(boundary)+graph_cycles(boundary)
    known = {frozenset(r['edges']) for r in existing}; result = []
    for verts,edges in contours:
        key = frozenset(edges)
        if key in known or filled_contour(verts,edges):
            continue
        support = {max(edge.link_faces,key=lambda f:abs(f.normal.dot(normal))) for edge in edges}
        outward = normal.copy()
        if math.fsum(f.normal.dot(normal)*f.calc_area() for f in support)<0:
            outward.negate()
        face = min(support,key=lambda f:f.index)
        rim = {'verts':verts,'edges':edges,'support':support,'material':face.material_index,
               'normal':outward,'component':face[layer]}
        if aperture_rim(rim,tolerance):
            known.add(key); result.append(rim)
    return result


def open_boundary_loops(bm, patch=None):
    """Follow each boundary face fan, allowing several openings at a vertex."""
    boundary = ({e for f in patch for e in f.edges if sum(other in patch for other in e.link_faces)==1}
                if patch is not None else {e for e in bm.edges if e.is_boundary})
    remaining = set(boundary)
    seeds = iter(sorted(remaining, key=lambda e:e.index))
    result = []
    while remaining:
        first = next(e for e in seeds if e in remaining); remaining.remove(first); edge = first
        loop = next(loop for loop in edge.link_loops if patch is None or loop.face in patch)
        path = []; verts = []; visited = set()
        while edge not in visited:
            visited.add(edge); remaining.discard(edge)
            path.append(edge); verts.append(loop.vert)
            candidate = loop.link_loop_next
            steps = set()
            while candidate.edge not in boundary and candidate.edge.is_manifold and candidate not in steps:
                steps.add(candidate)
                candidate = candidate.link_loop_radial_next.link_loop_next
            if candidate.edge not in boundary:
                break
            edge, loop = candidate.edge, candidate
        else:
            if edge == first and len(verts) >= 3:
                # A pinched vertex can make one fan walk visit several holes.
                vertices = [verts[0]]; segments = []; positions = {verts[0]: 0}
                for i, segment in enumerate(path):
                    segments.append(segment)
                    vertex = verts[(i+1) % len(verts)]
                    if vertex in positions:
                        start = positions[vertex]
                        if len(vertices)-start >= 3:
                            result.append((vertices[start:], segments[start:]))
                        for old in vertices[start+1:]:
                            positions.pop(old, None)
                        vertices = vertices[:start+1]; segments = segments[:start]
                    else:
                        positions[vertex] = len(vertices); vertices.append(vertex)
    return result


def planar_rims(bm, tolerance, component_layer=None, extended=False):
    unvisited = set(bm.faces)
    rims = []
    seeds = iter(sorted(bm.faces, key=(lambda f:(-f.calc_area(),f.index)) if extended else (lambda f:f.index)))
    plane_tolerance = tolerance*(64 if extended else 1)
    cosine = math.cos(math.radians(3 if extended else .1))
    while unvisited:
        pulse()
        seed = next(f for f in seeds if f in unvisited)
        unvisited.remove(seed)
        normal = seed.normal.copy()
        origin = seed.verts[0].co.copy()
        patch = {seed}
        stack = [seed]
        while stack:
            for e in stack.pop().edges:
                for f in e.link_faces:
                    if f in unvisited and f.normal.dot(normal) > cosine and all(abs((v.co - origin).dot(normal)) <= plane_tolerance for v in f.verts):
                        unvisited.remove(f)
                        patch.add(f)
                        stack.append(f)
        border = {e for f in patch for e in f.edges if sum(other in patch for other in e.link_faces) == 1}
        loops = ordered_loops(border)
        if len(loops) < 2:
            continue
        drop = max(range(3), key=lambda i: abs(normal[i]))
        axes = [i for i in range(3) if i != drop]
        projected = [[(v.co[axes[0]], v.co[axes[1]]) for v in verts] for verts, _ in loops]
        # An inner boundary lies inside exactly one outer boundary. Nested or
        # touching loops are ambiguous and left alone.
        areas = [polygon_area(p) for p in projected]
        containers=containing_loops(projected,areas)
        for i, (verts, edges) in enumerate(loops):
            rim_tolerance = min(tolerance, min(e.calc_length() for e in edges) * .01)
            containing = containers(i)
            if len(containing) != 1 or not all(e.is_manifold for e in edges):
                continue
            # Nested loops of overlapping/coplanar CAD faces can describe a
            # disk rather than a missing area. The supporting surface must be
            # on the OUTSIDE of every rim edge in the projected polygon.
            filled_disk = False
            for edge in edges:
                loop = next(loop for loop in edge.link_loops if loop.face in patch)
                tangent = loop.link_loop_next.vert.co - loop.vert.co
                inward = normal.cross(tangent).normalized()
                middle = (edge.verts[0].co + edge.verts[1].co) * .5
                sample = middle + inward * max(edge.calc_length() * 1e-3, rim_tolerance * .5)
                if point_inside((sample[axes[0]], sample[axes[1]]), projected[i]):
                    filled_disk = True
                    break
            if filled_disk:
                continue
            # An inner contour can also surround a protruding shaft or boss.
            # A hole's adjacent walls recede INTO the support plane; a boss
            # extends OUT of it. Do not treat a boss as a removable cavity.
            rim_vertices = set(verts)
            depths = [(v.co - origin).dot(normal) for e in edges
                      for face in e.link_faces if face not in patch for v in face.verts if v not in rim_vertices]
            rim_depths = [(v.co-origin).dot(normal) for v in verts]
            if not depths or min(depths) >= min(rim_depths)-rim_tolerance or max(depths) > max(rim_depths)+rim_tolerance:
                continue
            rims.append({'verts': verts, 'edges': edges, 'support': patch,
                         'material': seed.material_index, 'normal': normal,
                         'component': seed[component_layer] if component_layer else None})
    return rims


def exterior_rims(rims, tolerance, tree=None):
    """Remove nested mouths of counterbores inside an outer virtual cap.

    An internal shoulder's contour projects wholly into an outer aperture in
    the outward normal direction. It must not become a traversal barrier.
    """
    result = []
    cached = {}
    by_component={}
    for rim in rims:
        by_component.setdefault(rim.get('component'),[]).append(rim)
        normal = rim['normal']
        drop = max(range(3), key=lambda i:abs(normal[i]))
        axes = [i for i in range(3) if i != drop]
        cached[id(rim)] = (axes, [(v.co[axes[0]],v.co[axes[1]]) for v in rim['verts']],
                           [(min(v.co[k] for v in rim['verts']),max(v.co[k] for v in rim['verts'])) for k in range(3)])
    for rim in rims:
        internal = False
        direction = rim['normal']
        candidates=by_component[rim['component']]if rim.get('component')is not None else rims
        for outer in candidates:
            if outer is rim or direction.dot(outer['normal']) < .999:
                continue
            if rim.get('component') is not None and rim['component'] != outer.get('component'):
                continue
            n = outer['normal']
            origin = outer['verts'][0].co
            distance = (origin - rim['verts'][0].co).dot(n) / direction.dot(n)
            if distance <= tolerance:
                continue
            axes, polygon, bounds = cached[id(outer)]
            own_bounds = cached[id(rim)][2]
            if any(own_bounds[k][0]+direction[k]*distance < bounds[k][0]-tolerance or
                   own_bounds[k][1]+direction[k]*distance > bounds[k][1]+tolerance for k in axes):
                continue
            points = [v.co + direction * distance for v in rim['verts']]
            if all(point_inside((p[axes[0]], p[axes[1]]), polygon) for p in points):
                # Separate bores aligned on the same axis are not necessarily
                # shoulders of one cavity. Solid material between them means
                # each must keep its own mouth as a traversal barrier.
                if tree:
                    center = sum((v.co for v in rim['verts']), Vector()) / len(rim['verts'])
                    epsilon = tolerance * 2
                    if distance > epsilon and tree.ray_cast(center + direction * epsilon, direction, distance - epsilon)[0] is not None:
                        continue
                internal = True
                break
        if not internal:
            result.append(rim)
    return result


def curved_rims(bm, tolerance, component_layer, existing, extended=False):
    """Recognize bore mouths crossing several facets of a curved surface.

    Mouth edges turn sharply into the bore, while the support can span
    several differently oriented faces. Negative cavity volume and the
    component guard still decide whether removing the bounded region is safe.
    """
    crease = 20 if extended else 35
    sharp = [e for e in bm.edges if e.is_manifold and
             e.link_faces[0].normal.dot(e.link_faces[1].normal) < math.cos(math.radians(crease))]
    known = {frozenset(r['edges']) for r in existing}
    result = []
    loops = ordered_loops(sharp)
    # A long CAD seam can meet an otherwise closed small mouth and make the
    # complete sharp-edge component branched. Inspect the same graph at the
    # edge scales already observed in its closed contours.
    seen = {frozenset(edges) for verts, edges in loops}
    if extended:
        for verts, edges in projected_cycles(bm, sharp):
            key = frozenset(edges)
            if key not in seen:
                seen.add(key); loops.append((verts, edges))
    if extended and len(sharp) < 30000:
        for verts, edges in graph_cycles(sharp):
            key = frozenset(edges)
            if key not in seen:
                seen.add(key); loops.append((verts, edges))
    cutoffs = []
    for length in sorted(max(e.calc_length() for e in edges) for verts, edges in loops):
        if not cutoffs or length > cutoffs[-1]*1.5:
            cutoffs.append(length*1.05)
    for cutoff in cutoffs:
        pulse()
        for verts, edges in ordered_loops([e for e in sharp if e.calc_length() <= cutoff]):
            key = frozenset(edges)
            if key not in seen:
                seen.add(key); loops.append((verts, edges))
    for verts, edges in loops:
        span = max(max(v.co[k] for v in verts) - min(v.co[k] for v in verts) for k in range(3))
        if extended and filled_contour(verts, edges):
            continue
        if frozenset(edges) in known or (not extended and planar(verts, min(tolerance, span * 1e-6))):
            continue
        origin = verts[0].co
        normal = Vector()
        for a, b in zip(verts, verts[1:] + verts[:1]):
            normal += (a.co - origin).cross(b.co - origin)
        if normal.length_squared == 0:
            continue
        normal.normalize()
        drop = max(range(3), key=lambda k:abs(normal[k]))
        axes = [k for k in range(3) if k != drop]
        polygon = [(float(v.co[axes[0]]),float(v.co[axes[1]])) for v in verts]
        support = set()
        sign = None
        for edge in edges:
            ranked = sorted(edge.link_faces, key=lambda f: abs(f.normal.dot(normal)), reverse=True)
            aligned = ranked[0].normal.dot(normal)
            # The support faces point along the mouth axis; bore walls do not.
            if abs(aligned) < .75 or abs(ranked[1].normal.dot(normal)) > .5:
                break
            direction = aligned > 0
            if sign is not None and sign != direction:
                break
            sign = direction
            support.add(ranked[0])
        else:
            if not sign:
                normal.negate()
            face = min(support,key=lambda f:f.index)
            result.append({'verts': verts, 'edges': edges, 'support': support,
                           'material': face.material_index, 'normal': normal,
                           'component': face[component_layer]})
    result += cylindrical_rims(loops, component_layer, existing + result)
    return result


def circle_profile(verts, axis=None):
    """Fit a circular cross section in local coordinates, independently of shading."""
    origin = sum((v.co for v in verts), Vector()) / len(verts)
    normal = axis.copy() if axis is not None else Vector()
    if axis is None:
        for a, b in zip(verts, verts[1:] + verts[:1]):
            normal += (a.co - origin).cross(b.co - origin)
    if normal.length_squared == 0:
        return None
    normal.normalize()
    u = normal.orthogonal().normalized()
    v = normal.cross(u)
    points = [((p.co-origin).dot(u), (p.co-origin).dot(v)) for p in verts]
    xx = math.fsum(x*x for x,y in points)
    xy = math.fsum(x*y for x,y in points)
    yy = math.fsum(y*y for x,y in points)
    determinant = xx*yy-xy*xy
    if determinant <= xx*yy*1e-8:
        return None
    bx = .5*math.fsum(x*(x*x+y*y) for x,y in points)
    by = .5*math.fsum(y*(x*x+y*y) for x,y in points)
    cx, cy = (bx*yy-by*xy)/determinant, (by*xx-bx*xy)/determinant
    center = origin + u*cx + v*cy
    radii = [math.hypot(x-cx,y-cy) for x,y in points]
    radius = math.fsum(radii)/len(radii)
    if radius <= 0 or max(abs(r-radius) for r in radii) > radius*.025:
        return None
    return center, normal, radius


def cylindrical_rims(loops, component_layer, existing, bm=None, extended=False):
    """Trace the complete walls of a bore from a recognized round contour.

    CAD triangles on the surrounding tube can have very different normals.
    Cylinder membership recovers the opposite mouth without relying on those
    normals or requiring that both mouths form isolated sharp-edge loops.
    """
    known = {frozenset(r['edges']) for r in existing}
    result = []
    checked = set()
    def profiles():
        for verts, edges in loops:
            span = max(max(v.co[k] for v in verts)-min(v.co[k] for v in verts) for k in range(3))
            if not extended and planar(verts, span*1e-6):
                continue
            profile = circle_profile(verts)
            if profile is not None:
                yield profile, edges
        if bm is not None and (len(bm.faces) < 30000 or not any(e.is_boundary for e in bm.edges)):
            for edge in bm.edges:
                if not edge.is_manifold or any(f in checked for f in edge.link_faces):
                    continue
                angle = edge.calc_face_angle_signed()
                if not -math.radians(100) < angle < -math.radians(5):
                    continue
                axis = edge.verts[1].co-edge.verts[0].co
                if axis.length_squared == 0:
                    continue
                axis.normalize()
                verts = list({v for f in edge.link_faces for v in f.verts})
                profile = circle_profile(verts, axis)
                if profile is None or edge.calc_length() < profile[2]*.005:
                    continue
                toward_center = profile[0]-(edge.verts[0].co+edge.verts[1].co)*.5
                if all(f.normal.dot(toward_center) > 0 for f in edge.link_faces):
                    yield profile, [edge]

    for profile, edges in profiles():
        center, axis, radius = profile
        tolerance = radius*(.05 if extended else .025)
        fits = {}

        def on_wall(face):
            if face not in fits:
                fits[face] = all(abs((v.co-center-axis*(v.co-center).dot(axis)).length-radius)
                                 <= tolerance for v in face.verts)
            return fits[face]

        seeds = {f for e in edges for f in e.link_faces if on_wall(f)}
        if not seeds or seeds & checked:
            continue
        region = set(seeds); queue = list(seeds)
        while queue:
            for edge in queue.pop().edges:
                for face in edge.link_faces:
                    if face not in region and on_wall(face):
                        region.add(face); queue.append(face)
        checked.update(region)
        # A previously created cap can also have all its vertices on the
        # cylinder. It is a surface, not another cavity to delete and recap.
        if not any(abs(f.normal.dot(axis)) < .35 and
                   max((v.co-center).dot(axis) for v in f.verts) -
                   min((v.co-center).dot(axis) for v in f.verts) > radius*.01
                   for f in region):
            continue
        boundary = {e for f in region for e in f.edges if sum(n in region for n in e.link_faces) == 1}
        mouths = ordered_loops(boundary)
        if not mouths or {e for v, path in mouths for e in path} != boundary:
            continue
        candidates = []
        for mouth_verts, mouth_edges in mouths:
            if not all(e.is_manifold for e in mouth_edges):
                break
            support = {f for e in mouth_edges for f in e.link_faces if f not in region}
            if not support:
                break
            normal = axis.copy()
            if math.fsum(f.normal.dot(normal)*f.calc_area() for f in support) < 0:
                normal.negate()
            face = min(support,key=lambda f:f.index)
            candidates.append({'verts': mouth_verts, 'edges': mouth_edges, 'support': support,
                               'material': face.material_index, 'normal': normal,
                               'component': face[component_layer]})
        else:
            if cavity_volume(region, candidates) >= -max(cavity_volume_tolerance(region, candidates), radius**3*1e-8):
                continue
            for rim in candidates:
                key = frozenset(rim['edges'])
                if key not in known:
                    known.add(key); result.append(rim)
    return result


def component_guard(bm):
    """Tag every face island and remember its external world-space bounds."""
    layer = bm.faces.layers.int.new('fab_hole_guard')
    remaining = set(bm.faces)
    bounds = {}
    while remaining:
        seed = remaining.pop()
        faces, queue = {seed}, [seed]
        while queue:
            for e in queue.pop().edges:
                for other in e.link_faces:
                    if other in remaining:
                        remaining.remove(other)
                        faces.add(other)
                        queue.append(other)
        component_id = len(bounds) + 1
        verts = {v for f in faces for v in f.verts}
        bounds[component_id] = [(min(v.co[k] for v in verts), max(v.co[k] for v in verts)) for k in range(3)]
        for face in faces:
            face[layer] = component_id
    return layer, bounds


def check_components(bm, layer, original, tolerance):
    surviving = {}
    for face in bm.faces:
        surviving.setdefault(face[layer], set()).update(face.verts)
    for component_id, bounds in original.items():
        verts = surviving.get(component_id)
        if not verts:
            raise RuntimeError('Chiusura non applicata: cancellerebbe una parte della mesh. Oggetto conservato.')
        current = [(min(v.co[k] for v in verts), max(v.co[k] for v in verts)) for k in range(3)]
        if any(abs(a-b) > tolerance * 2 for before, after in zip(bounds, current) for a, b in zip(before, after)):
            raise RuntimeError('Chiusura non applicata: altererebbe l’ingombro esterno di una parte. Oggetto conservato.')
    bm.faces.layers.int.remove(layer)


def signed_volume(verts, origin):
    # Subtract in Python double precision, not with float32 Vector arithmetic.
    points = [tuple(float(v.co[k]) - float(origin[k]) for k in range(3)) for v in verts]
    a = points[0]
    return math.fsum((a[0]*(b[1]*c[2]-b[2]*c[1]) +
                      a[1]*(b[2]*c[0]-b[0]*c[2]) +
                      a[2]*(b[0]*c[1]-b[1]*c[0])) / 6
                     for b, c in zip(points[1:-1], points[2:]))


def orient_small_components(bm, layer):
    """Correct closed islands whose tiny volume confused normal recalculation."""
    groups = {}
    for face in bm.faces:
        groups.setdefault(face[layer], []).append(face)
    for faces in groups.values():
        edges = {e for face in faces for e in face.edges}
        if not all(e.is_manifold for e in edges):
            continue
        origin = faces[0].verts[0].co.copy()
        if math.fsum(signed_volume(list(f.verts), origin) for f in faces) < 0:
            bmesh.ops.reverse_faces(bm, faces=faces)
    bm.normal_update()


def fill_loop(bm, edges):
    # Direct construction avoids the generic fill operator traversing a large
    # damaged CAD shell for each small contour, and keeps every rim vertex.
    loops = ordered_loops(edges)
    if len(loops) == 1 and len(loops[0][1]) == len(edges) and all(e.is_boundary for e in edges):
        try:
            return [bm.faces.new(loops[0][0])]
        except ValueError:
            pass
    return []


def preserves_component_bounds(bm, region, matching, layer, bounds, tolerance):
    affected = {f[layer] for f in region}
    # Most bore-wall vertices lie strictly inside the component bounds.
    # Inspect exactly the vertices that would disappear before doing the
    # expensive full-component check. Surviving rim vertices keep the caps.
    capped = {v for rim in matching for v in rim['verts']}
    disappearing = {v for face in region for v in face.verts
                    if v not in capped and all(f in region for f in v.link_faces)}
    if all(all(bounds[f[layer]][k][0]+tolerance*2 < v.co[k] < bounds[f[layer]][k][1]-tolerance*2
               for k in range(3)) for v in disappearing for f in v.link_faces):
        return True
    surviving = {i: set() for i in affected}
    for face in bm.faces:
        if face not in region and face[layer] in affected:
            surviving[face[layer]].update(face.verts)
    for rim in matching:
        component_id = rim['component']
        if component_id in surviving:
            surviving[component_id].update(rim['verts'])
    for component_id, verts in surviving.items():
        if not verts:
            return False
        current = [(min(v.co[k] for v in verts), max(v.co[k] for v in verts)) for k in range(3)]
        if any(abs(a-b) > tolerance * 2 for before, after in zip(bounds[component_id], current) for a, b in zip(before, after)):
            return False
    return True


def cavity_volume(region, matching):
    """Signed closed volume of a surface region with virtual mouth caps.

    In a consistently oriented solid, inner cavity surfaces enclose negative
    volume; the exterior body encloses positive volume. This also handles
    communicating bores whose interior shoulders are coplanar with an entry.
    """
    origin = matching[0]['verts'][0].co

    values = [signed_volume(list(face.verts), origin) for face in region]
    for rim in matching:
        verts = rim['verts']
        edge = rim['edges'][0]
        loop = next(loop for loop in edge.link_loops if loop.face in region)
        same_direction = loop.vert == verts[0] and loop.link_loop_next.vert == verts[1]
        values.append(signed_volume(list(reversed(verts)) if same_direction else verts, origin))
    return math.fsum(values)


def cavity_volume_tolerance(region, matching):
    """Local numerical tolerance: tiny bores must not inherit body volume."""
    verts = {v for face in region for v in face.verts}
    verts.update(v for rim in matching for v in rim['verts'])
    spans = [max(float(v.co[k]) for v in verts) - min(float(v.co[k]) for v in verts)
             for k in range(3)]
    return math.prod(spans) * 1e-12


def within_size(verts, maximum):
    """Largest vertex-to-vertex span of an opening, in transformed mesh units."""
    if maximum is None:
        return True
    squared = (maximum + max(maximum * 1e-6, 1e-10)) ** 2
    return all((a.co - b.co).length_squared <= squared
               for i, a in enumerate(verts) for b in verts[i + 1:])


def weld_boundary_seams(bm, tolerance):
    verts = list({v for e in bm.edges if e.is_boundary for v in e.verts})
    if not verts:
        return
    local = {v: min((e.calc_length() for e in v.link_edges if e.calc_length() > 0), default=0)
             for v in verts}
    candidates = bmesh.ops.find_doubles(bm, verts=verts, dist=tolerance).get('targetmap', {})
    targets = {}
    for vertex, target in candidates.items():
        if any(e.other_vert(vertex) == target for e in vertex.link_edges):
            continue
        limit = min(tolerance, local[vertex]*.01, local[target]*.01)
        if (vertex.co-target.co).length <= limit:
            targets[vertex] = target
    if targets:
        bmesh.ops.weld_verts(bm, targetmap=targets)
        bm.normal_update()


def aperture_rim(rim, tolerance):
    """An opening has material outside its contour and walls receding inward."""
    verts, edges, normal = rim['verts'], rim['edges'], rim['normal']
    if not all(e.is_valid and e.is_manifold for e in edges):
        return False
    origin = verts[0].co
    drop = max(range(3), key=lambda k: abs(normal[k]))
    axes = [k for k in range(3) if k != drop]
    polygon = [(float(v.co[axes[0]]), float(v.co[axes[1]])) for v in verts]
    walls = set()
    for edge in edges:
        support = [f for f in edge.link_faces if f in rim['support']]
        if len(support) != 1:
            return False
        face = support[0]
        loop = next(l for l in edge.link_loops if l.face == face)
        tangent = loop.link_loop_next.vert.co-loop.vert.co
        inward = face.normal.cross(tangent).normalized()
        step = edge.calc_length()*1e-3
        sample = tuple((float(edge.verts[0].co[k])+float(edge.verts[1].co[k]))*.5 +
                       float(inward[k])*step for k in axes)
        if point_inside(sample, polygon):
            return False
        walls.update(f for f in edge.link_faces if f not in rim['support'])
    rim_verts = set(verts)
    depths = [(v.co-origin).dot(normal) for f in walls for v in f.verts if v not in rim_verts]
    if not depths:
        return False
    rim_depth = [(v.co-origin).dot(normal) for v in verts]
    span = max(max(v.co[k] for v in verts)-min(v.co[k] for v in verts) for k in range(3))
    return min(depths) < min(rim_depth)-min(tolerance, span*1e-4) and max(depths) <= max(rim_depth)+span*.02


def planar_recognition_coordinates(bm, tolerance):
    """Temporarily regularize an imported, nearly planar constant-thickness part.

    Return the original coordinates: they MUST be restored before writing the
    mesh. This is a recognition aid, never a flatten/remesh of the exterior.
    """
    points = [v.co for v in bm.verts]
    candidates = [Vector((1,0,0)), Vector((0,1,0)), Vector((0,0,1))]
    normal = max(bm.faces, key=lambda f:f.calc_area()).normal.copy()
    if normal.length_squared:
        candidates.append(normal.normalized())
    direction = min(candidates, key=lambda n:max(p.dot(n) for p in points)-min(p.dot(n) for p in points))
    depths = [p.dot(direction) for p in points]
    low, high = min(depths), max(depths)
    thickness = high-low
    if thickness <= tolerance*4:
        return {}
    u = direction.orthogonal().normalized(); v = direction.cross(u)
    spans = [max(p.dot(axis) for p in points)-min(p.dot(axis) for p in points) for axis in (u,v)]
    if thickness >= min(spans)*.02:
        return {}
    precision = min(thickness*.01, tolerance*64)
    if any(min(abs(d-low),abs(d-high)) > precision for d in depths):
        return {}
    originals = {vertex:vertex.co.copy() for vertex in bm.verts}
    for vertex, depth in zip(bm.verts, depths):
        target = low if depth < (low+high)*.5 else high
        vertex.co += direction*(target-depth)
    bm.normal_update()
    return originals


def smooth_shell_rims(bm, tolerance, layer, axis, triangulate=False, threshold=.2):
    choices=bm.faces.layers.int.get('fab_choice_id')
    values={}
    for v in bm.verts:values[v]=v.normal.dot(axis)
    if triangulate:
        provenance=bm.faces.layers.int.new('_field_original')
        for i,f in enumerate(bm.faces):f[provenance]=i+1
        bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method='BEAUTY',ngon_method='BEAUTY')
        for edge in list(bm.edges):
            if len(edge.link_faces)<=2:continue
            groups={}
            for face in edge.link_faces:groups.setdefault(face[provenance],[]).append(face)
            for group in groups.values():
                if len(group)!=2:continue
                a,b=edge.verts;mid=bm.verts.new((a.co+b.co)*.5);values[mid]=(values[a]+values[b])*.5
                originals=[]
                for face in group:
                    verts=list(face.verts);expanded=[]
                    for i,v in enumerate(verts):
                        expanded.append(v)
                        if v in (a,b)and verts[(i+1)%len(verts)]in(a,b):expanded.append(mid)
                    uv_data=[]
                    for uv_layer in bm.loops.layers.uv.values():
                        coordinates={loop.vert:loop[uv_layer].uv.copy()for loop in face.loops}
                        coordinates[mid]=(coordinates[a]+coordinates[b])*.5
                        uv_data.append((uv_layer,[coordinates[v]for v in expanded]))
                    originals.append((expanded,face.material_index,face.smooth,face[layer],face[provenance],uv_data,face[choices]if choices else 0))
                bmesh.ops.delete(bm,geom=group,context='FACES_ONLY')
                for vs,mat,smooth,comp,orig,uv_data,choice in originals:
                    f=bm.faces.new(vs);f.material_index=mat;f.smooth=smooth;f[layer]=comp;f[provenance]=orig
                    if choices:f[choices]=choice
                    for uv_layer,coordinates in uv_data:
                        for loop,uv in zip(f.loops,coordinates):loop[uv_layer].uv=uv
        loose=[e for e in bm.edges if not e.link_faces]
        if loose:bmesh.ops.delete(bm,geom=loose,context='EDGES')
    for level in (threshold,-threshold):
        for edge in list(bm.edges):
            a,b=edge.verts;va,vb=values[a],values[b]
            if (va-level)*(vb-level)<-1e-12:
                newedge,vertex=bmesh.utils.edge_split(edge,a,(level-va)/(vb-va));values[vertex]=level
        for face in list(bm.faces):
            cuts=[v for v in face.verts if values[v]==level]
            if len(cuts)==2 and not any(cuts[1]in e.verts for e in cuts[0].link_edges):
                material,smooth,component=face.material_index,face.smooth,face[layer]
                choice=face[choices]if choices else 0
                newface,loop=bmesh.utils.face_split(face,*cuts);newface.material_index=material;newface.smooth=smooth;newface[layer]=component
                if choices:newface[choices]=choice
    if choices:
        # New split edges otherwise keep index -1, making ordered contour
        # seeds depend on set iteration rather than the actual topology.
        bm.verts.index_update();bm.edges.index_update();bm.faces.index_update()
    bm.normal_update()
    from mathutils.bvhtree import BVHTree
    tree=BVHTree.FromBMesh(bm)
    low=min(v.co.dot(axis)for v in bm.verts);high=max(v.co.dot(axis)for v in bm.verts)
    def open_projection(polygon):
        xmin,xmax=min(p[0]for p in polygon),max(p[0]for p in polygon)
        ymin,ymax=min(p[1]for p in polygon),max(p[1]for p in polygon)
        samples=[(sum(p[0]for p in polygon)/len(polygon),sum(p[1]for p in polygon)/len(polygon))]
        samples.extend((xmin+(xmax-xmin)*(i+.5)/5,ymin+(ymax-ymin)*(j+.5)/5)for i in range(5)for j in range(5))
        return any(point_inside(p,polygon)and tree.ray_cast(u*p[0]+w*p[1]+axis*(low-.01),axis,high-low+.02)[0]is None for p in samples)
    u=axis.orthogonal().normalized();w=axis.cross(u)
    known=set();rims=[]
    for sign in (1,-1):
      normal=axis*sign;pending={f for f in bm.faces if sum(values[v]*sign for v in f.verts)/len(f.verts)>threshold+1e-6};seeds=iter(list(bm.faces))
      while pending:
        pulse()
        seed=next(f for f in seeds if f in pending);pending.remove(seed);patch={seed};queue=[seed]
        while queue:
            for edge in queue.pop().edges:
                for face in edge.link_faces:
                    if face in pending:pending.remove(face);patch.add(face);queue.append(face)
        loops=open_boundary_loops(bm,patch)
        if len(loops)<2:continue
        polygons=[[(v.co.dot(u),v.co.dot(w))for v in verts]for verts,edges in loops];areas=[polygon_area(p)for p in polygons]
        containers=containing_loops(polygons,areas)
        for i,(verts,edges)in enumerate(loops):
            key=frozenset(edges)
            if key in known or not all(e.is_manifold for e in edges)or filled_contour(verts,edges):continue
            containing=containers(i)
            if len(containing)!=1 or not open_projection(polygons[i]):continue
            known.add(key);rims.append({'verts':verts,'edges':edges,'support':patch,'normal':normal,'material':seed.material_index,'component':seed[layer]})
    return rims

def recover_smooth_shells(mesh, history=None, max_size=None):
    """Close densely perforated rounded shells independently of other parts.

    Commit only closed manifold, genus-zero replacements with unchanged bounds.
    Original vertices keep their coordinates; no object is replaced.
    """
    import bpy
    import numpy as np
    bm=bmesh.new();bm.from_mesh(mesh)
    if history is not None:history.prepare(bm)
    total=[0,0,0,0];changed=False
    try:
        layer,bounds=component_guard(bm)
        groups={}
        for face in bm.faces:groups.setdefault(face[layer],[]).append(face)
        for component,faces in groups.items():
            pulse()
            edges={e for f in faces for e in f.edges};verts={v for f in faces for v in f.verts}
            chi=len(verts)-len(edges)+len(faces)
            if chi>-62 or chi%2 or not all(len(e.link_faces)==2 for e in edges):continue
            xyz=np.asarray([tuple(v.co)for v in verts]);center=xyz.mean(axis=0)
            eig,axes=np.linalg.eigh((xyz-center).T@(xyz-center))
            if eig[1]<=0 or eig[0]/eig[1]>.65 or eig[1]/eig[2]<.65:continue
            axis=Vector(axes[:,0].tolist()).normalized()
            aligned=[f for f in faces if abs(f.normal.dot(axis))>.995]
            if aligned:axis=max(aligned,key=lambda f:f.calc_area()).normal.copy()
            major=max(range(3),key=lambda k:abs(axis[k]))
            if axis[major]<0:axis=-axis
            # CAD planar-patch normals can be noisy on bridged n-gons.
            # Stabilize nearly axial recognition without moving any vertex.
            if axis[major]>.99995:
                axis=Vector(tuple(1.0 if k==major else 0.0 for k in range(3)))
            reference=Vector((1,0,0))if abs(axis.x)<.9 else Vector((0,1,0))
            u=(reference-axis*reference.dot(axis)).normalized();w=u.cross(axis)
            depth=max(v.co.dot(axis)for v in verts)-min(v.co.dot(axis)for v in verts)
            span=min(max(v.co.dot(a)for v in verts)-min(v.co.dot(a)for v in verts)for a in(u,w))
            if span<=0 or not .05<depth/span<.75:continue
            part=bpy.data.meshes.new('_fab_curved_shell_work')
            sub=bm.copy()
            try:
                sub_layer=sub.faces.layers.int.get(layer.name)
                other=[f for f in sub.faces if f[sub_layer]!=component]
                bmesh.ops.delete(sub,geom=other,context='FACES')
                # Vertex-only connections to unrelated CAD islands must not
                # contaminate the smooth normals used by the detector.
                loose=[v for v in sub.verts if not v.link_faces]
                if loose:bmesh.ops.delete(sub,geom=loose,context='VERTS')
                sub.faces.layers.int.remove(sub_layer)
                sub.to_mesh(part)
                for material in mesh.materials:part.materials.append(material)
            finally:sub.free()
            counts=[0,0,0,0];success=False
            mark=len(history.records) if history is not None else 0
            committed=False
            try:
                directions=[axis,axis+u*.8+w*.6,axis-u*.8+w*.6,
                            axis+u*.8-w*.6,axis-u*.8-w*.6,
                            axis+u*1.5,axis-u*1.5,axis+w*1.5,axis-w*1.5]
                for i,direction in enumerate(directions):
                    pulse()
                    result=_close_pass(part,max_size=max_size,extended=True,repair=False,
                                       field_axis=direction.normalized(),field_triangulate=i==0,history=history)
                    counts=[a+b for a,b in zip(counts,result)]
                    audit=audit_mesh(part)
                    if not any(audit.values()):success=True;break
                    if len(part.polygons)>len(faces)*12:break
                expected_chi=2;partial=False
                if not success and (history is not None or max_size is not None) and any(counts):
                    audit=audit_mesh(part)
                    if not audit['remaining_openings']and not audit['uncertain_topology']and audit['remaining_passages']< (2-chi)//2:
                        expected_chi=2-2*audit['remaining_passages'];partial=True;success=True
                if not success:continue
                clean=bmesh.new();clean.from_mesh(part)
                try:
                    provenance=clean.faces.layers.int.get('_field_original')
                    choices=clean.faces.layers.int.get('fab_choice_id') if history is not None else None
                    protected={v for f in clean.faces if choices and f[choices] for v in f.verts}
                    internal=[e for e in clean.edges if len(e.link_faces)==2 and
                              (not choices or e.link_faces[0][choices]==e.link_faces[1][choices]) and
                              e.link_faces[0][provenance]!=0 and
                              e.link_faces[0][provenance]==e.link_faces[1][provenance]]
                    bmesh.ops.dissolve_edges(clean,edges=internal,use_verts=False,use_face_split=False)
                    bmesh.ops.dissolve_limit(clean,angle_limit=.001,verts=[v for v in clean.verts if v not in protected],edges=[e for e in clean.edges if not any(v in protected for v in e.verts)],
                                             use_dissolve_boundaries=False,delimit={'MATERIAL','UV'})
                    if not all(v.is_manifold for v in clean.verts)or not all(e.is_manifold for e in clean.edges):continue
                    if len(clean.verts)-len(clean.edges)+len(clean.faces)!=expected_chi:continue
                    eps=max(depth,span)*1e-6
                    if any(abs(min(v.co[k]for v in clean.verts)-bounds[component][k][0])>eps or
                           abs(max(v.co[k]for v in clean.verts)-bounds[component][k][1])>eps for k in range(3)):continue
                    clean.faces.layers.int.remove(provenance)
                    clean.to_mesh(part)
                finally:clean.free()
                # Delete only faces in this same mesh component, then append
                # its repaired geometry. Other objects never enter this BVH.
                bmesh.ops.delete(bm,geom=faces,context='FACES')
                bm.from_mesh(part);changed=True;committed=True
                if partial and history is not None:history.partial_components+=1
                total=[a+b for a,b in zip(total,counts)]
            finally:
                if history is not None and not committed:del history.records[mark:]
                bpy.data.meshes.remove(part)
        if changed:
            layer=bm.faces.layers.int.get('fab_hole_guard')
            if layer:bm.faces.layers.int.remove(layer)
            bm.to_mesh(mesh);mesh.update()
        return tuple(total)
    finally:bm.free()


def _close_pass(mesh, max_size=None, diagnostics=None, extended=False, repair=True, field_axis=None, field_triangulate=False, history=None, field_threshold=.2, planar_only=False):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    if history is not None:history.prepare(bm)
    try:
        if not bm.faces:
            return 0, 0, 0, 0
        # CAD imports can contain reversed connected shells. Consistent face
        # winding is required to distinguish recesses from external bosses.
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        bm.normal_update()
        diagonal = math.sqrt(sum((max(v.co[k] for v in bm.verts) - min(v.co[k] for v in bm.verts)) ** 2 for k in range(3)))
        tolerance = max(diagonal * 1e-6, 1e-9)
        if repair:
            weld_boundary_seams(bm, tolerance*.1)
            multi = [e for e in bm.edges if len(e.link_faces) > 2]
            if multi:
                bmesh.ops.split_edges(bm, edges=multi)
                bm.normal_update()
        bm.verts.index_update(); bm.edges.index_update(); bm.faces.index_update()
        guard_layer, guard_bounds = component_guard(bm)
        orient_small_components(bm, guard_layer)
        recognition_originals = planar_recognition_coordinates(bm, tolerance) if extended else {}
        if field_axis is not None:
            rims = smooth_shell_rims(bm, tolerance, guard_layer, field_axis, field_triangulate)
        else:
            rims = planar_rims(bm, tolerance, guard_layer, extended)
            if not planar_only:rims += curved_rims(bm, tolerance, guard_layer, rims, extended)
            if extended and not planar_only:
                rims += silhouette_rims(bm, tolerance, guard_layer, rims)
        if history is not None:history.refresh(bm)
        rims = exterior_rims(rims, tolerance, BVHTree.FromBMesh(bm))
        barriers = {e for rim in rims for e in rim['edges']}
        visited = set()
        regions = []
        rejected = 0
        for rim in rims:
            pulse()
            seeds = {f for e in rim['edges'] for f in e.link_faces if f not in rim['support']}
            if not seeds or seeds & visited:
                continue
            region = set(seeds)
            queue = list(seeds)
            while queue:
                face = queue.pop()
                for e in face.edges:
                    if e in barriers:
                        continue
                    for other in e.link_faces:
                        if other not in region:
                            region.add(other)
                            queue.append(other)
            visited.update(region)
            boundary = {e for f in region for e in f.edges if sum(n in region for n in e.link_faces) == 1}
            matching = [r for r in rims if all(e in boundary for e in r['edges'])]
            expected = {e for r in matching for e in r['edges']}
            if not matching or boundary != expected:
                rejected += 1
                continue
            region_verts = {v for face in region for v in face.verts}
            if any(region_verts.issubset(set(r['verts'])) for r in matching):
                # A disk made exclusively from one mouth's vertices is
                # already a cap, even if its nonplanar fan has signed volume.
                rejected += 1
                continue
            if cavity_volume(region, matching) >= -cavity_volume_tolerance(region, matching):
                rejected += 1
                continue
            regions.append((region, matching))

        # Interior shoulders can split one communicating cavity into several
        # negative-volume regions. Shared rims are internal interfaces, not
        # additional external mouths: merge before creating caps.
        parents = list(range(len(regions)))

        def find(i):
            while parents[i] != i:
                parents[i] = parents[parents[i]]
                i = parents[i]
            return i

        owners = {}
        for i, (_, matching) in enumerate(regions):
            for edge in {e for rim in matching for e in rim['edges']}:
                if edge in owners:
                    parents[find(i)] = find(owners[edge])
                else:
                    owners[edge] = i
        groups = {}
        for i, (region, _) in enumerate(regions):
            groups.setdefault(find(i), set()).update(region)
        regions = []
        for region in groups.values():
            boundary = {e for face in region for e in face.edges if sum(f in region for f in e.link_faces) == 1}
            matching = [rim for rim in rims if all(e in boundary for e in rim['edges'])]
            expected = {e for rim in matching for e in rim['edges']}
            if not matching or boundary != expected:
                rejected += 1
                continue
            regions.append((region, matching))

        cad_count = 0
        cap_count = 0
        removed_faces = 0
        for region, matching in regions:
            pulse()
            if not all(f.is_valid for f in region):
                continue
            # Check the final external mouths together, never internal shoulders.
            # A large mouth preserves the entire communicating cavity.
            if any(not within_size(rim['verts'], max_size) for rim in matching):
                if diagnostics is not None:
                    diagnostics['over_limit'] += 1
                continue
            if not preserves_component_bounds(bm, region, matching, guard_layer, guard_bounds, tolerance):
                rejected += 1
                continue
            already_capped = any(any(face not in region and len(face.verts) == len(rim['verts']) and
                                     set(face.verts) == set(rim['verts']) for face in rim['edges'][0].link_faces)
                                 for rim in matching)
            if already_capped:
                rejected += 1
                continue
            old_edges = {e for f in region for e in f.edges}
            old_verts = {v for f in region for v in f.verts}
            cap_data = []
            for rim in matching:
                adjacent = next(face for e in rim['edges'] for face in e.link_faces if face not in region)
                cap_data.append((rim, adjacent.material_index, adjacent[guard_layer]))
            original_faces = [(list(f.verts), f.material_index, f[guard_layer], f.smooth,
                               [(layer,[tuple(loop[layer].uv) for loop in f.loops])
                                for layer in bm.loops.layers.uv.values()]) for f in region]
            choice_layer=bm.faces.layers.int.get('fab_choice_id')if history is not None else None
            original_choices=[f[choice_layer]for f in region]if choice_layer else None
            bmesh.ops.delete(bm, geom=list(region), context='FACES_ONLY')
            created = []
            failed = False
            for rim, material, component_id in cap_data:
                faces = fill_loop(bm, rim['edges'])
                if not faces:
                    failed = True
                    break
                created.extend(faces)
                for f in faces:
                    f.material_index = material
                    f[guard_layer] = component_id
                if any(not e.is_manifold for e in rim['edges']):
                    failed = True
                    break
                cap_count += 1
            if failed:
                if created:
                    bmesh.ops.delete(bm, geom=created, context='FACES_ONLY')
                for face_index,(verts, material, component_id, smooth, uv_data) in enumerate(original_faces):
                    restored = bm.faces.new(verts)
                    restored.material_index = material; restored[guard_layer] = component_id; restored.smooth = smooth
                    if choice_layer:restored[choice_layer]=original_choices[face_index]
                    for layer, coordinates in uv_data:
                        for loop, uv in zip(restored.loops, coordinates):
                            loop[layer].uv = uv
                rejected += 1
                continue
            if history is not None:
                data=[(vs,material,smooth,uv)for vs,material,component,smooth,uv in original_faces]
                identity=history.capture(data,created,recognition_originals,original_choices)
                history.tag(bm,created,identity)
            removed_faces += len(region)
            wires = [e for e in old_edges if e.is_valid and not e.link_faces]
            if wires:
                bmesh.ops.delete(bm, geom=wires, context='EDGES')
            loose = [v for v in old_verts if v.is_valid and not v.link_edges]
            if loose:
                bmesh.ops.delete(bm, geom=loose, context='VERTS')
            cad_count += 1

        # Fill genuine mesh openings as well, including complete missing faces.
        open_count = 0
        for verts, edges in ([] if planar_only else open_boundary_loops(bm)):
            pulse()
            if not within_size(verts, max_size):
                if diagnostics is not None:
                    diagnostics['over_limit'] += 1
                continue
            material = edges[0].link_faces[0].material_index
            component_id = edges[0].link_faces[0][guard_layer]
            faces = fill_loop(bm, edges)
            if faces:
                for f in faces:
                    f.material_index = material
                    f[guard_layer] = component_id
                if history is not None:
                    identity=history.capture([],faces,recognition_originals)
                    history.tag(bm,faces,identity)
                open_count += 1
            else:
                rejected += 1
        if cad_count or open_count or removed_faces:
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            orient_small_components(bm, guard_layer)
        for vertex, coordinate in recognition_originals.items():
            if vertex.is_valid:
                vertex.co = coordinate
        if recognition_originals:
            bm.normal_update()
        check_components(bm, guard_layer, guard_bounds, tolerance)
        if cad_count or open_count or removed_faces:
            bm.to_mesh(mesh)
            mesh.update()
        return cad_count, open_count, rejected, removed_faces
    finally:
        bm.free()


def close_mesh(mesh, max_size=None, diagnostics=None, history=None, progress=None):
    global _progress
    previous=_progress;_progress=progress
    try:
        pulse()
        return _close_mesh_impl(mesh,max_size,diagnostics,history)
    finally:_progress=previous


def _close_mesh_impl(mesh, max_size=None, diagnostics=None, history=None):
    if max_size is not None and (not math.isfinite(max_size) or max_size <= 0):
        raise ValueError('La dimensione massima deve essere positiva e finita')
    # Sealing one connected cavity can expose the classification of another
    # contour. Repeat until stable instead of making the user run the button
    # multiple times. The guard is for convergence, not hole diameter.
    # Prefer the actual planar mouth over normal-field cuts through a wall.
    # A folded perforated sheet can meet the curved-shell heuristic globally
    # while each bore still has exact planar support at both exterior mouths.
    if diagnostics is not None:diagnostics['over_limit']=0
    cad, opened, _, removed = _close_pass(mesh,max_size,diagnostics,history=history,planar_only=True)
    c,o,_,r = recover_smooth_shells(mesh,history=history,max_size=max_size)
    cad+=c;opened+=o;removed+=r
    extended = False
    prepared = False
    for iteration in range(64):
        pulse()
        if diagnostics is not None:
            diagnostics['over_limit'] = 0
        c, o, rejected, r = _close_pass(mesh, max_size, diagnostics, extended, not prepared,history=history)
        cad += c
        opened += o
        removed += r
        prepared |= bool(c or o or r)
        if not (c or o or r):
            if not extended and needs_extended(mesh, rejected):
                extended = True
                continue
            if diagnostics is not None:
                diagnostics.update(audit_mesh(mesh))
            return cad, opened, rejected, removed
    raise RuntimeError('La chiusura non converge; oggetto originale conservato. Invia il pezzo per la verifica.')


def audit_mesh(mesh):
    """Report residual passages separately from a successful command execution.

    Euler's test is used only on closed manifold surface components. A CAD
    singularity cannot be interpreted as a trustworthy count of holes.
    """
    bm = bmesh.new(); bm.from_mesh(mesh)
    try:
        loops = open_boundary_loops(bm)
        covered = {e for verts,edges in loops for e in edges}
        openings = sum(not filled_contour(verts,edges) for verts,edges in loops)
        ambiguous = int(any(e.is_boundary and e not in covered for e in bm.edges) or
                        any(len(e.link_faces)>2 for e in bm.edges))
        remaining = set(bm.faces); handles = 0
        while remaining:
            seed = remaining.pop(); faces = {seed}; queue = [seed]
            while queue:
                for edge in queue.pop().edges:
                    for other in edge.link_faces:
                        if other in remaining:
                            remaining.remove(other); faces.add(other); queue.append(other)
            edges = {e for face in faces for e in face.edges}
            if not all(e.is_manifold for e in edges):
                continue
            verts = {v for face in faces for v in face.verts}
            chi = len(verts)-len(edges)+len(faces)
            if not all(v.is_manifold for v in verts) or chi>2 or chi%2:
                ambiguous += 1
            elif chi<2:
                handles += (2-chi)//2
        return {'remaining_openings':openings, 'remaining_passages':handles,
                'uncertain_topology':ambiguous}
    finally:
        bm.free()


def needs_extended(mesh, rejected):
    if rejected:
        return True
    bm = bmesh.new(); bm.from_mesh(mesh)
    try:
        if any(not e.is_manifold for e in bm.edges):
            return True
        # A blind pocket has no boundary edges and need not add a handle.
        # Concave face junctions still require the CAD recovery pass.
        if any(e.is_manifold and e.calc_face_angle_signed(0.0) < -1e-5 for e in bm.edges):
            return True
        remaining = set(bm.faces)
        while remaining:
            face = remaining.pop(); faces = {face}; queue = [face]
            while queue:
                for e in queue.pop().edges:
                    for other in e.link_faces:
                        if other in remaining:
                            remaining.remove(other); faces.add(other); queue.append(other)
            edges = {e for f in faces for e in f.edges}; verts = {v for f in faces for v in f.verts}
            if len(verts)-len(edges)+len(faces) < 2:
                return True
        return False
    finally:
        bm.free()
