"""Viewport picker for recorded closures. No helper objects for markers."""
import bpy
from bpy.props import IntProperty, StringProperty, BoolProperty
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import tessellate_polygon
from . import hole_choices as choices

_active=None


def closure_geometry(payload,mesh=None):
    vertices=[];triangles=[];identities=[];outlines=[]
    if mesh is not None:
        # Use Blender's actual tessellation, also for warped CAD n-gons.
        # Re-tessellating each cap separately can produce a different surface
        # and make the picker think its own closure is an occluder.
        mesh.calc_loop_triangles()
        layer=mesh.attributes.get(choices.LAYER)
        if layer:
            valid={r['id']for r in payload['records']}
            vertices=[v.co.copy()for v in mesh.vertices]
            for triangle in mesh.loop_triangles:
                identity=layer.data[triangle.polygon_index].value
                if identity in valid:
                    triangles.append(tuple(triangle.vertices));identities.append(identity)
            # Draw the external rim, not every internal tessellation edge.
            edges={}
            for face in mesh.polygons:
                identity=layer.data[face.index].value
                if identity not in valid:continue
                for a,b in zip(face.vertices,(*face.vertices[1:],face.vertices[0])):
                    key=(identity,min(a,b),max(a,b));edges[key]=edges.get(key,0)+1
            for (identity,a,b),count in edges.items():
                if count==1:outlines.append((identity,[vertices[a],vertices[b]]))
            if triangles:return BVHTree.FromPolygons(vertices,triangles,all_triangles=True),identities,outlines
    for record in payload['records']:
        for cap in record['caps']:
            points=[Vector(record['vertices'][i])for i in cap]
            mapping={tuple(v):i for i,v in enumerate(points)}
            for tri in tessellate_polygon([points]):
                # Recent Blender versions return indices; older versions
                # return vectors. Keep both forms of the API supported.
                local=tri if isinstance(tri[0],int)else tuple(mapping[tuple(v)]for v in tri)
                triangles.append(tuple(len(vertices)+i for i in local));identities.append(record['id'])
            outlines.append((record['id'],points));vertices.extend(points)
    if not triangles:return None
    return BVHTree.FromPolygons(vertices,triangles,all_triangles=True),identities,outlines


def state_visible(opened,mode):
    return mode=='ALL'or(mode=='OPEN'and opened)or(mode=='CLOSED'and not opened)


def filter_changed(scene,context):
    if _active:
        _active.hover=None;_active._cycle_targets=[];_active._cycle_anchor=None
        _active.update_header()
    if context:
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type=='VIEW_3D':area.tag_redraw()


def ray_candidates(items,origin,direction,occluder=float('inf'),through=False,mode='ALL'):
    """Order recorded cavities along the ray, deduplicating their two mouths.

    Only explicit depth cycling requests all intersections. Plain hover keeps
    the nearest-hit path and respects ordinary scene occlusion.
    """
    hits=[]
    for obj,tree,ids,outlines in items:
        if not obj.visible_get()or not getattr(obj,'fab_holes_group_visible',True):continue
        inverse=obj.matrix_world.inverted();start=inverse@origin
        ray=(inverse.to_3x3()@direction).normalized();seen=set();opened=set(obj.get(choices.OPEN,[]))
        for _ in range(len(ids)+1 if through or mode!='ALL'else 1):
            loc,normal,index,depth=tree.ray_cast(start,ray)
            if loc is None:break
            distance=(obj.matrix_world@loc-origin).length
            identity=ids[index]
            if identity not in seen and state_visible(identity in opened,mode)and (through or occluder>=distance-max(1e-5,distance*1e-5)):
                hits.append((distance,obj.name_full,identity,obj));seen.add(identity)
            if not through and hits and hits[-1][3]==obj:break
            # Float32-aware step, local to this object's coordinates. This is
            # only a ray cursor: no mesh vertex or transform is modified.
            epsilon=max(1e-8,max(abs(v)for v in loc)*2e-7)
            advanced=loc+ray*epsilon
            if (advanced-start).dot(ray)<=0:break
            start=advanced
    hits.sort(key=lambda h:(h[0],h[1],h[2]))
    return [(obj,identity)for distance,name,identity,obj in hits]


def cycle_target(targets,current,step):
    if not targets:return None
    if current not in targets:return targets[0 if step>0 else -1]
    return targets[(targets.index(current)+step)%len(targets)]


def cycle_anchor(event,view):
    return event.mouse_x,event.mouse_y,tuple(v for row in view.view_matrix for v in row)


def same_anchor(anchor,event,view):
    return bool(anchor and abs(anchor[0]-event.mouse_x)<=4 and abs(anchor[1]-event.mouse_y)<=4
                and anchor[2]==tuple(v for row in view.view_matrix for v in row))


class FABHOLES_OT_page(bpy.types.Operator):
    bl_idname='fab_holes.choice_page'
    bl_label='Pagina chiusure'
    page:IntProperty(min=1)

    def execute(self,context):
        context.scene.fab_holes_choice_page=self.page
        return {'FINISHED'}


class FABHOLES_OT_toggle(bpy.types.Operator):
    bl_idname='fab_holes.toggle_one'
    bl_label='Apri / chiudi foro'
    bl_options={'REGISTER','UNDO'}
    object_name:StringProperty()
    hole_id:IntProperty(min=1)

    def execute(self,context):
        obj=bpy.data.objects.get(self.object_name)
        if obj is None:return {'CANCELLED'}
        try:choices.toggle(obj,self.hole_id)
        except Exception as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}
        context.view_layer.update()
        if context.area:context.area.tag_redraw()
        return {'FINISHED'}


class FABHOLES_OT_all(bpy.types.Operator):
    bl_idname='fab_holes.set_all'
    bl_label='Apri / richiudi tutti'
    bl_description='Imposta tutte le chiusure registrate delle mesh selezionate, con una sola ricostruzione per mesh'
    bl_options={'REGISTER','UNDO'}
    open_all:BoolProperty(default=True)

    @classmethod
    def poll(cls,context):
        return context.mode=='OBJECT'and any(o.type=='MESH'and o.data.get(choices.HISTORY)for o in context.selected_objects)

    def execute(self,context):
        changed=failed=0
        for obj in list(context.selected_objects):
            if obj.type!='MESH'or not obj.data.get(choices.HISTORY):continue
            try:
                if not obj.is_editable:raise ValueError('Oggetto non modificabile')
                payload=choices.read(obj.data)
                wanted={r['id']for r in payload['records']}if self.open_all else set()
                changed+=bool(choices.set_opened(obj,wanted,payload))
            except Exception as exc:
                failed+=1;self.report({'WARNING'},f'{obj.name}: {exc}')
        context.view_layer.update()
        for area in context.screen.areas if context.screen else ():
            if area.type=='VIEW_3D':area.tag_redraw()
        self.report({'INFO'},f'Mesh aggiornate: {changed}.'+(f' Errori: {failed}.'if failed else''))
        return {'FINISHED'}if changed or not failed else{'CANCELLED'}


class FABHOLES_OT_editor(bpy.types.Operator):
    bl_idname='fab_holes.edit_choices'
    bl_label='Scegli fori aperti'
    bl_description='Clic apre/richiude. Maiusc + rotellina o frecce su/giù scorre i fori sovrapposti. Esc termina'
    _handle=None

    def invoke(self,context,event):
        global _active
        if _active is not None:
            _active.finish(context);return {'CANCELLED'}
        if context.area is None or context.area.type!='VIEW_3D' or context.mode!='OBJECT':
            self.report({'WARNING'},'Usa la vista 3D in modalità Oggetto.');return {'CANCELLED'}
        self.items=[];self.hover=None;self._cycle_targets=[];self._cycle_anchor=None
        self._area=context.area
        self._region=next(r for r in context.area.regions if r.type=='WINDOW')
        self._view=context.space_data.region_3d
        for obj in context.selected_objects:
            if obj.type!='MESH'or not obj.visible_get():continue
            payload=choices.read(obj.data)
            if not payload:continue
            try:base=choices.validate(obj,payload)
            except ValueError:
                self.report({'WARNING'},f'{obj.name}: mesh modificata dopo la chiusura.');continue
            geometry=closure_geometry(payload,base)
            if geometry:self.items.append((obj,*geometry))
        if not self.items:
            self.report({'WARNING'},'Nessuna chiusura modificabile: attiva Fori modificabili e richiudi dal modello originale.');return {'CANCELLED'}
        import gpu
        self.shader=gpu.shader.from_builtin('UNIFORM_COLOR')
        self._handle=bpy.types.SpaceView3D.draw_handler_add(self.draw_overlay,(), 'WINDOW','POST_VIEW')
        _active=self
        context.window_manager.modal_handler_add(self)
        self.update_header()
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def draw_overlay(self):
        import gpu
        from gpu_extras.batch import batch_for_shader
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('NONE'if bpy.context.scene.fab_holes_xray else'LESS_EQUAL');gpu.state.line_width_set(2)
        try:
            buckets={}
            for obj,tree,ids,outlines in self.items:
                if not obj.visible_get()or not getattr(obj,'fab_holes_group_visible',True):continue
                opened=set(obj.get(choices.OPEN,[]));matrix=obj.matrix_world
                for identity,points in outlines:
                    if not state_visible(identity in opened,bpy.context.scene.fab_holes_display_state):continue
                    color=(.15,.9,.45,.95)if identity in opened else(1,.16,.22,.95)
                    if self.hover==(obj,identity):color=(1,1,.15,1)
                    coords=[matrix@p for p in points];lines=buckets.setdefault((color,self.hover==(obj,identity)),[])
                    for i,p in enumerate(coords):lines.extend((p,coords[(i+1)%len(coords)]))
            for (color,hovered),vertices in sorted(buckets.items(),key=lambda pair:pair[0][1]):
                gpu.state.depth_test_set('NONE'if hovered or bpy.context.scene.fab_holes_xray else'LESS_EQUAL')
                gpu.state.line_width_set(3 if hovered else 2)
                batch=batch_for_shader(self.shader,'LINES',{'pos':vertices})
                self.shader.bind();self.shader.uniform_float('color',color);batch.draw(self.shader)
        except ReferenceError:pass
        finally:
            gpu.state.depth_test_set('NONE');gpu.state.blend_set('NONE');gpu.state.line_width_set(1)

    def pick(self,context,event,through=False):
        from bpy_extras.view3d_utils import region_2d_to_origin_3d,region_2d_to_vector_3d
        region=self._region;view=self._view
        for other in self._area.regions:
            if other.type in {'UI','TOOLS','HEADER','TOOL_HEADER'}and other.x<=event.mouse_x<other.x+other.width and other.y<=event.mouse_y<other.y+other.height:return [] if through else None
        pos=(event.mouse_x-region.x,event.mouse_y-region.y)
        if not(0<=pos[0]<region.width and 0<=pos[1]<region.height):return [] if through else None
        origin=region_2d_to_origin_3d(region,view,pos);direction=region_2d_to_vector_3d(region,view,pos)
        occluder=float('inf')
        depsgraph=context.evaluated_depsgraph_get();start_world=origin.copy()
        for _ in range(0 if through or context.scene.fab_holes_xray else 16):
            hit,point,n,face,owner,matrix=context.scene.ray_cast(depsgraph,start_world,direction)
            if not hit:break
            if owner.visible_get():occluder=(point-origin).length;break
            start_world=point+direction*1e-5
        targets=ray_candidates(self.items,origin,direction,occluder,through,context.scene.fab_holes_display_state)
        return targets if through else(targets[0]if targets else None)

    def update_header(self):
        text='Fabularis • Clic: apri/chiudi • Maiusc + rotellina o ↑/↓: foro dietro • Esc termina'
        if self.hover and self.hover in self._cycle_targets:
            index=self._cycle_targets.index(self.hover)+1
            text+=f' • {index}/{len(self._cycle_targets)} · {self.hover[0].name} · Foro {self.hover[1]}'
        self._area.header_text_set(text)

    def cycle(self,context,event,step):
        if not same_anchor(self._cycle_anchor,event,self._view):
            self._cycle_targets=self.pick(context,event,through=True)
            self._cycle_anchor=cycle_anchor(event,self._view)
        self.hover=cycle_target(self._cycle_targets,self.hover,step)
        self.update_header();context.area.tag_redraw()
        return bool(self._cycle_targets)

    def modal(self,context,event):
        if self._handle is None:return {'FINISHED'}
        if event.type in {'ESC','RIGHTMOUSE'}and event.value=='PRESS':
            self.finish(context);return {'FINISHED'}
        if event.type=='TAB' or (event.type=='Z'and event.ctrl):
            self.finish(context);return {'PASS_THROUGH'}
        if event.shift and event.type in {'WHEELUPMOUSE','WHEELDOWNMOUSE','UP_ARROW','DOWN_ARROW'}and event.value=='PRESS':
            try:
                step=1 if event.type in {'WHEELUPMOUSE','UP_ARROW'}else -1
                if self.cycle(context,event,step):return {'RUNNING_MODAL'}
            except (ReferenceError,ValueError):self.finish(context);return {'CANCELLED'}
        if event.type=='MOUSEMOVE':
            try:
                if not same_anchor(self._cycle_anchor,event,self._view):
                    self._cycle_targets=[];self._cycle_anchor=None
                    self.hover=self.pick(context,event);self.update_header()
            except (ReferenceError,ValueError):self.finish(context);return {'CANCELLED'}
            context.area.tag_redraw();return {'PASS_THROUGH'}
        if event.type=='LEFTMOUSE'and event.value=='PRESS':
            target=self.hover if same_anchor(self._cycle_anchor,event,self._view)else self.pick(context,event)
            if target:
                mode=getattr(getattr(context,'scene',None),'fab_holes_display_state','ALL')
                if not state_visible(target[1]in target[0].get(choices.OPEN,[]),mode):return {'RUNNING_MODAL'}
                bpy.ops.fab_holes.toggle_one(object_name=target[0].name,hole_id=target[1]);context.area.tag_redraw()
                if mode!='ALL':
                    self.hover=None;self._cycle_targets=[];self._cycle_anchor=None;self.update_header()
                return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}

    def finish(self,context=None):
        global _active
        if self._handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle,'WINDOW');self._handle=None
        _active=None
        area=getattr(self,'_area',None)
        if area:
            try:area.header_text_set(None);area.tag_redraw()
            except ReferenceError:pass

    def cancel(self,context):self.finish(context)


CLASSES=(FABHOLES_OT_page,FABHOLES_OT_toggle,FABHOLES_OT_all,FABHOLES_OT_editor)

def stop():
    if _active:_active.finish(bpy.context)


@bpy.app.handlers.persistent
def _load_pre(_):
    stop()


def install():
    if _load_pre not in bpy.app.handlers.load_pre:bpy.app.handlers.load_pre.append(_load_pre)


def uninstall():
    stop()
    if _load_pre in bpy.app.handlers.load_pre:bpy.app.handlers.load_pre.remove(_load_pre)
