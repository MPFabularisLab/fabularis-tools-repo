bl_info = {'name': 'Fabularis — Chiudi fori', 'author': 'Fabularis Lab', 'version': (0, 3, 18), 'blender': (5, 1, 0), 'category': 'Mesh'}

import textwrap
import traceback
import bpy
from bpy.props import StringProperty, EnumProperty, FloatProperty, BoolProperty, IntProperty
from .geometry import close_mesh
from . import hole_choices, hole_editor, measurements
from .timing import CalculationTimer,format_elapsed
from . import icons,selection_ui

REPORT = 'Fabularis_Chiudi_Fori_Report'


def notice(operator, context, message, error=False):
    context.scene.fab_holes_message = message
    operator.report({'WARNING'} if error else {'INFO'}, message)
    def draw(menu, ctx):
        for line in textwrap.wrap(message, width=80):
            menu.layout.label(text=line)
        menu.layout.operator('fab_holes.copy_report', text='Copia dettagli')
    if error and context.window and not bpy.app.background:
        context.window_manager.popup_menu(draw, title='Fabularis — Chiudi fori', icon='ERROR' if error else 'INFO')


class FABHOLES_OT_close(bpy.types.Operator):
    bl_idname = 'fab_holes.close'
    bl_label = 'Chiudi fori'
    bl_description = 'Modifica direttamente le mesh selezionate, mantenendo oggetti, gerarchia, Collection e trasformazioni. Annulla con Ctrl+Z'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            notice(self, context, 'Passa alla modalità Oggetto, poi seleziona le mesh da elaborare.', True)
            return {'CANCELLED'}
        sources = [o for o in context.selected_objects if o.type == 'MESH']
        if not sources:
            notice(self, context, 'Nessuna mesh selezionata. Seleziona uno o più oggetti mesh prima di avviare la chiusura.', True)
            return {'CANCELLED'}
        hole_editor.stop()
        cached_empty=measurements.cached_empty_sources(context)
        context.scene.fab_holes_preview=False
        timer=CalculationTimer(context)
        if len(cached_empty)==len(sources):
            timer.finish()
            report=bpy.data.texts.get(REPORT)or bpy.data.texts.new(REPORT);report.clear()
            report.write('Analisi valida riutilizzata: nessun foro riconosciuto entro il limite. Nessuna scansione o copia di mesh.\n'+context.scene.fab_holes_time)
            notice(self,context,'0 fori riconosciuti entro il limite. Analisi riutilizzata; mesh invariate.')
            return {'FINISHED'}
        limited = context.scene.fab_holes_size_mode == 'LIMITED'
        maximum_mm = context.scene.fab_holes_max_size_mm
        max_size = maximum_mm / (1000 * context.scene.unit_settings.scale_length) if limited else None
        scope = f'Fino a {maximum_mm:g} mm' if limited else 'Tutti i fori (senza limite di dimensione)'
        logs, pending = [scope], []
        modified_objects = []
        previous_active = context.view_layer.objects.active
        over_limit = 0
        review = 0
        total = failed = skipped = rejected = modified = internal = unchanged = 0
        dg = context.evaluated_depsgraph_get()
        wm = context.window_manager
        wm.progress_begin(0, len(sources))
        try:
            # Evaluate every input before changing any source. Dependencies such
            # as Boolean target objects see the original assembly throughout.
            for index, src in enumerate(sources):
                timer.set_stage(f'{index+1}/{len(sources)}: {src.name}')
                object_started=timer.clock()
                mesh = None
                try:
                    if src in cached_empty:
                        unchanged+=1;over_limit+=cached_empty[src]
                        logs.append(f'{src.name}: 0 fori riconosciuti entro il limite; analisi valida riutilizzata, nessuna scansione')
                        continue
                    if not src.is_editable:
                        skipped += 1
                        logs.append(f'{src.name}: ignorato, oggetto collegato non modificabile')
                        continue
                    if src.data.shape_keys or src.animation_data or any(m.type == 'ARMATURE' for m in src.modifiers):
                        skipped += 1
                        logs.append(f'{src.name}: ignorato, oggetto animato / armatura / shape key')
                        continue
                    mesh = bpy.data.meshes.new_from_object(src.evaluated_get(dg), preserve_all_data_layers=True, depsgraph=dg)
                    previous_choices=None
                    if context.scene.fab_holes_editable and not src.modifiers:
                        previous_choices=hole_choices.read(src.data)
                        if previous_choices:
                            try:hole_choices.validate(src,previous_choices)
                            except ValueError:previous_choices=None
                    if hole_choices.HISTORY in mesh:del mesh[hole_choices.HISTORY]
                    for name in (hole_choices.LAYER,hole_choices.VERT):
                        attribute=mesh.attributes.get(name)
                        if attribute and not previous_choices:mesh.attributes.remove(attribute)
                    matrix = src.matrix_world.copy()
                    if abs(matrix.determinant()) < 1e-15:
                        raise ValueError('Scala nulla: impossibile elaborare questo oggetto')
                    # Rotation/scale affect the geometry; scene translation
                    # does not. Excluding it avoids CAD precision loss far
                    # from the origin without moving the actual object.
                    geometry_matrix = matrix.copy()
                    geometry_matrix.translation = (0, 0, 0)
                    mesh.transform(geometry_matrix)
                    diagnostics = {}
                    recorder = hole_choices.Recorder() if context.scene.fab_holes_editable else None
                    if recorder is not None and previous_choices:
                        recorder.resume(previous_choices,mesh,geometry_matrix,src.get(hole_choices.OPEN,[]))
                    timer.update()
                    cad, opened, ambiguous, removed_faces = close_mesh(mesh, max_size, diagnostics,history=recorder,progress=timer.update)
                    excluded = diagnostics['over_limit']
                    over_limit += excluded
                    logs.append(f'{src.name}: cavità/aperture oltre il limite {excluded}')
                    openings = diagnostics.get('remaining_openings', 0)
                    passages = diagnostics.get('remaining_passages', 0)
                    uncertain = diagnostics.get('uncertain_topology', 0)
                    if openings or passages or uncertain:
                        logs.append(f'DA VERIFICARE {src.name}: aperture residue {openings}; passaggi topologici residui {passages}; topologia ambigua {uncertain}. Il conteggio non certifica tutte le possibili cavità geometriche.')
                        if not limited:
                            review += 1
                    rejected += ambiguous
                    if not (cad or opened or removed_faces):
                        unchanged += 1
                        logs.append(f'{src.name}: invariato, nessun foro chiudibile con le impostazioni attuali; candidati esclusi {ambiguous}')
                        continue
                    mesh.transform(geometry_matrix.inverted())
                    if matrix.determinant() < 0:
                        mesh.flip_normals()
                    mesh.update()
                    for i, slot in enumerate(src.material_slots):
                        if i < len(mesh.materials):
                            mesh.materials[i] = slot.material
                    if recorder is not None and recorder.partial_components:
                        logs.append(f'{src.name}: {recorder.partial_components} componente/i chiusa/e parzialmente; i passaggi residui restano segnalati. Con Dimensione massima possono includere le cavità oltre soglia.')
                    if recorder is not None and recorder.records:
                        timer.set_stage('Registrazione: '+src.name);timer.update()
                        recorder.store(mesh,geometry_matrix.inverted())
                    pending.append((src, mesh, cad, opened, removed_faces, ambiguous))
                    mesh = None  # Owned by the pending transaction until commit.
                except Exception as exc:
                    failed += 1
                    logs.append(f'ERRORE {src.name}: {type(exc).__name__}: {exc}\n{traceback.format_exc()}')
                finally:
                    logs.append(f'{src.name}: tempo elaborazione {timer.clock()-object_started:.2f} s')
                    if mesh and mesh.users == 0:
                        bpy.data.meshes.remove(mesh)
                    wm.progress_update(index + 1)

            for src, mesh, cad, opened, removed_faces, ambiguous in pending:
                timer.set_stage('Applicazione: '+src.name)
                timer.update()
                original_mesh = src.data
                try:
                    # Keep the exact same Object ID, parent, parent inverse,
                    # constraints, transform and Collection membership. Only
                    # the evaluated geometry becomes the object's new mesh.
                    src.data = mesh
                    src.modifiers.clear()  # Their visible result is already baked.
                    hole_choices.cleanup(src)
                except Exception as exc:
                    if src.data == mesh:
                        src.data = original_mesh
                    if mesh.users == 0:
                        bpy.data.meshes.remove(mesh)
                    failed += 1
                    logs.append(f'ERRORE APPLICAZIONE {src.name}: {exc}\n{traceback.format_exc()}')
                    continue
                modified_objects.append(src)
                modified += 1
                internal += removed_faces
                total += cad + opened
                logs.append(f'{src.name}: cavità CAD chiuse {cad}; aperture chiuse {opened}; facce dei fori rimosse {removed_faces}; candidati esclusi {ambiguous}')
                if original_mesh.users == 0:
                    previous_history=original_mesh.get(hole_choices.HISTORY)
                    bpy.data.meshes.remove(original_mesh)
                    hole_choices.release_history(previous_history)
        finally:
            wm.progress_end()
            timer.finish()
        # Select only successfully committed objects, including after partial failure.
        for obj in list(context.selected_objects):
            obj.select_set(False)
        for obj in modified_objects:
            obj.select_set(True)
        context.view_layer.objects.active = (
            previous_active if previous_active in modified_objects else
            modified_objects[0] if modified_objects else None)
        context.view_layer.update()
        report = bpy.data.texts.get(REPORT) or bpy.data.texts.new(REPORT)
        report.clear()
        report.write('\n\n'.join(logs))
        message = f'{scope}. Mesh modificate: {modified}/{len(sources)}. Invariate: {unchanged}. Fori/cavità chiusi: {total}. Facce dei fori rimosse: {internal}. Candidati esclusi: {rejected}. Ignorati: {skipped}. Errori: {failed}.'
        message += f' Cavità/aperture oltre il limite: {over_limit}.' if limited else ''
        if review:
            message += f' Mesh con aperture, passaggi residui o topologia ambigua: {review}. Chiusura completa non certificata.'
        message += ' Gerarchia e posizione conservate; nessuna copia creata.'
        if not modified and not failed:
            message += ' Nessun foro chiudibile con le impostazioni attuali.'
        report.write('\n\n' + message)
        report.write('\n' + context.scene.fab_holes_time)
        if modified:
            message = f'Oggetti modificati: {modified}/{len(sources)}. Fori chiusi: {total}.'
        else:
            message = 'Nessuna modifica con le impostazioni attuali.'
        if failed:
            message += f' Errori: {failed}. Vedi dettagli.'
        if skipped:
            message += f' Oggetti ignorati: {skipped}.'
        if review:
            message += f' Da verificare: {review}. Vedi dettagli.'
        notice(self, context, message, failed > 0)
        if modified and context.scene.fab_holes_editable and not bpy.app.background:
            area=context.area;window=context.window
            def show_choices():
                try:
                    if area and area.type=='VIEW_3D'and any(a==area for a in window.screen.areas):
                        region=next(r for r in area.regions if r.type=='WINDOW')
                        with bpy.context.temp_override(window=window,area=area,region=region):
                            bpy.ops.fab_holes.edit_choices('INVOKE_DEFAULT')
                except (ReferenceError,RuntimeError,StopIteration):pass
            bpy.app.timers.register(show_choices,first_interval=.1)
        # FINISHED lets Blender retain an undo step for successful changes, even
        # when some other selected objects failed and were left untouched.
        return {'FINISHED'}


class FABHOLES_OT_report(bpy.types.Operator):
    bl_idname = 'fab_holes.copy_report'
    bl_label = 'Copia dettagli'

    def execute(self, context):
        report = bpy.data.texts.get(REPORT)
        context.window_manager.clipboard = report.as_string() if report else context.scene.fab_holes_message
        self.report({'INFO'}, 'Dettagli copiati')
        return {'FINISHED'}


class FABHOLES_PT_panel(bpy.types.Panel):
    bl_label = 'Chiudi fori'
    bl_idname = 'FABHOLES_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Fabularis Tools'
    bl_parent_id = 'FABULARIS_SECTION_OPTIMIZATION'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_hole_closer")


    def draw(self, context):
        layout=self.layout;layout.use_property_decorate=False
        scene=context.scene;n=sum(o.type=='MESH'for o in context.selected_objects)
        layout.row(align=True).prop(scene,'fab_holes_ui_tab',expand=True)
        row=layout.row();row.enabled=False;row.label(text=f'{n} mesh selezionate',icon='MESH_DATA')
        layout.separator(factor=.5)
        action=layout.column(align=True);action.enabled=n>0 and context.mode=='OBJECT'
        if scene.fab_holes_ui_tab=='CLOSE':
            action.prop(scene,'fab_holes_size_mode',text='Fori')
            if scene.fab_holes_size_mode=='LIMITED':
                if selection_ui.LIMIT_KEY in scene:
                    action.prop(scene,'["'+selection_ui.LIMIT_KEY+'"]',text='Max (mm)',slider=True)
                else:action.prop(scene,'fab_holes_max_size_mm',text='Max (mm)',slider=True)
                action.operator('fab_holes.measure',text='Analizza fori',icon='VIEWZOOM').preview_only=True
            action.prop(scene,'fab_holes_editable',text='Fori modificabili')
            action.separator(factor=.5)
            row=action.row();row.scale_y=1.3;row.operator('fab_holes.close',icon='MESH_CIRCLE')
            action.operator('fab_holes.preview',icon='HIDE_OFF',depress=scene.fab_holes_preview)
            if n and context.mode=='OBJECT':
                eligible,outside,unknown=measurements.selection_status(context)
                if not unknown:layout.label(text=f'Entro limite: {eligible} · Fuori: {outside}',icon='INFO')
                elif scene.fab_holes_size_mode=='LIMITED':layout.label(text='Analizza per adattare lo slider',icon='INFO')
        elif scene.fab_holes_ui_tab=='MANAGE':
            recorded=any(o.type=='MESH'and o.data.get(hole_choices.HISTORY)for o in context.selected_objects)
            action.enabled=action.enabled and recorded
            row=action.row();row.scale_y=1.2;row.operator('fab_holes.edit_choices',icon='RESTRICT_SELECT_OFF')
            row=action.row(align=True)
            row.operator('fab_holes.set_all',text='Apri tutti',icon='UNLOCKED').open_all=True
            row.operator('fab_holes.set_all',text='Richiudi tutti',icon='LOCKED').open_all=False
            if not recorded:layout.label(text='Chiudi prima con Fori modificabili',icon='INFO')
            if hole_editor._active:layout.label(text='Maiusc + rotellina / ↑↓: foro dietro',icon='INFO')
        else:
            row=action.row();row.scale_y=1.2;row.operator('fab_holes.measure',icon='DRIVER_DISTANCE')
            action.label(text='Misure sul modello e report',icon='INFO')
        if context.mode!='OBJECT':layout.label(text='Passa alla modalità Oggetto',icon='INFO')
        if scene.fab_holes_time:
            layout.separator(factor=.5)
            row=layout.row();row.alignment='RIGHT';row.scale_y=.75;row.enabled=False
            row.label(text=format_elapsed(scene.fab_holes_elapsed),icon='TIME')


class FABHOLES_PT_details(bpy.types.Panel):
    bl_label = 'Dettagli'
    bl_idname = 'FABHOLES_PT_details'
    bl_parent_id = 'FABHOLES_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Fabularis Tools'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return bool(context.scene.fab_holes_message)and context.scene.fab_holes_ui_tab=='CLOSE'

    def draw(self, context):
        for line in textwrap.wrap(context.scene.fab_holes_message,width=38):self.layout.label(text=line)
        self.layout.operator('fab_holes.copy_report',icon='COPYDOWN')


class FABHOLES_PT_choices(bpy.types.Panel):
    bl_options = {'DEFAULT_CLOSED'}
    bl_label='Elenco chiusure'
    bl_idname='FABHOLES_PT_choices'
    bl_parent_id='FABHOLES_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Fabularis Tools'
    bl_options={'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls,context):
        return context.scene.fab_holes_ui_tab=='MANAGE'and any(o.type=='MESH'and o.data.get(hole_choices.HISTORY)for o in context.selected_objects)

    def draw(self,context):
        layout=self.layout;wm=context.window_manager
        layout.prop(context.scene,'fab_holes_display_state',text='Mostra')
        layout.prop(context.scene,'fab_holes_xray',text='Mostra fori nascosti')
        layout.template_list('FABHOLES_UL_closures','selected',wm,'fab_holes_rows',wm,'fab_holes_row_index',rows=8,maxrows=8)


CLASSES = selection_ui.CLASSES + hole_editor.CLASSES + measurements.CLASSES + (FABHOLES_OT_close, FABHOLES_OT_report, FABHOLES_PT_panel, FABHOLES_PT_details,FABHOLES_PT_choices,measurements.FABHOLES_PT_measurements)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    hole_editor.install()
    measurements.install()
    icons.install()
    bpy.types.Scene.fab_holes_ui_tab=EnumProperty(name='Attività',items=[('CLOSE','Chiudi','Imposta il limite, analizza se serve e chiudi'),('MANAGE','Gestisci','Gestisci chiusure e cartelle per oggetto'),('MEASURE','Misure','Consulta le dimensioni e le etichette')],default='CLOSE',update=selection_ui.tab_changed)
    bpy.types.Scene.fab_holes_time=StringProperty(default='',options={'SKIP_SAVE'})
    bpy.types.Scene.fab_holes_elapsed=FloatProperty(default=0,min=0,options={'SKIP_SAVE'})
    bpy.types.Scene.fab_holes_choice_page=IntProperty(default=1,min=1,options={'SKIP_SAVE'})
    bpy.types.Scene.fab_holes_display_state=EnumProperty(name='Mostra fori',items=[('ALL','Tutti','Mostra tutte le chiusure registrate'),('OPEN','Solo aperti','Mostra solo i fori registrati attualmente aperti'),('CLOSED','Solo chiusi','Mostra solo i fori registrati attualmente chiusi')],default='ALL',update=hole_editor.filter_changed)
    bpy.types.Scene.fab_holes_xray=BoolProperty(default=False,description='Evidenzia e permette di cliccare anche le chiusure dietro altre superfici. L’elenco rende accessibili tutte le chiusure registrate')
    bpy.types.Scene.fab_holes_editable = BoolProperty(name='Fori modificabili',default=False,description='Registra le chiusure per aprire/richiudere le cavità con un clic. Attivare sul modello originale. Sulle griglie complesse può lasciare passaggi residui: controllare il report')
    bpy.types.Scene.fab_holes_message = StringProperty(default='')
    bpy.types.Scene.fab_holes_size_mode = EnumProperty(
        name='Fori da chiudere',
        items=[('ALL', 'Tutti i fori', 'Chiude tutti i fori riconosciuti senza limite di dimensione'),
               ('LIMITED', 'Dimensione massima', 'Chiude solo cavità con tutte le imboccature entro il limite indicato')],
        default='ALL',update=measurements.redraw)
    bpy.types.Scene.fab_holes_max_size_mm = FloatProperty(
        name='Dimensione massima (mm)', min=0.001, soft_max=5.0,
        get=selection_ui.get_limit,set=selection_ui.set_limit,
        precision=3,update=measurements.redraw,
        description='Stesso numero mostrato da Misura fori: diametro massimo del bordo (distanza massima fra due vertici). Misura in mm con scala oggetto e scala unità della scena; tutte le imboccature della cavità devono rispettarla')
    selection_ui.install()


def unregister():
    selection_ui.uninstall()
    hole_editor.uninstall()
    measurements.uninstall()
    icons.uninstall()
    del bpy.types.Scene.fab_holes_ui_tab
    del bpy.types.Scene.fab_holes_time
    del bpy.types.Scene.fab_holes_elapsed
    del bpy.types.Scene.fab_holes_choice_page
    del bpy.types.Scene.fab_holes_display_state
    del bpy.types.Scene.fab_holes_xray
    del bpy.types.Scene.fab_holes_editable
    del bpy.types.Scene.fab_holes_max_size_mm
    del bpy.types.Scene.fab_holes_size_mode
    del bpy.types.Scene.fab_holes_message
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
