"""Read-only hole survey: temporary recognition geometry and screen labels."""
import math
from collections import Counter,defaultdict
import bpy
from bpy.props import BoolProperty,PointerProperty,CollectionProperty,IntProperty,StringProperty
from mathutils import Vector
from . import hole_choices as choices,hole_editor
from .geometry import close_mesh
from .timing import CalculationTimer

_items=[]
_handle=None
_preview_handle=None
_shader=None
_busy=False
_selection_token=None
_selection_since=0.0
_attempted_token=None
_measure_rows_key=None
_measure_filter_flags={}
_measure_folder_state={}
_survey_revision=0
REPORT='Fabularis_Misure_Fori'


def number(value):
    return f'{value:.2f}'if abs(value)>=.1 else f'{value:.6f}'.rstrip('0').rstrip('.')


def mouths(record):
    """Boundary cycles of final caps, not individual tessellation triangles."""
    edges=Counter(tuple(sorted((a,b)))for face in record['caps']for a,b in zip(face,face[1:]+face[:1]))
    remaining={edge for edge,count in edges.items()if count==1};adj=defaultdict(set)
    for a,b in remaining:adj[a].add(b);adj[b].add(a)
    loops=[]
    while remaining:
        first=min(remaining);start,current=first;path=[start];previous=start;remaining.remove(first)
        while current!=start:
            path.append(current)
            candidates=[v for v in adj[current]if tuple(sorted((current,v)))in remaining]
            if len(candidates)!=1:break
            following=candidates[0];remaining.remove(tuple(sorted((current,following))));previous,current=current,following
        if current==start and len(path)>=3:loops.append([Vector(record['vertices'][i])for i in path])
    return loops


def describe(points,matrix,mm,details=True):
    """The same largest 3D vertex-to-vertex span used by the size filter."""
    import numpy as np
    xyz=np.asarray([tuple(matrix@p)for p in points],dtype=float)
    if len(xyz)<3:return None
    largest=0.0
    for offset in range(0,len(xyz),128):
        for other in range(offset,len(xyz),1024):
            delta=xyz[offset:offset+128,None,:]-xyz[None,other:other+1024,:]
            largest=max(largest,float(np.max(np.einsum('ijk,ijk->ij',delta,delta))))
    maximum=math.sqrt(largest)*mm
    if not details:return {'maximum_mm':maximum}
    center=matrix.inverted()@Vector(xyz.mean(axis=0).tolist())
    return {'kind':'span','values':(maximum,),'text':number(maximum)+' mm',
            'center':tuple(center),'maximum_mm':maximum}


def summarize(payload,matrix,mm,details=True):
    labels=[];groups={}
    for record in payload['records']:
        for points in mouths(record):
            measure=describe(points,matrix,mm,details=details)
            if measure is None:continue
            if not details:
                measure['id']=record['id'];measure['outline']=[tuple(p)for p in points]
                labels.append(measure);continue
            # One geometric span, shared by labels and the closing filter.
            # Absorb only the same floating-point tolerance as within_size;
            # otherwise round UP so the displayed number is usable as input.
            raw=measure['maximum_mm'];digits=3 if raw>=.001 else 6
            factor=10**digits;nearest=round(raw,digits)
            tolerance=max(raw*1e-6,1e-10*mm)
            threshold=nearest if nearest>0 and raw<=nearest+tolerance else math.ceil(raw*factor-1e-8)/factor
            measure['filter_mm']=threshold
            value=f'{threshold:.{digits}f}'.rstrip('0').rstrip('.')
            measure['text']=value+' mm'
            key=(measure['kind'],threshold)
            group=groups.setdefault(key,{'text':measure['text'],'ids':set(),'mouths':0})
            group['ids'].add(record['id']);group['mouths']+=1
            measure['id']=record['id'];measure['group']=key;labels.append(measure)
            measure['outline']=[tuple(p)for p in points]
    for label in labels if details else ():
        count=len(groups[label['group']]['ids'])
        label['label']=label['text']+(f' · {count} uguali'if count>1 else'')
    return labels,list(groups.values())


def clear():
    global _handle,_preview_handle,_shader,_measure_rows_key,_survey_revision
    _survey_revision+=1
    _measure_rows_key=None;_measure_filter_flags.clear()
    _items.clear()
    if _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle,'WINDOW');_handle=None
    if _preview_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_preview_handle,'WINDOW');_preview_handle=None
    _shader=None


def visible_items(context):
    for item in _items:
        try:
            obj=item['object']
            if obj.type!='MESH'or not obj.select_get()or not obj.visible_get()or obj.data!=item['mesh']:continue
            if tuple(v for row in obj.matrix_world.to_3x3()for v in row)!=item['linear']:continue
            if context.scene.unit_settings.scale_length!=item['units']:continue
            yield item
        except ReferenceError:continue


def draw_labels():
    import blf
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    context=bpy.context
    if context.scene.fab_holes_preview or not context.scene.fab_holes_measure_show or context.mode!='OBJECT':return
    region=context.region;view=context.region_data
    if region is None or view is None:return
    blf.size(0,12);blf.enable(0,blf.SHADOW);blf.shadow(0,3,0,0,0,.95);blf.shadow_offset(0,1,-1)
    occupied=set()
    try:
        for item in visible_items(context):
            if not item.get('details',True)or not getattr(item['object'],'fab_holes_group_visible',True)or not measurement_visible(item['object']):continue
            matrix=item['object'].matrix_world
            for label in item['labels']:
                screen=location_3d_to_region_2d(region,view,matrix@Vector(label['center']))
                if screen is None or not(0<=screen.x<region.width and 0<=screen.y<region.height):continue
                # A through-hole's two mouths can project onto one pixel.
                key=(round(screen.x/6),round(screen.y/6),label['label'])
                if key in occupied:continue
                occupied.add(key)
                blf.position(0,screen.x+7,screen.y+7,0);blf.color(0,1,0,100/255,1);blf.draw(0,label['label'])
    finally:blf.disable(0,blf.SHADOW)


def redraw(self,context):
    if context is None or not context.scene.fab_holes_preview:return
    request_redraw(context)


def request_redraw(context):
    if context is None:return
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type=='VIEW_3D':area.tag_redraw()


def preview_ids(item,scene):
    """All mouths of a communicating cavity must satisfy the same limit."""
    if 'preview_sizes'not in item:
        required={}
        for label in item['labels']:
            identity=label['id'];required[identity]=max(required.get(identity,0),label['maximum_mm'])
        item['preview_sizes']=required
    required=item['preview_sizes']
    if scene.fab_holes_size_mode=='ALL':return set(required)
    maximum=scene.fab_holes_max_size_mm
    tolerance=max(maximum*1e-6,1e-10*1000*scene.unit_settings.scale_length)
    return {identity for identity,size in required.items()if size<=maximum+tolerance}


def preview_ready(context):
    selected={o for o in context.selected_objects if o.type=='MESH'}
    return bool(selected)and selected<={item['object']for item in visible_items(context)}


def selection_status(context):
    """Only cached spans: no geometry work in panel draw."""
    selected={o for o in context.selected_objects if o.type=='MESH' and o.visible_get()}
    known={item['object']:item for item in visible_items(context)}
    eligible=outside=0
    for item in known.values():
        eligible+=len(preview_ids(item,context.scene))
        outside+=len(item['preview_sizes'])-len(preview_ids(item,context.scene))
    return eligible,outside,len(selected-set(known))


def refresh_preview_selection(context):
    """Called outside drawing/handlers; only missing selected sources are surveyed."""
    if _busy or context.mode!='OBJECT' or not context.scene.fab_holes_preview:return
    if not any(o.type=='MESH' and o.visible_get() for o in context.selected_objects):return
    if not preview_ready(context):
        bpy.ops.fab_holes.measure(preview_only=True,missing_only=True)
    show_preview();request_redraw(context)


def selection_tick():
    global _selection_token,_selection_since,_attempted_token
    import time
    context=bpy.context
    if not context.scene or not context.scene.fab_holes_preview:return None
    if _busy or context.mode!='OBJECT':return .25
    token=(context.scene.as_pointer(),tuple(sorted(
        (o.as_pointer(),o.data.as_pointer(),tuple(v for row in o.matrix_world.to_3x3()for v in row))
        for o in context.selected_objects if o.type=='MESH' and o.visible_get())),
        context.scene.unit_settings.scale_length,tuple(id(item)for item in visible_items(context)))
    if token!=_selection_token:
        _selection_token=token;_selection_since=time.monotonic()
        request_redraw(context)
    elif time.monotonic()-_selection_since>=.35 and token!=_attempted_token:
        _attempted_token=token
        try:refresh_preview_selection(context)
        except Exception as exc:
            context.scene.fab_holes_message='Anteprima: '+str(exc)
    return .25


def cached_empty_sources(context):
    """No recognition/copies when a valid survey has no eligible cavities."""
    if context.scene.fab_holes_size_mode!='LIMITED':return {}
    sources=[o for o in context.selected_objects if o.type=='MESH']
    if not _items and not any(o.data.get(choices.HISTORY)for o in sources):return {}
    # Flush pending edits before trusting the geometry snapshot. Depsgraph
    # invalidation also discards surveys whose evaluated geometry changed.
    context.view_layer.update()
    empty={}
    for item in visible_items(context):
        obj=item['object']
        if obj.modifiers or obj.animation_data or obj.data.shape_keys:continue
        if item.get('signature')!=choices.signature(obj.data):continue
        if not preview_ids(item,context.scene):
            empty[obj]=len({label['id']for label in item['labels']})
    # Persisted history is another valid source of already recognized holes,
    # even after reloading a .blend or removing the measurement overlay.
    for obj in sources:
        if obj in empty or obj.modifiers or obj.animation_data or obj.data.shape_keys:continue
        if not obj.data.get(choices.HISTORY):continue
        try:
            payload=choices.read(obj.data);choices.validate(obj,payload)
        except (ValueError,TypeError,KeyError):continue
        opened=set(obj.get(choices.OPEN,[]))
        records=[r for r in payload['records']if r['id']in opened]
        if not records:
            empty[obj]=0;continue
        linear=obj.matrix_world.copy();linear.translation=(0,0,0)
        labels,_=summarize({'records':records},linear,1000*context.scene.unit_settings.scale_length,details=False)
        if labels and not preview_ids({'labels':labels},context.scene):empty[obj]=len(records)
    return empty


def draw_preview():
    global _shader
    context=bpy.context
    if context.mode!='OBJECT'or not context.scene.fab_holes_preview:return
    import gpu
    from gpu_extras.batch import batch_for_shader
    if _shader is None:_shader=gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA');gpu.state.depth_test_set('LESS_EQUAL');gpu.state.line_width_set(3)
    try:
        for item in visible_items(context):
            if not getattr(item['object'],'fab_holes_group_visible',True):continue
            selected=preview_ids(item,context.scene)
            if 'preview_batches'not in item:
                lines=defaultdict(list)
                for label in item['labels']:
                    points=label['outline']
                    for a,b in zip(points,points[1:]+points[:1]):lines[label['id']].extend((a,b))
                item['preview_batches']={i:batch_for_shader(_shader,'LINES',{'pos':points})for i,points in lines.items()}
            gpu.matrix.push()
            try:
                gpu.matrix.multiply_matrix(item['object'].matrix_world)
                _shader.bind();_shader.uniform_float('color',(.05,1,.25,1))
                for identity in selected:
                    batch=item['preview_batches'].get(identity)
                    if batch:batch.draw(_shader)
            finally:gpu.matrix.pop()
    except ReferenceError:pass
    finally:
        gpu.state.depth_test_set('NONE');gpu.state.blend_set('NONE');gpu.state.line_width_set(1)


def show():
    global _handle
    if _handle is None and bpy.context.scene.fab_holes_measure_show and not bpy.app.background:
        _handle=bpy.types.SpaceView3D.draw_handler_add(draw_labels,(),'WINDOW','POST_PIXEL')
    if bpy.context.scene.fab_holes_preview:show_preview()


def labels_changed(self,context):
    global _handle
    if context and context.scene.fab_holes_measure_show and _items:show()
    elif _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle,'WINDOW');_handle=None
    request_redraw(context)


def show_preview():
    global _preview_handle
    if _preview_handle is None and not bpy.app.background:
        _preview_handle=bpy.types.SpaceView3D.draw_handler_add(draw_preview,(),'WINDOW','POST_VIEW')


def stop_preview():
    global _preview_handle,_shader
    if _preview_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_preview_handle,'WINDOW');_preview_handle=None
    for item in _items:item.pop('preview_batches',None)
    _shader=None


def preview_changed(self,context):
    global _selection_token,_attempted_token
    _selection_token=_attempted_token=None
    if context and context.scene.fab_holes_preview:
        show_preview()
        if not bpy.app.background and not bpy.app.timers.is_registered(selection_tick):
            bpy.app.timers.register(selection_tick,first_interval=.25)
    else:
        stop_preview()
        if bpy.app.timers.is_registered(selection_tick):bpy.app.timers.unregister(selection_tick)
    request_redraw(context)


class FABHOLES_OT_preview(bpy.types.Operator):
    bl_idname='fab_holes.preview'
    bl_label='Anteprima verde'
    bl_description='Calcola una volta i fori riconosciuti e aggiorna il verde con Max (mm), senza modificare le mesh'

    @classmethod
    def poll(cls,context):return context.mode=='OBJECT'and any(o.type=='MESH'for o in context.selected_objects)

    def execute(self,context):
        if context.scene.fab_holes_preview:
            context.scene.fab_holes_preview=False;return {'FINISHED'}
        if not preview_ready(context):
            previous_labels=context.scene.fab_holes_measure_show and bool(_items)
            if bpy.ops.fab_holes.measure(preview_only=True)!={'FINISHED'}:return {'CANCELLED'}
            context.scene.fab_holes_measure_show=previous_labels
        context.scene.fab_holes_size_mode='LIMITED'
        context.scene.fab_holes_preview=True;show_preview();redraw(None,context)
        return {'FINISHED'}


class FABHOLES_OT_measure(bpy.types.Operator):
    bl_idname='fab_holes.measure'
    bl_label='Misura fori'
    bl_description='Analizza le mesh selezionate senza modificarle e mostra le dimensioni delle imboccature in mm'
    preview_only:BoolProperty(default=False,options={'HIDDEN','SKIP_SAVE'})
    missing_only:BoolProperty(default=False,options={'HIDDEN','SKIP_SAVE'})

    @classmethod
    def poll(cls,context):return context.mode=='OBJECT'and any(o.type=='MESH'for o in context.selected_objects)

    def execute(self,context):
        global _busy,_survey_revision
        hole_editor.stop()
        keep=True # Keep valid surveys of other objects when measuring a new selection.
        known={item['object'] for item in visible_items(context)}if self.missing_only else set()
        sources=[o for o in context.selected_objects if o.type=='MESH' and o.visible_get() and o not in known]
        if not sources:return {'FINISHED'}
        if not keep:clear()
        _busy=True
        timer=CalculationTimer(context);found=[];logs=[];failed=0
        dg=context.evaluated_depsgraph_get()
        wm=context.window_manager;wm.progress_begin(0,len(sources))
        try:
            for index,obj in enumerate(sources):
                mesh=None
                try:
                    timer.set_stage('Misure: '+obj.name);timer.update()
                    matrix=obj.matrix_world.copy();linear=matrix.copy();linear.translation=(0,0,0)
                    if abs(linear.determinant())<1e-15:raise ValueError('Scala nulla')
                    payload=choices.read(obj.data)if not obj.modifiers else None
                    if payload:
                        try:choices.validate(obj,payload)
                        except ValueError:payload=None
                    diagnostics={}
                    if payload is None:
                        mesh=bpy.data.meshes.new_from_object(obj.evaluated_get(dg),preserve_all_data_layers=True,depsgraph=dg)
                        if choices.HISTORY in mesh:del mesh[choices.HISTORY]
                        for name in (choices.LAYER,choices.VERT):
                            attr=mesh.attributes.get(name)
                            if attr:mesh.attributes.remove(attr)
                        mesh.transform(linear);recorder=choices.Recorder()
                        close_mesh(mesh,diagnostics=diagnostics,history=recorder,progress=timer.update)
                        mesh.transform(linear.inverted())
                        if linear.determinant()<0:mesh.flip_normals()
                        mesh.update()
                        payload=recorder.store(mesh,linear.inverted(),write=False)if recorder.records else{'records':[]}
                    mm=1000*context.scene.unit_settings.scale_length
                    labels,groups=summarize(payload,linear,mm,details=not self.preview_only)
                    found.append({'object':obj,'mesh':obj.data,'signature':choices.signature(obj.data),'labels':labels,'groups':groups,'units':context.scene.unit_settings.scale_length,
                                  'linear':tuple(v for row in matrix.to_3x3()for v in row),'details':not self.preview_only})
                    if self.preview_only:continue
                    logs.append(obj.name+f': {len(payload["records"])} cavità riconosciute; {len(labels)} imboccature misurate.')
                    for group in groups:logs.append(f'  {group["text"]}: {len(group["ids"])} cavità, {group["mouths"]} imboccature')
                    for label in labels:logs.append(f'  Foro {label["id"]}: {label["text"]}')
                    if payload.get('partial_components')or any(diagnostics.get(k,0)for k in ('remaining_openings','remaining_passages','uncertain_topology')):
                        logs.append('  Analisi parziale: aperture/passaggi residui o topologia ambigua; non tutte le cavità geometriche sono certificate.')
                except Exception as exc:failed+=1;logs.append(f'{obj.name}: {exc}')
                finally:
                    if mesh and mesh.users==0:bpy.data.meshes.remove(mesh)
                    wm.progress_update(index+1)
        finally:
            wm.progress_end();timer.finish();_busy=False
        context.view_layer.update()
        replaced={item['object']for item in found}
        _items[:]=[item for item in _items if item['object']not in replaced]
        _items.extend(found)
        if found:
            _survey_revision+=1
            from . import selection_ui
            selection_ui.refresh_range(context)
        if self.preview_only:
            if failed:self.report({'WARNING'},f'Anteprima: {failed} mesh non analizzate.')
            return {'FINISHED'}if found else{'CANCELLED'}
        sync_measure_rows(context)
        context.scene.fab_holes_measure_show=True;show()
        text=bpy.data.texts.get(REPORT)or bpy.data.texts.new(REPORT);text.clear()
        text.write('MISURE FORI — unico valore in mm, uguale a Max (mm) del filtro.\nDiametro massimo geometrico del bordo: per un foro circolare è il diametro; per altre forme è la massima distanza fra due punti del bordo.\nUguali = stessa misura visualizzata nella stessa mesh; le due imboccature di un passante contano come una cavità.\nNessuna mesh sorgente modificata. Il riconoscimento non certifica tutte le cavità.\n\n'+'\n'.join(logs)+'\n'+context.scene.fab_holes_time)
        count=sum(len(item['labels'])for item in found)
        self.report({'INFO'},f'Imboccature misurate: {count}. Mesh invariate.'+(f' Errori: {failed}.'if failed else''))
        if context.area:context.area.tag_redraw()
        return {'FINISHED'}if found else{'CANCELLED'}


class FABHOLES_OT_measure_clear(bpy.types.Operator):
    bl_idname='fab_holes.clear_measurements'
    bl_label='Rimuovi misure'
    def execute(self,context):
        clear()
        if context.area:context.area.tag_redraw()
        return {'FINISHED'}


class FABHOLES_OT_measure_report(bpy.types.Operator):
    bl_idname='fab_holes.copy_measurements'
    bl_label='Copia misure'
    def execute(self,context):
        text=bpy.data.texts.get(REPORT)
        context.window_manager.clipboard=text.as_string()if text else''
        return {'FINISHED'}


def measurement_visible(obj):
    return _measure_folder_state.get(obj.as_pointer(),{}).get('visible',True)


def measurement_folder_changed(self,context):
    obj=self.object
    if obj:
        _measure_folder_state[obj.as_pointer()]={'expanded':self.expanded,'visible':self.visible}
    _measure_filter_flags.clear();request_redraw(context)


class FABHOLES_PG_measure_row(bpy.types.PropertyGroup):
    object:PointerProperty(type=bpy.types.Object)
    is_group:BoolProperty()
    value:StringProperty()
    count:IntProperty()
    expanded:BoolProperty(default=True,update=measurement_folder_changed)
    visible:BoolProperty(default=True,update=measurement_folder_changed,description='Mostra o nasconde le etichette di misura di questo oggetto senza cancellare l’analisi')


class FABHOLES_OT_copy_value(bpy.types.Operator):
    bl_idname='fab_holes.copy_value'
    bl_label='Copia valore'
    bl_description='Copia solo il numero in mm, utilizzabile come Max (mm)'
    value:StringProperty()
    def execute(self,context):
        context.window_manager.clipboard=self.value
        return {'FINISHED'}



def grouped_values(item):
    """One displayed threshold per object, counting each cavity only once."""
    groups={}
    for group in item['groups']:
        value=group['text'].removesuffix(' mm')
        groups.setdefault(value,set()).update(group['ids'])
    return [(value,len(ids))for value,ids in sorted(groups.items(),key=lambda pair:float(pair[0]))]


def sync_measure_rows(context):
    global _measure_rows_key
    items=sorted((item for item in visible_items(context)if item.get('details',True)),key=lambda item:item['object'].name_full)
    key=tuple((id(item),item['object'].name)for item in items)
    if key==_measure_rows_key:return False
    wm=context.window_manager;wm.fab_holes_measure_rows.clear()
    _measure_filter_flags.clear();_measure_rows_key=key
    for item in items:
        obj=item['object'];state=dict(_measure_folder_state.get(obj.as_pointer(),{'expanded':True,'visible':True}))
        header=wm.fab_holes_measure_rows.add();header.object=obj;header.is_group=True
        header.expanded=state['expanded'];header.visible=state['visible']
        for value,count in grouped_values(item):
            row=wm.fab_holes_measure_rows.add();row.object=obj;row.value=value;row.count=count
    wm.fab_holes_measure_row_index=0
    return True


class FABHOLES_UL_measures(bpy.types.UIList):
    def filter_items(self,context,data,propname):
        flag=self.bitflag_filter_item
        if flag not in _measure_filter_flags:
            _measure_filter_flags[flag]=[flag if row.is_group or(row.object and _measure_folder_state.get(row.object.as_pointer(),{}).get('expanded',True))else 0 for row in getattr(data,propname)]
        return _measure_filter_flags[flag],[]

    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
        obj=item.object
        if obj is None:return
        row=layout.row(align=True)
        if item.is_group:
            row.prop(item,'expanded',text='',icon='TRIA_DOWN'if item.expanded else'TRIA_RIGHT',emboss=False)
            row.label(text=obj.name,icon='FILE_FOLDER')
            row.prop(item,'visible',text='',icon='HIDE_OFF'if item.visible else'HIDE_ON',emboss=False)
        else:
            row.separator(factor=1)
            row.label(text=f'{item.value} mm · {item.count} '+('foro'if item.count==1 else'fori'))
            row.operator('fab_holes.copy_value',text='',icon='COPYDOWN',emboss=False).value=item.value


class FABHOLES_PT_measurements(bpy.types.Panel):
    bl_label='Misure fori'
    bl_idname='FABHOLES_PT_measurements'
    bl_parent_id='FABHOLES_PT_panel'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Fabularis Tools'
    bl_options={'DEFAULT_CLOSED'}
    @classmethod
    def poll(cls,context):return context.scene.fab_holes_ui_tab=='MEASURE'and not context.scene.fab_holes_preview and any(item.get('details',True)for item in _items)
    def draw(self,context):
        layout=self.layout;layout.prop(context.scene,'fab_holes_measure_show',text='Mostra misure')
        wm=context.window_manager
        layout.template_list('FABHOLES_UL_measures','by_object',wm,'fab_holes_measure_rows',wm,'fab_holes_measure_row_index',rows=8,maxrows=8)
        row=layout.row(align=True);row.operator('fab_holes.copy_measurements',text='Copia misure');row.operator('fab_holes.clear_measurements',text='Rimuovi')


@bpy.app.handlers.persistent
def invalidate(_):
    _measure_folder_state.clear();clear()


@bpy.app.handlers.persistent
def geometry_changed(scene,depsgraph):
    if not _items:return
    changed=set()
    for update in depsgraph.updates:
        if update.is_updated_geometry:
            identity=getattr(update.id,'original',update.id)
            changed.add(identity)
    if not changed:return
    retained=[]
    for item in _items:
        try:
            if item['object']not in changed and item['mesh']not in changed:retained.append(item)
        except ReferenceError:pass
    if len(retained)!=len(_items):
        _items[:]=retained
        if not retained:clear()


CLASSES=(FABHOLES_PG_measure_row,FABHOLES_UL_measures,FABHOLES_OT_copy_value,FABHOLES_OT_measure,FABHOLES_OT_measure_clear,FABHOLES_OT_measure_report,FABHOLES_OT_preview)


def install():
    bpy.types.WindowManager.fab_holes_measure_rows=CollectionProperty(type=FABHOLES_PG_measure_row,options={'SKIP_SAVE'})
    bpy.types.WindowManager.fab_holes_measure_row_index=IntProperty(default=0,min=0,options={'SKIP_SAVE'})
    bpy.types.Scene.fab_holes_measure_show=BoolProperty(default=True,options={'SKIP_SAVE'},update=labels_changed)
    bpy.types.Scene.fab_holes_preview=BoolProperty(default=False,options={'SKIP_SAVE'},update=preview_changed)
    for handlers in (bpy.app.handlers.load_pre,bpy.app.handlers.undo_pre,bpy.app.handlers.redo_pre):
        if invalidate not in handlers:handlers.append(invalidate)
    if geometry_changed not in bpy.app.handlers.depsgraph_update_post:bpy.app.handlers.depsgraph_update_post.append(geometry_changed)


def uninstall():
    if bpy.app.timers.is_registered(selection_tick):bpy.app.timers.unregister(selection_tick)
    clear()
    for handlers in (bpy.app.handlers.load_pre,bpy.app.handlers.undo_pre,bpy.app.handlers.redo_pre):
        if invalidate in handlers:handlers.remove(invalidate)
    if geometry_changed in bpy.app.handlers.depsgraph_update_post:bpy.app.handlers.depsgraph_update_post.remove(geometry_changed)
    _measure_folder_state.clear()
    del bpy.types.WindowManager.fab_holes_measure_rows
    del bpy.types.WindowManager.fab_holes_measure_row_index
    del bpy.types.Scene.fab_holes_measure_show
    del bpy.types.Scene.fab_holes_preview
