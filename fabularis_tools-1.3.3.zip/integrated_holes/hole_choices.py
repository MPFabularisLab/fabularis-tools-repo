"""Reversible recorded closures; rebuild only from the saved closed mesh."""
import base64
import hashlib
import json
import uuid
import zlib
import copy
from array import array
import bpy
import bmesh
from mathutils import Vector

HISTORY='fab_hole_history'
OPEN='fab_open_holes'
LAYER='fab_choice_id'
VERT='fab_choice_vertex'
BASE='fab_closed_base'
WORK='fab_work_signature'
_id_cache={}


class Recorder:
    def __init__(self):self.records=[];self.serial=0;self.identity_serial=0;self.prepared=False;self.partial_components=0

    def resume(self,payload,mesh,matrix,opened=()):
        """Keep previous closed patches when processing this object again."""
        opened=set(opened)
        self.records=copy.deepcopy([r for r in payload['records']if r['id']not in opened])
        for record in self.records:
            record['vertices']=[list(matrix@Vector(v))for v in record['vertices']]
            record['wall_choices']=[0]*len(record['walls'])
            if matrix.determinant()<0:
                record['walls']=[list(reversed(f))for f in record['walls']]
                record['caps']=[list(reversed(f))for f in record['caps']]
                record['uv']=[{name:list(reversed(values))for name,values in face.items()}for face in record['uv']]
        self.serial=max((item.value for item in mesh.attributes[VERT].data),default=0)
        self.serial=max(self.serial,max((i for r in self.records for i in r['vertex_ids']),default=0))
        self.partial_components=payload.get('partial_components',0)
        self.prepared=True

    def prepare(self,bm):
        self.identity_serial=max(self.identity_serial,max((r['id']for r in self.records),default=0))
        layer=bm.faces.layers.int.get(LAYER)or bm.faces.layers.int.new(LAYER)
        self.vertex_layer=bm.verts.layers.int.get(VERT)or bm.verts.layers.int.new(VERT)
        if not self.prepared:
            for face in bm.faces:face[layer]=0
            for vertex in bm.verts:vertex[self.vertex_layer]=0
            self.prepared=True
        self.references={v[self.vertex_layer]:v for v in bm.verts if v[self.vertex_layer]}

    def refresh(self,bm):
        for v in bm.verts:
            identity=v[self.vertex_layer]
            if identity and self.references.get(identity)!=v:
                self.serial+=1;v[self.vertex_layer]=self.serial;self.references[self.serial]=v

    def capture(self,originals,caps,original_coordinates=None,wall_choices=None):
        coordinates=original_coordinates or {};vertices=[];index={};vertex_ids=[]
        def vert(v):
            if v not in index:
                index[v]=len(vertices);vertices.append(list(coordinates.get(v,v.co)))
                if not v[self.vertex_layer]:
                    self.serial+=1;v[self.vertex_layer]=self.serial;self.references[self.serial]=v
                vertex_ids.append(v[self.vertex_layer])
            return index[v]
        walls=[[vert(v)for v in vs]for vs,material,smooth,uv in originals]
        faces=[[vert(v)for v in face.verts]for face in caps]
        self.identity_serial+=1
        record={'id':self.identity_serial,'vertices':vertices,'vertex_ids':vertex_ids,'walls':walls,'caps':faces,
                'materials':[material for vs,material,smooth,uv in originals]+[f.material_index for f in caps],
                'wall_choices':wall_choices or [0]*len(walls),
                'boundary':not bool(originals),
                'uv':[{layer.name:[list(v)for v in values]for layer,values in uv}for vs,material,smooth,uv in originals],
                'smooth':[smooth for vs,material,smooth,uv in originals]}
        self.records.append(record);return record['id']

    def tag(self,bm,faces,identity):
        layer=bm.faces.layers.int.get(LAYER)or bm.faces.layers.int.new(LAYER)
        for face in faces:face[layer]=identity

    def store(self,mesh,inverse,write=True):
        attribute=mesh.attributes.get(LAYER)
        for record in self.records:
            record['vertices']=[list(inverse@Vector(v))for v in record['vertices']]
            if inverse.determinant()<0:
                record['walls']=[list(reversed(f))for f in record['walls']]
                record['caps']=[list(reversed(f))for f in record['caps']]
                record['uv']=[{name:list(reversed(values))for name,values in face.items()}for face in record['uv']]
        # A later pass can close a communicating cavity through an earlier
        # cap. Treat the dependent closures as one reversible patch, retaining
        # the real walls and excluding their temporary internal caps.
        parents={r['id']:r['id']for r in self.records}
        def root(identity):
            while parents[identity]!=identity:identity=parents[identity]
            return identity
        for record in self.records:
            for dependency in record['wall_choices']:
                if dependency in parents:
                    a,b=root(record['id']),root(dependency);parents[max(a,b)]=min(a,b)
        groups={}
        for record in self.records:groups.setdefault(root(record['id']),[]).append(record)
        values=[root(item.value)if item.value in parents else 0 for item in attribute.data]
        attribute.data.foreach_set('value',values)
        caps_by_id={}
        for polygon,value in zip(mesh.polygons,values):
            if value:caps_by_id.setdefault(value,[]).append(polygon.index)
        vertices=mesh.attributes[VERT]
        for item in vertices.data:
            if not item.value:self.serial+=1;item.value=self.serial
        combined=[]
        for identity,records in groups.items():
            result={'id':identity,'vertices':[],'vertex_ids':[],'walls':[],'caps':[],'materials':[],'uv':[],'smooth':[]}
            index={}
            def vertex(vid,co):
                if vid not in index:
                    index[vid]=len(index);result['vertex_ids'].append(vid);result['vertices'].append(list(co))
                return index[vid]
            for record in records:
                for n,face in enumerate(record['walls']):
                    if record['wall_choices'][n]:continue
                    result['walls'].append([vertex(record['vertex_ids'][i],record['vertices'][i])for i in face])
                    result['materials'].append(record['materials'][n]);result['uv'].append(record['uv'][n]);result['smooth'].append(record['smooth'][n])
            for polygon_index in caps_by_id.get(identity,[]):
                polygon=mesh.polygons[polygon_index]
                result['caps'].append([vertex(vertices.data[i].value,mesh.vertices[i].co)for i in polygon.vertices])
                result['materials'].append(polygon.material_index)
            if not result['caps']:raise ValueError(f'Chiusura {identity} non più separabile: oggetto originale conservato.')
            result['boundary']=not bool(result['walls']);combined.append(result)
        self.records=combined
        payload={'version':3,'records':self.records,'signature':signature(mesh),'partial_components':self.partial_components}
        if not write:return payload
        encoded=base64.b85encode(zlib.compress(json.dumps(payload,separators=(',',':')).encode(),6)).decode()
        text=bpy.data.texts.new('.Fabularis_Fori_'+uuid.uuid4().hex[:12])
        # Avoid quadratic insertion time in Blender's Text buffer.
        text.write('\n'.join(encoded[i:i+120]for i in range(0,len(encoded),120)))
        text.use_fake_user=True;text['fab_holes_record']=True;mesh[HISTORY]=text
        text['fab_holes_ids']=[r['id']for r in self.records]


def signature(mesh):
    digest=hashlib.blake2b(digest_size=16)
    coordinates=array('f',[0])*(len(mesh.vertices)*3);mesh.vertices.foreach_get('co',coordinates);digest.update(coordinates.tobytes())
    indices=array('i',[0])*len(mesh.loops);mesh.loops.foreach_get('vertex_index',indices);digest.update(indices.tobytes())
    digest.update(str((len(mesh.vertices),len(mesh.edges),len(mesh.polygons))).encode());return digest.hexdigest()


def read(mesh):
    ref=mesh.get(HISTORY)
    text=ref if isinstance(ref,bpy.types.Text)else bpy.data.texts.get(ref)if ref else None
    if text is None:return None
    return json.loads(zlib.decompress(base64.b85decode(''.join(text.as_string().split()))).decode())


def record_ids(mesh):
    """Small UI index: never inflate the complete wall history on a redraw."""
    ref=mesh.get(HISTORY)
    text=ref if isinstance(ref,bpy.types.Text)else bpy.data.texts.get(ref)if ref else None
    if text is None:return ()
    if 'fab_holes_ids'in text:return tuple(text['fab_holes_ids'])
    # Compatibility for 0.3.0/0.3.1 files, without writing RNA during draw.
    key=(text.as_pointer(),text.name)
    if key not in _id_cache:
        if len(_id_cache)>=16:_id_cache.clear()
        _id_cache[key]=tuple(r['id']for r in read(mesh)['records'])
    return _id_cache[key]


def validate(obj,payload):
    base=obj.get(BASE)
    expected=obj.get(WORK)if base else payload['signature']
    if signature(obj.data)!=expected or (base and signature(base)!=payload['signature']):
        raise ValueError('La mesh è stata modificata dopo la chiusura. Rigenera le chiusure sul modello originale.')
    return base or obj.data


def release_history(text):
    if not isinstance(text,bpy.types.Text)or not text.get('fab_holes_record'):return
    if not any(mesh.get(HISTORY)==text for mesh in bpy.data.meshes):bpy.data.texts.remove(text)


def cleanup(obj):
    base=obj.get(BASE)
    for key in (BASE,OPEN,WORK):
        if key in obj:del obj[key]
    if base and base.users==0:
        text=base.get(HISTORY);bpy.data.meshes.remove(base);release_history(text)


def rebuilt_mesh(base,payload,opened):
    """Remove recorded caps, then restore their original cavity walls.

    Only a cap's own rim vertices are reused. Coincident vertices from other
    disconnected components are never welded into the restored cavity.
    """
    bm=bmesh.new();result=None
    try:
        bm.from_mesh(base);layer=bm.faces.layers.int.get(LAYER);vertex_layer=bm.verts.layers.int.get(VERT)
        if layer is None:raise ValueError('Dati delle chiusure mancanti: riparti dal modello originale.')
        groups={identity:[]for identity in opened}
        for face in bm.faces:
            if face[layer]in groups:groups[face[layer]].append(face)
        records={r['id']:r for r in payload['records']}
        for identity in sorted(opened):
            record=records[identity];caps=groups[identity]
            if not caps:raise ValueError('Questa chiusura non è più disponibile.')
            cap_set=set(caps)
            rim={v for face in caps for v in face.verts}
            boundary={v for face in caps for edge in face.edges if any(f not in cap_set for f in edge.link_faces)for v in edge.verts}
            current={v[vertex_layer]:v for v in rim}
            points=[Vector(v)for v in record['vertices']]
            span=max(max(p[k]for p in points)-min(p[k]for p in points)for k in range(3))
            magnitude=max(abs(value)for p in points for value in p)
            tolerance=max(span*1e-6,magnitude*1e-7,1e-10)
            mapping={}
            used={i for face in record['walls']for i in face}
            for i in used:
                mapping[i]=current.get(record['vertex_ids'][i])or bm.verts.new(points[i])
            originals=set(record['vertex_ids']);extra=[v for v in boundary if v[vertex_layer]not in originals]
            cap_edges={frozenset((face[i],face[(i+1)%len(face)]))for face in record['caps']for i in range(len(face))}
            edges={e for face in caps for e in face.edges}
            bmesh.ops.delete(bm,geom=caps,context='FACES_ONLY')
            for n,indices in enumerate(record['walls']):
                expanded=[];expanded_uv=[]
                for j,i in enumerate(indices):
                    following=indices[(j+1)%len(indices)];a=mapping[i];b=mapping[following];expanded.append(a);expanded_uv.append((j,0))
                    if frozenset((i,following))not in cap_edges:continue
                    delta=b.co-a.co;length=delta.length_squared
                    if not length:continue
                    splits=[]
                    for v in extra:
                        factor=(v.co-a.co).dot(delta)/length
                        if 1e-7<factor<1-1e-7 and (v.co-(a.co+delta*factor)).length<=tolerance:splits.append((factor,v))
                    for factor,v in sorted(splits,key=lambda pair:pair[0]):expanded.append(v);expanded_uv.append((j,factor))
                face=bm.faces.new(expanded);face.material_index=record['materials'][n]
                face.smooth=record['smooth'][n]
                for name,values in record['uv'][n].items():
                    uv=bm.loops.layers.uv.get(name)or bm.loops.layers.uv.new(name)
                    for loop,(j,factor)in zip(face.loops,expanded_uv):
                        a=Vector(values[j]);b=Vector(values[(j+1)%len(values)]);loop[uv].uv=a.lerp(b,factor)
            # Remove only unused geometry belonging to the removed caps.
            wires=[e for e in edges if e.is_valid and not e.link_faces]
            if wires:bmesh.ops.delete(bm,geom=wires,context='EDGES')
            loose=[v for v in rim if v.is_valid and not v.link_edges]
            if loose:bmesh.ops.delete(bm,geom=loose,context='VERTS')
        bm.normal_update();result=base.copy();bm.to_mesh(result);result.update();return result
    except Exception:
        if result and result.users==0:bpy.data.meshes.remove(result)
        raise
    finally:bm.free()


def toggle(obj,hole_id):
    payload=read(obj.data)
    if not payload or payload.get('version')!=3 or not any(r['id']==hole_id for r in payload['records']):
        raise ValueError('Chiusura non disponibile. Attiva Fori modificabili prima di chiudere i fori.')
    opened=set(obj.get(OPEN,[]))^{hole_id}
    set_opened(obj,opened,payload)
    return hole_id in opened


def set_opened(obj,opened,payload=None):
    """Apply a complete choice set with just one mesh rebuild."""
    payload=payload or read(obj.data)
    if not payload or payload.get('version')!=3:
        raise ValueError('Nessuna chiusura modificabile registrata.')
    opened=set(opened);known={r['id']for r in payload['records']}
    if not opened<=known:raise ValueError('Chiusura non disponibile.')
    base=validate(obj,payload)
    if opened==set(obj.get(OPEN,[])):return False
    old=obj.data
    if opened:
        result=rebuilt_mesh(base,payload,opened)
        # Commit only after construction succeeds. Keep one closed reference,
        # independent of how many holes are currently open.
        obj[BASE]=base;obj.data=result;obj[WORK]=signature(result);obj[OPEN]=sorted(opened)
    else:
        obj.data=base
        for key in (BASE,WORK,OPEN):
            if key in obj:del obj[key]
    if old!=base and old.users==0:bpy.data.meshes.remove(old)
    obj.update_tag();return True
