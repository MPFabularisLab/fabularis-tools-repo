"""Small selection UI cache. No recognition or writes from panel draw."""
import bpy,math
from bpy.props import CollectionProperty,PointerProperty,IntProperty,BoolProperty
from . import hole_choices as choices,measurements,icons,hole_editor
LIMIT_KEY='fab_holes_limit_mm'
_rows_key=None
_range_cache={}
_last_range=None
_range_selection_key=None
_selected_max=None
_row_groups={}
_open_states={}
_filter_flags={}


def get_limit(scene):return float(scene.get(LIMIT_KEY,5.0))


def set_limit(scene,value):scene[LIMIT_KEY]=max(.001,float(value))


class FABHOLES_PG_closure_row(bpy.types.PropertyGroup):
    object:PointerProperty(type=bpy.types.Object)
    hole_id:IntProperty()
    opened:BoolProperty()
    is_group:BoolProperty()
    total:IntProperty()


class FABHOLES_UL_closures(bpy.types.UIList):
    def filter_items(self,context,data,propname):
        mode=context.scene.fab_holes_display_state
        key=(mode,self.bitflag_filter_item)
        if key not in _filter_flags:
            _filter_flags[key]=[self.bitflag_filter_item if row.is_group or(row.object and row.object.fab_holes_group_expanded and hole_editor.state_visible(row.opened,mode))else 0 for row in getattr(data,propname)]
        return _filter_flags[key],[]

    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
        obj=item.object
        if obj is None:return
        if item.is_group:
            row=layout.row(align=True)
            row.prop(obj,'fab_holes_group_expanded',text='',icon='TRIA_DOWN'if obj.fab_holes_group_expanded else'TRIA_RIGHT',emboss=False)
            row.label(text=f'{obj.name} · {item.total}',icon='FILE_FOLDER')
            row.prop(obj,'fab_holes_group_visible',text='',icon='HIDE_OFF'if obj.fab_holes_group_visible else'HIDE_ON',emboss=False)
            return
        row=layout.row(align=True);row.separator(factor=1)
        op=row.operator('fab_holes.toggle_one',text=f'Foro {item.hole_id}',depress=not item.opened,**icons.arguments(item.opened))
        op.object_name=obj.name;op.hole_id=item.hole_id


def selected_sources(context):
    return sorted((o for o in context.selected_objects if o.type=='MESH'and o.data.get(choices.HISTORY)),key=lambda o:o.name_full)


def sync_rows(context):
    global _rows_key
    sources=selected_sources(context)
    # A toggle swaps mesh data, but keeps the recorded history. Do not rebuild
    # thousands of collection rows just because one hole changed state.
    key=tuple((o.as_pointer(),o.name,str(o.data.get(choices.HISTORY)))for o in sources)
    wm=context.window_manager
    if key==_rows_key:
        changed=False
        for obj in sources:
            pointer=obj.as_pointer();opened=tuple(obj.get(choices.OPEN,[]))
            if _open_states.get(pointer)==opened:continue
            wanted=set(opened)
            for row in _row_groups.get(pointer,[]):
                state=row.hole_id in wanted
                if row.opened!=state:row.opened=state;changed=True
            _open_states[pointer]=opened
        if changed:_filter_flags.clear()
        return changed
    _filter_flags.clear()
    _rows_key=key
    index=wm.fab_holes_row_index
    previous=None
    if 0<=index<len(wm.fab_holes_rows):
        item=wm.fab_holes_rows[index];previous=(item.object,item.hole_id)
    wm.fab_holes_rows.clear();new_index=0;_row_groups.clear();_open_states.clear()
    for obj in sources:
        pointer=obj.as_pointer();opened=tuple(obj.get(choices.OPEN,[]));wanted=set(opened)
        group=_row_groups.setdefault(pointer,[]);_open_states[pointer]=opened
        records=choices.record_ids(obj.data)
        header=wm.fab_holes_rows.add();header.object=obj;header.is_group=True;header.total=len(records)
        for identity in records:
            row=wm.fab_holes_rows.add();row.object=obj;row.hole_id=identity;row.opened=identity in wanted;group.append(row)
            if (obj,identity)==previous:new_index=len(wm.fab_holes_rows)-1
    wm.fab_holes_row_index=new_index
    return True


def selected_maximum(context):
    """Use measured spans or saved closures only; never discover new holes."""
    maximum=0.0;known=set()
    for item in measurements.visible_items(context):
        known.add(item['object'])
        if 'span_maximum_mm'not in item:item['span_maximum_mm']=max((label['maximum_mm']for label in item['labels']),default=0.0)
        maximum=max(maximum,item['span_maximum_mm'])
    for obj in selected_sources(context):
        if obj in known:continue
        matrix=obj.matrix_world.copy();matrix.translation=(0,0,0)
        key=(str(obj.data.get(choices.HISTORY)),tuple(v for row in matrix for v in row),context.scene.unit_settings.scale_length)
        pointer=obj.as_pointer()
        if pointer not in _range_cache or _range_cache[pointer][0]!=key:
            payload=choices.read(obj.data)
            labels,_=measurements.summarize(payload,matrix,1000*context.scene.unit_settings.scale_length,details=False)if payload else([],[])
            _range_cache[pointer]=(key,max((label['maximum_mm']for label in labels),default=0.0))
        maximum=max(maximum,_range_cache[pointer][1])
    if not maximum:return None
    # Match the filter tolerance and expose a usable, displayed endpoint.
    factor=1000 if maximum>=.001 else 1e6
    rounded=round(maximum*factor)/factor
    tolerance=max(maximum*1e-6,1e-10*1000*context.scene.unit_settings.scale_length)
    return max(.001,rounded if rounded>0 and maximum<=rounded+tolerance else math.ceil(maximum*factor)/factor)


def sync_range(context):
    global _last_range,_range_selection_key,_selected_max
    scene=context.scene
    if LIMIT_KEY not in scene:set_limit(scene,scene.fab_holes_max_size_mm)
    selection_key=(context.scene.as_pointer(),context.scene.unit_settings.scale_length,measurements._survey_revision,
                   tuple(sorted((obj.as_pointer(),tuple(v for row in obj.matrix_world.to_3x3()for v in row))for obj in context.selected_objects if obj.type=='MESH')),
                   tuple((item['object'].as_pointer(),id(item))for item in measurements.visible_items(context)),
                   tuple((obj.as_pointer(),str(obj.data.get(choices.HISTORY)),tuple(v for row in obj.matrix_world.to_3x3()for v in row))for obj in selected_sources(context)))
    if selection_key!=_range_selection_key:
        _selected_max=selected_maximum(context);_range_selection_key=selection_key
        # Blender expands a soft slider range to accommodate an out-of-range
        # current value. On a new selection/survey bring that value within
        # the detected extent; manual numeric input on the same selection
        # remains unrestricted and does not get clamped on idle ticks.
        if _selected_max is not None and get_limit(scene)>_selected_max:
            set_limit(scene,_selected_max)
    maximum=_selected_max
    # With no valid survey, show the current value as slider extent. Typed
    # input remains possible across the full float range in every case.
    soft_max=maximum if maximum is not None else max(.001,get_limit(scene))
    key=(scene.as_pointer(),soft_max,get_limit(scene))
    changed=key!=_last_range
    if changed:
        scene.id_properties_ui(LIMIT_KEY).update(min=.001,max=3.402823e38,soft_min=.001,soft_max=soft_max,precision=3,default=5.0)
        _last_range=key
    return changed


def refresh_range(context):
    if context is None or not hasattr(context.scene,'fab_holes_max_size_mm'):return
    sync_range(context)
    measurements.request_redraw(context)


def tab_changed(self,context):
    if self.fab_holes_ui_tab=='CLOSE':refresh_range(context)



def tick():
    context=bpy.context
    if not context.scene or not context.window_manager:return .25
    # Avoid reentrancy during expensive operators and their explicit redraws.
    if measurements._busy:return .25
    try:
        rows_changed=sync_rows(context)if context.scene.fab_holes_ui_tab=='MANAGE'else measurements.sync_measure_rows(context)if context.scene.fab_holes_ui_tab=='MEASURE'else False
        range_changed=sync_range(context)if context.scene.fab_holes_ui_tab=='CLOSE'or context.scene.fab_holes_preview else False
        if rows_changed or range_changed:measurements.request_redraw(context)
    except (ReferenceError,RuntimeError):reset()
    return .25


@bpy.app.handlers.persistent
def reset(*args):
    global _rows_key,_last_range,_range_selection_key,_selected_max
    _rows_key=_last_range=_range_selection_key=_selected_max=None;_range_cache.clear();_row_groups.clear();_open_states.clear();_filter_flags.clear()


def group_changed(self,context):
    _filter_flags.clear()
    hole_editor.filter_changed(context.scene if context else None,context)



CLASSES=(FABHOLES_PG_closure_row,FABHOLES_UL_closures)


def install():
    bpy.types.Object.fab_holes_group_expanded=BoolProperty(default=True,update=group_changed)
    bpy.types.Object.fab_holes_group_visible=BoolProperty(default=True,update=group_changed,description='Mostra o nasconde i contorni dei fori di questo pezzo, senza nascondere la mesh')
    bpy.types.WindowManager.fab_holes_rows=CollectionProperty(type=FABHOLES_PG_closure_row,options={'SKIP_SAVE'})
    bpy.types.WindowManager.fab_holes_row_index=IntProperty(default=0,min=0,options={'SKIP_SAVE'})
    reset()
    for handlers in (bpy.app.handlers.load_post,bpy.app.handlers.undo_post,bpy.app.handlers.redo_post):
        if reset not in handlers:handlers.append(reset)
    if not bpy.app.background:bpy.app.timers.register(tick,first_interval=.1,persistent=True)


def uninstall():
    if bpy.app.timers.is_registered(tick):bpy.app.timers.unregister(tick)
    for handlers in (bpy.app.handlers.load_post,bpy.app.handlers.undo_post,bpy.app.handlers.redo_post):
        if reset in handlers:handlers.remove(reset)
    reset()
    del bpy.types.Object.fab_holes_group_expanded
    del bpy.types.Object.fab_holes_group_visible
    del bpy.types.WindowManager.fab_holes_rows
    del bpy.types.WindowManager.fab_holes_row_index
