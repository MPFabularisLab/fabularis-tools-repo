"""Small native sidebar status icons; loaded once, never on redraw."""
from pathlib import Path
import bpy

_previews=None


def install():
    global _previews
    if bpy.app.background:return
    from bpy.utils import previews
    _previews=previews.new()
    for name in ('closed','open'):
        _previews.load(name,str(Path(__file__).parent/'icons'/f'{name}.png'),'IMAGE')


def arguments(is_open):
    if _previews:return {'icon_value':_previews['open'if is_open else'closed'].icon_id}
    return {'icon':'RADIOBUT_OFF'if is_open else'RADIOBUT_ON'}


def uninstall():
    global _previews
    if _previews:
        from bpy.utils import previews
        previews.remove(_previews);_previews=None
