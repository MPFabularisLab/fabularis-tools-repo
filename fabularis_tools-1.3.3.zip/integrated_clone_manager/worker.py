"""Worker invoked by Blender --background. NEVER run inside the interactive MASTER."""
import bpy
import os
import sys
import json
import shutil
import traceback
import tempfile
import time


def main(jobpath):
    with open(jobpath, encoding='utf-8') as f:
        job = json.load(f)
    target = job['target']
    logpath = job.get('logpath', os.path.splitext(jobpath)[0] + '.log')
    success = False
    with open(logpath, 'w', encoding='utf-8', buffering=1) as log:
        def say(message):
            log.write(str(message) + '\n')
            print(message, flush=True)
        say('FABULARIS CLONE MANAGER 0.3.1 - conversione originale')
        say('Master: ' + job['master'])
        say('Target: ' + target)
        temp = None
        try:
            if os.path.normcase(os.path.abspath(bpy.data.filepath)) != os.path.normcase(os.path.abspath(job['master'])):
                raise RuntimeError('Il MASTER aperto non coincide con il job')
            scene = bpy.data.scenes.get(job.get('scene', ''))
            if scene is None:
                raise RuntimeError('Scena originale non trovata')
            # Imposta la scena di origine prima di utilizzare gli operatori.
            bpy.context.window.scene = scene
            layer = bpy.context.view_layer
            def unexclude(node):
                node.exclude = False
                for child in node.children:
                    unexclude(child)
            unexclude(layer.layer_collection)
            layer.update()
            sys.path.insert(0, os.path.dirname(__file__))
            from collection_to_empty import converti_collection_in_nulli
            if job.get('scope', 'COLLECTION') == 'SCENE':
                # Snapshot: la conversione elimina le Collection originali.
                roots = list(scene.collection.children)
                say('Conversione intera scena: ' + scene.name)
                say('Collection principali: ' + str(len(roots)))
                for idx, col in enumerate(roots, 1):
                    say(f'[{idx}/{len(roots)}] ' + col.name)
                    converti_collection_in_nulli(col, bpy.context)
                say('Oggetti direttamente nella radice mantenuti: ' + str(len(scene.collection.objects)))
            else:
                requested = [bpy.data.collections.get(n) for n in job.get('roots', [])]
                if any(c is None for c in requested) or not requested:
                    raise RuntimeError('Una o piu Collection selezionate non esistono')
                selected = set(requested)
                def ancestor_selected(col, parent):
                    for child in parent.children:
                        if child == col:
                            return False
                        if ancestor_selected(col, child):
                            return parent in selected or child in selected
                    return False
                # Remove descendants if an ancestor is already selected.
                def descendants(col):
                    result = set()
                    for child in col.children:
                        result.add(child)
                        result.update(descendants(child))
                    return result
                nested = set()
                for col in requested:
                    nested.update(descendants(col))
                roots = [col for col in requested if col not in nested]
                say('Collection selezionate: ' + str(len(roots)))
                for idx, col in enumerate(roots, 1):
                    say(f'[{idx}/{len(roots)}] ' + col.name)
                    converti_collection_in_nulli(col, bpy.context)
            say('Conversione completata')
            folder = os.path.dirname(target)
            fd, temp = tempfile.mkstemp(prefix='.fabclone_build_', suffix='.blend', dir=folder)
            os.close(fd)
            os.unlink(temp)
            bpy.ops.wm.save_as_mainfile(filepath=temp, check_existing=False, compress=False)
            if not os.path.exists(temp) or os.path.getsize(temp) == 0:
                raise RuntimeError('File temporaneo mancante o vuoto')
            if job['mode'] != 'OVERWRITE' and os.path.exists(target):
                raise RuntimeError('Destinazione gia esistente: non sovrascrivo')
            if os.path.exists(target) and job['backup']:
                stamp = time.strftime('%Y%m%d_%H%M%S')
                backup = target + '.' + stamp + '.bak'
                shutil.copy2(target, backup)
                say('Backup: ' + backup)
            os.replace(temp, target)
            temp = None
            say('SUCCESSO: ' + target)
            success = True
        except Exception:
            say('ERRORE: ' + traceback.format_exc())
        finally:
            if temp and os.path.exists(temp):
                os.unlink(temp)
            if job.get('statuspath'):
                with open(job['statuspath'], 'w', encoding='utf-8') as sf:
                    json.dump({'success': success, 'target': target, 'log': logpath}, sf)


if __name__ == '__main__':
    try:
        main(sys.argv[sys.argv.index('--') + 1])
    except Exception:
        traceback.print_exc()
