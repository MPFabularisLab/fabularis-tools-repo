bl_info = {
    'name': 'Project Clone',
    'author': 'Fabularis Lab',
    'version': (0, 3, 2),
    'blender': (4, 3, 0),
    'location': 'View3D > Sidebar > Fabularis Tools > Altro',
    'description': 'Create converted Blender clones in a separate Blender process',
    'category': 'Import-Export',
}

import bpy
import os
import sys
import subprocess
import json
import time
import tempfile
import shutil
from bpy.props import StringProperty, EnumProperty, PointerProperty, BoolProperty, CollectionProperty, IntProperty


def normalized(path):
    return os.path.normcase(os.path.abspath(bpy.path.abspath(path)))


def next_incremental(path):
    folder, filename = os.path.split(path)
    stem, ext = os.path.splitext(filename)
    import re
    stem = re.sub(r'_v\d{3,}$', '', stem)
    for i in range(1, 10000):
        candidate = os.path.join(folder, f'{stem}_v{i:03d}{ext}')
        if not os.path.exists(candidate):
            return candidate
    raise RuntimeError('Troppe versioni incrementali')


class FABULARIS_PG_clone_entry(bpy.types.PropertyGroup):
    collection: PointerProperty(type=bpy.types.Collection)


class FABULARIS_PG_clone_settings(bpy.types.PropertyGroup):
    filepath: StringProperty(name='File clone', subtype='FILE_PATH', default='//Unity_Clone.blend')
    scope: EnumProperty(name='Ambito', items=[('SCENE', 'Intera scena', 'Converte tutte le Collection della scena attiva, mantenendo gli oggetti nella radice'), ('SELECTED', 'Collection selezionate', 'Converte le Collection scelte nell Outliner')], default='SCENE')
    selected_collections: CollectionProperty(type=FABULARIS_PG_clone_entry)
    mode: EnumProperty(name='Modalita', items=[
        ('OVERWRITE', 'Sovrascrivi', 'Aggiorna il clone selezionato; le modifiche locali non sono preservate in v0.1'),
        ('NEW', 'Nuovo file', 'Non sovrascrive file esistenti'),
        ('INCREMENT', 'Incrementale', 'Crea un nuovo file numerato'),
    ], default='NEW')
    backup: BoolProperty(name='Backup prima di sovrascrivere', default=True)


class FABULARIS_OT_clone_add_selected(bpy.types.Operator):
    bl_idname = 'fabularis.clone_add_selected'
    bl_label = 'Aggiungi Collection al Clone'
    bl_description = 'Aggiunge le Collection selezionate nell Outliner alla lista di conversione'

    def execute(self, context):
        try:
            selected = list(context.selected_ids)
        except (AttributeError, TypeError):
            self.report({'ERROR'}, 'Esegui questo comando dall Outliner: seleziona le Collection, poi tasto destro')
            return {'CANCELLED'}
        settings = context.scene.fab_clone_settings
        existing = {item.collection.as_pointer() for item in settings.selected_collections if item.collection}
        count = 0
        for col in selected:
            if isinstance(col, bpy.types.Collection) and col.as_pointer() not in existing:
                entry = settings.selected_collections.add()
                entry.collection = col
                existing.add(col.as_pointer())
                count += 1
        settings.scope = 'SELECTED'
        self.report({'INFO'}, f'Aggiunte {count} Collection')
        return {'FINISHED'}


class FABULARIS_OT_clone_remove_entry(bpy.types.Operator):
    bl_idname = 'fabularis.clone_remove_entry'
    bl_label = 'Rimuovi Collection'
    index: IntProperty()

    def execute(self, context):
        items = context.scene.fab_clone_settings.selected_collections
        if 0 <= self.index < len(items):
            items.remove(self.index)
        return {'FINISHED'}


class FABULARIS_OT_clone_clear_entries(bpy.types.Operator):
    bl_idname = 'fabularis.clone_clear_entries'
    bl_label = 'Svuota lista Collection'

    def execute(self, context):
        context.scene.fab_clone_settings.selected_collections.clear()
        return {'FINISHED'}


def outliner_clone_menu(self, context):
    self.layout.separator()
    self.layout.operator('fabularis.clone_add_selected', icon='ADD')


class FABULARIS_OT_clone_browse(bpy.types.Operator):
    bl_idname = 'fabularis.clone_browse'
    bl_label = 'Scegli file clone'
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.blend', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath(context.scene.fab_clone_settings.filepath)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = os.path.abspath(self.filepath)
        if not path.lower().endswith('.blend'):
            path += '.blend'
        context.scene.fab_clone_settings.filepath = path
        return {'FINISHED'}


# Active subprocesses live only in this Blender session. No job files next to the clone.
_active_builds = []


def _poll_builds():
    for task in list(_active_builds):
        proc = task['process']
        if proc.poll() is None:
            continue
        _active_builds.remove(task)
        status = {}
        try:
            with open(task['status'], encoding='utf-8') as f:
                status = json.load(f)
        except (OSError, ValueError):
            pass
        success = bool(status.get('success')) and os.path.isfile(task['target'])
        message = ('Clone creato: ' if success else 'Clone non creato. Controlla il log: ') + (task['target'] if success else task['log'])
        try:
            def draw(self, context, msg=message):
                self.layout.label(text=msg[:180], icon='CHECKMARK' if success else 'ERROR')
            bpy.context.window_manager.popup_menu(draw, title='Fabularis Clone Manager', icon='INFO' if success else 'ERROR')
        except Exception:
            print('Fabularis Clone Manager: ' + message)
        shutil.rmtree(task['jobdir'], ignore_errors=True)
    return 0.7 if _active_builds else None


class FABULARIS_OT_clone_build(bpy.types.Operator):
    bl_idname = 'fabularis.clone_build'
    bl_label = 'Salva e crea clone'
    bl_description = 'Salva il MASTER e avvia subito il clone (senza finestra)'
    bl_options = {'REGISTER'}

    def execute(self, context):
        s = context.scene.fab_clone_settings
        master = bpy.data.filepath
        if not master:
            self.report({'ERROR'}, 'Salva prima il MASTER con Ctrl+Shift+S')
            return {'CANCELLED'}
        if s.scope == 'SELECTED' and not any(x.collection for x in s.selected_collections):
            self.report({'ERROR'}, 'Nessuna Collection scelta: aggiungila dall Outliner')
            return {'CANCELLED'}
        path = normalized(s.filepath)
        if not path.lower().endswith('.blend'):
            path += '.blend'
        # Prima risolvi il nome definitivo: Nuovo file e Incrementale
        # non devono essere bloccati dal confronto col file aperto.
        if s.mode == 'INCREMENT' or (s.mode == 'NEW' and os.path.exists(path)):
            path = next_incremental(path)
        # Impedisci solo di sovrascrivere il .blend attualmente aperto.
        if normalized(master) == normalized(path):
            self.report({'ERROR'}, 'La destinazione coincide con il file aperto. Scegli un altro nome o Nuovo file.')
            return {'CANCELLED'}
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            self.report({'ERROR'}, 'La cartella non esiste: scegli una cartella valida')
            return {'CANCELLED'}
        if _active_builds:
            self.report({'WARNING'}, 'Conversione precedente ancora in corso')
            return {'CANCELLED'}
        try:
            bpy.ops.wm.save_as_mainfile(filepath=master)
        except Exception as exc:
            self.report({'ERROR'}, f'Salvataggio MASTER fallito: {exc}')
            return {'CANCELLED'}
        script = os.path.join(os.path.dirname(__file__), 'worker.py')
        # Job and status are temporary, the only persistent diagnostic file is target.fabclone.log.
        jobdir = tempfile.mkdtemp(prefix='fabclone_')
        jobpath = os.path.join(jobdir, 'job.json')
        statuspath = os.path.join(jobdir, 'status.json')
        logpath = path + '.fabclone.log'
        job = {'master': master, 'target': path,
               'roots': [x.collection.name for x in s.selected_collections if x.collection],
               'scope': s.scope, 'scene': context.scene.name, 'mode': s.mode,
               'backup': bool(s.backup), 'logpath': logpath, 'statuspath': statuspath}
        try:
            with open(jobpath, 'w', encoding='utf-8') as f:
                json.dump(job, f, ensure_ascii=False)
            cmd = [bpy.app.binary_path, '--background', master, '--python', script, '--', jobpath]
            flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if sys.platform == 'win32' else 0
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                    creationflags=flags, close_fds=True)
            _active_builds.append({'process': proc, 'target': path, 'log': logpath,
                                   'jobdir': jobdir, 'status': statuspath})
            if not bpy.app.timers.is_registered(_poll_builds):
                bpy.app.timers.register(_poll_builds, first_interval=0.7)
            self.report({'INFO'}, 'Conversione avviata: ' + os.path.basename(path))
            return {'FINISHED'}
        except Exception as exc:
            shutil.rmtree(jobdir, ignore_errors=True)
            self.report({'ERROR'}, f'Impossibile avviare la build: {exc}')
            return {'CANCELLED'}


class FABULARIS_OT_clone_shortcut(bpy.types.Operator):
    bl_idname = 'fabularis.clone_shortcut'
    bl_label = 'Crea clone (Ctrl + Backslash)'
    bl_description = 'Scegli come salvare il clone'
    bl_options = {'REGISTER', 'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=390)

    def draw(self, context):
        s = context.scene.fab_clone_settings
        layout = self.layout
        layout.prop(s, 'filepath', text='Destinazione')
        layout.prop(s, 'mode', expand=True)
        if s.mode == 'OVERWRITE':
            layout.prop(s, 'backup')
            layout.label(text='Il clone esistente sara sostituito', icon='ERROR')
        elif s.mode == 'NEW':
            layout.label(text='Se il nome esiste, ne verra creato uno numerato', icon='INFO')

    def execute(self, context):
        return bpy.ops.fabularis.clone_build('EXEC_DEFAULT')


class FABULARIS_PT_clone_manager(bpy.types.Panel):
    bl_label = 'Project Clone'
    bl_idname = 'FABULARIS_PT_clone_manager'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Fabularis Tools'
    bl_parent_id = 'FABULARIS_SECTION_OTHER'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        from ..preferences import is_section_enabled
        return is_section_enabled(context, "show_clone_manager")


    def draw(self, context):
        layout = self.layout
        s = context.scene.fab_clone_settings
        layout.prop(s, 'scope', expand=True)
        if s.scope == 'SELECTED':
            layout.label(text='Outliner: seleziona, tasto destro, Aggiungi', icon='INFO')
            for i, entry in enumerate(s.selected_collections):
                row = layout.row(align=True)
                row.label(text=entry.collection.name if entry.collection else '(Collection eliminata)', icon='OUTLINER_COLLECTION')
                row.operator('fabularis.clone_remove_entry', text='', icon='X').index = i
            layout.operator('fabularis.clone_clear_entries', text='Svuota lista', icon='TRASH')
        else:
            layout.label(text='Converte tutte le Collection della scena', icon='OUTLINER_COLLECTION')
        layout.prop(s, 'filepath', text='Destinazione')
        layout.operator('fabularis.clone_browse', text='Sfoglia cartelle / file', icon='FILE_FOLDER')
        layout.prop(s, 'mode', expand=True)
        if s.mode == 'OVERWRITE':
            layout.prop(s, 'backup')
            layout.label(text='ATTENZIONE: rigenera il clone', icon='ERROR')
            layout.label(text='Le modifiche locali NON sono conservate')
        layout.separator()
        layout.operator('fabularis.clone_build', icon='DUPLICATE')
        layout.label(text='Ctrl + Backslash: salva e crea clone')
        layout.label(text='V0.3.2: correzione percorsi, conversione originale')


classes = (FABULARIS_PG_clone_entry, FABULARIS_PG_clone_settings, FABULARIS_OT_clone_add_selected, FABULARIS_OT_clone_remove_entry, FABULARIS_OT_clone_clear_entries, FABULARIS_OT_clone_browse,
           FABULARIS_OT_clone_build, FABULARIS_OT_clone_shortcut, FABULARIS_PT_clone_manager)
addon_keymaps = []


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fab_clone_settings = PointerProperty(type=FABULARIS_PG_clone_settings)
    bpy.types.OUTLINER_MT_collection.append(outliner_clone_menu)
    wm = bpy.context.window_manager
    if wm and wm.keyconfigs.addon:
        km = wm.keyconfigs.addon.keymaps.new(name='Window', space_type='EMPTY')
        try:
            kmi = km.keymap_items.new('fabularis.clone_shortcut', 'BACK_SLASH', 'PRESS', ctrl=True)
            addon_keymaps.append((km, kmi))
        except Exception:
            pass


def unregister():
    if bpy.app.timers.is_registered(_poll_builds):
        bpy.app.timers.unregister(_poll_builds)
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.OUTLINER_MT_collection.remove(outliner_clone_menu)
    del bpy.types.Scene.fab_clone_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
