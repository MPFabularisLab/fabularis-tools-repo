import bpy
import bmesh

import math



from bpy.app.handlers import persistent





# ============================================================

# FABULARIS TOOLS - MATERIAL GALLERY

# ============================================================



_MSGBUS_OWNER = object()

# V3 optimization state.
# Keeps the external behaviour unchanged while avoiding unnecessary work.
_MATERIAL_UI_IS_PINNED = False
_MATERIAL_CACHE = []
_MATERIAL_CACHE_SIGNATURE = None


def invalidate_material_cache():
    global _MATERIAL_CACHE_SIGNATURE
    _MATERIAL_CACHE_SIGNATURE = None


def get_sorted_materials_cached():
    """Return alphabetically sorted materials, sorting only when data changed."""
    global _MATERIAL_CACHE
    global _MATERIAL_CACHE_SIGNATURE

    # Building the signature is cheap compared with repeatedly sorting the list.
    signature = tuple(
        material.name
        for material in bpy.data.materials
    )

    if signature != _MATERIAL_CACHE_SIGNATURE:
        _MATERIAL_CACHE = sorted(
            bpy.data.materials,
            key=lambda material: material.name.lower()
        )
        _MATERIAL_CACHE_SIGNATURE = signature

    return _MATERIAL_CACHE






# ============================================================

# UTILITY

# ============================================================



def redraw_ui(context):
    if not context:
        return

    # Redraw the current area immediately when possible.
    current_area = getattr(
        context,
        "area",
        None
    )

    if current_area is not None:
        try:
            current_area.tag_redraw()
        except:
            pass

    wm = getattr(
        context,
        "window_manager",
        None
    )

    if not wm:
        return

    relevant_types = {
        'VIEW_3D',
        'PROPERTIES',
        'NODE_EDITOR',
    }

    for window in wm.windows:
        screen = window.screen

        if screen is None:
            continue

        for area in screen.areas:
            if area is current_area:
                continue

            if area.type not in relevant_types:
                continue

            try:
                area.tag_redraw()
            except:
                pass


def get_material_icon(material):

    try:

        return material.preview_ensure().icon_id

    except:

        return 0





def get_filtered_materials(context):

    search = (

        context.scene.material_gallery_search

        .strip()

        .lower()

    )



    materials = list(
        get_sorted_materials_cached()
    )



    if search:

        materials = [

            mat

            for mat in materials

            if search in mat.name.lower()

        ]



    return materials






def get_display_materials(context):
    """Materiali dopo ricerca + filtro rapido."""
    scene = context.scene
    materials = get_filtered_materials(context)
    mode = scene.material_gallery_filter_mode

    if mode == 'USED':
        return [m for m in materials if m.users > 0]

    if mode == 'UNUSED':
        return [m for m in materials if m.users == 0]

    if mode == 'ACTIVE_OBJECT':
        obj = context.object
        if obj is None or obj.type != 'MESH':
            return []
        names = {m.name for m in obj.data.materials if m}
        return [m for m in materials if m.name in names]

    if mode == 'FAVORITES':
        return [m for m in materials if m.get("fabularis_favorite", False)]

    return materials


def get_gallery_layout(context):

    size = context.scene.material_gallery_size



    region_width = max(

        180,

        context.region.width

    )



    card_width = 58 + size * 17



    columns = max(

        1,

        min(

            int(region_width / card_width),

            10

        )

    )



    if size >= 9:

        rows = 2



    elif size >= 7:

        rows = 3



    elif size >= 5:

        rows = 4



    elif size >= 3:

        rows = 5



    else:

        rows = 6



    per_page = max(

        1,

        columns * rows

    )



    return (

        columns,

        rows,

        per_page

    )





def get_gallery_item(

    scene,

    material_name

):

    for item in scene.material_gallery_list:



        if item.material_name == material_name:

            return item



    return None





def get_multi_selected_names(scene):

    return [

        item.material_name

        for item in scene.material_gallery_list

        if item.selected

    ]





def get_multi_selected_materials(scene):

    result = []



    for name in get_multi_selected_names(scene):



        material = bpy.data.materials.get(

            name

        )



        if material is not None:

            result.append(

                material

            )



    return result





# ============================================================

# APPLICA MATERIALE

# ============================================================



def apply_material(

    material,

    context

):

    """Object Mode Apply:
    replace only the active slot, then merge duplicate slots
    that point to the exact same material datablock.
    Other different materials are preserved.
    """

    modified = 0



    for obj in context.selected_objects:



        if obj.type != 'MESH':

            continue



        if len(obj.data.materials) == 0:



            obj.data.materials.append(

                material

            )



        else:



            slot = obj.active_material_index



            if slot >= len(obj.data.materials):

                slot = 0



            obj.data.materials[

                slot

            ] = material



        # Important:
        # do NOT remove other different materials.
        # Only collapse duplicate slots that now reference
        # the exact same material datablock.
        merge_duplicate_material_slots_object(

            obj

        )



        modified += 1



    return modified





# ============================================================

# APRI MATERIALE

# ============================================================



def focus_material_in_blender(

    context,

    material

):

    global _MATERIAL_UI_IS_PINNED

    if material is None:
        return False

    found = False



    for window in context.window_manager.windows:



        screen = window.screen



        if screen is None:

            continue



        for area in screen.areas:



            # =================================================

            # MATERIAL PROPERTIES

            # =================================================



            if area.type == 'PROPERTIES':



                try:

                    space = area.spaces.active



                    space.pin_id = material

                    space.use_pin_id = True

                    space.context = 'MATERIAL'



                    found = True



                except Exception as error:



                    print(

                        "Fabularis Material Gallery - Properties:",

                        error

                    )



            # =================================================

            # SHADER EDITOR

            # =================================================



            elif area.type == 'NODE_EDITOR':



                try:

                    space = area.spaces.active



                    if (

                        space.tree_type == 'ShaderNodeTree'

                        and

                        material.use_nodes

                        and

                        material.node_tree is not None

                    ):



                        space.shader_type = 'OBJECT'



                        space.pin = False

                        space.node_tree = material.node_tree

                        space.pin = True



                        found = True



                except Exception as error:



                    print(

                        "Fabularis Material Gallery - Shader:",

                        error

                    )



            try:

                area.tag_redraw()

            except:

                pass



    if found:
        _MATERIAL_UI_IS_PINNED = True

    return found





# ============================================================

# RIPRISTINA PROPERTIES

# ============================================================



def restore_normal_properties():

    global _MATERIAL_UI_IS_PINNED

    # Most object selections never use Material Gallery.
    # In that normal case there is nothing to restore.
    if not _MATERIAL_UI_IS_PINNED:
        return

    wm = bpy.context.window_manager



    if wm is None:

        return



    for window in wm.windows:



        screen = window.screen



        if screen is None:

            continue



        for area in screen.areas:



            # =================================================

            # PROPERTIES

            # =================================================



            if area.type == 'PROPERTIES':



                try:

                    space = area.spaces.active



                    space.use_pin_id = False



                    try:

                        space.pin_id = None

                    except:

                        pass



                    try:

                        space.context = 'OBJECT'

                    except:

                        pass



                    area.tag_redraw()



                except Exception as error:



                    print(

                        "Fabularis Material Gallery - "

                        "Restore Properties:",

                        error

                    )



            # =================================================

            # SHADER EDITOR

            # =================================================



            elif area.type == 'NODE_EDITOR':



                try:

                    space = area.spaces.active



                    if (

                        space.tree_type

                        ==

                        'ShaderNodeTree'

                    ):



                        space.pin = False

                        space.shader_type = 'OBJECT'



                        area.tag_redraw()



                except Exception as error:



                    print(

                        "Fabularis Material Gallery - "

                        "Restore Shader:",

                        error

                    )



    try:

        bpy.context.view_layer.update()



    except:

        pass



    _MATERIAL_UI_IS_PINNED = False

    redraw_ui(
        bpy.context
    )





# ============================================================

# CAMBIO OGGETTO ATTIVO

# ============================================================




def select_faces_using_pending_material():
    """One-shot face selection after 'Select objects using material'."""
    context = bpy.context
    scene = getattr(
        context,
        "scene",
        None
    )

    if scene is None:
        return False

    material_name = getattr(
        scene,
        "material_gallery_face_select_material",
        ""
    )

    # Fast exit during normal Blender usage.
    if not material_name:
        return False

    if context.mode != 'EDIT_MESH':
        return False

    material = bpy.data.materials.get(
        material_name
    )

    if material is None:
        scene.material_gallery_face_select_material = ""
        return False

    objects_in_mode = getattr(
        context,
        "objects_in_mode_unique_data",
        None
    )

    if not objects_in_mode:
        obj = context.object
        objects_in_mode = (
            [obj]
            if obj is not None
            else []
        )

    selected_faces = 0
    changed_anything = False

    for obj in objects_in_mode:
        if obj is None or obj.type != 'MESH':
            continue

        slot_indices = {
            index
            for index, current in enumerate(
                obj.data.materials
            )
            if current == material
        }

        if not slot_indices:
            continue

        try:
            bm = bmesh.from_edit_mesh(
                obj.data
            )

            object_changed = False

            for face in bm.faces:
                wanted = (
                    face.material_index
                    in slot_indices
                )

                if face.select != wanted:
                    face.select = wanted
                    object_changed = True

                if wanted:
                    selected_faces += 1

            if object_changed:
                bmesh.update_edit_mesh(
                    obj.data,
                    loop_triangles=False,
                    destructive=False
                )
                changed_anything = True

        except Exception as error:
            print(
                "Fabularis Material Gallery - face select:",
                obj.name,
                error
            )

    # One-shot workflow: once Edit Mode was reached, stop monitoring it.
    scene.material_gallery_face_select_material = ""

    if changed_anything:
        redraw_ui(
            context
        )

    return selected_faces > 0


def object_mode_changed():
    """Very cheap msgbus callback; does work only for a pending face lookup."""
    try:
        scene = getattr(
            bpy.context,
            "scene",
            None
        )

        if scene is None:
            return

        if not getattr(
            scene,
            "material_gallery_face_select_material",
            ""
        ):
            return

        if bpy.context.mode != 'EDIT_MESH':
            return

        select_faces_using_pending_material()

    except Exception as error:
        print(
            "Fabularis Material Gallery - mode change:",
            error
        )


def active_object_changed():

    if not _MATERIAL_UI_IS_PINNED:
        return

    restore_normal_properties()





# ============================================================

# MSGBUS

# ============================================================



def register_msgbus():



    try:

        bpy.msgbus.clear_by_owner(

            _MSGBUS_OWNER

        )

    except:

        pass



    bpy.msgbus.subscribe_rna(

        key=(

            bpy.types.LayerObjects,

            "active"

        ),

        owner=_MSGBUS_OWNER,

        args=(),

        notify=active_object_changed,

        options={'PERSISTENT'}

    )


    bpy.msgbus.subscribe_rna(
        key=(
            bpy.types.Object,
            "mode"
        ),
        owner=_MSGBUS_OWNER,
        args=(),
        notify=object_mode_changed,
        options={'PERSISTENT'}
    )





def unregister_msgbus():



    try:

        bpy.msgbus.clear_by_owner(

            _MSGBUS_OWNER

        )

    except:

        pass





# ============================================================

# RIATTIVA MSGBUS DOPO APERTURA .BLEND

# ============================================================



@persistent

def material_gallery_load_post(dummy):

    global _MATERIAL_UI_IS_PINNED

    _MATERIAL_UI_IS_PINNED = False

    try:
        bpy.context.scene.material_gallery_face_select_material = ""
    except:
        pass

    invalidate_material_cache()
    register_msgbus()





# ============================================================

# CALLBACK

# ============================================================



def gallery_updated(

    self,

    context

):

    if not context:

        return



    context.scene.material_gallery_page = 0



    refresh_material_list(

        context

    )



    redraw_ui(

        context

    )





# ============================================================

# LIST ITEM

# ============================================================



class MATERIALGALLERY_PG_list_item(

    bpy.types.PropertyGroup

):



    material_name: bpy.props.StringProperty()



    selected: bpy.props.BoolProperty(

        name="Selezionato",

        default=False

    )





# ============================================================

# REFRESH LISTA

# ============================================================



def refresh_material_list(context):

    if not context:

        return



    scene = context.scene



    materials = get_filtered_materials(

        context

    )



    selected_names = {

        item.material_name

        for item in scene.material_gallery_list

        if item.selected

    }



    current_names = [

        item.material_name

        for item in scene.material_gallery_list

    ]



    new_names = [

        material.name

        for material in materials

    ]



    if current_names == new_names:

        return



    scene.material_gallery_list.clear()



    for material in materials:



        item = scene.material_gallery_list.add()



        item.material_name = material.name



        item.selected = (

            material.name

            in

            selected_names

        )



    if (

        scene.material_gallery_list_index

        >=

        len(scene.material_gallery_list)

    ):



        scene.material_gallery_list_index = max(

            0,

            len(scene.material_gallery_list) - 1

        )





# ============================================================

# UI LIST MATERIALI

# ============================================================



class MATERIALGALLERY_UL_materials(

    bpy.types.UIList

):



    def draw_item(

        self,

        context,

        layout,

        data,

        item,

        icon,

        active_data,

        active_propname,

        index

    ):



        material = bpy.data.materials.get(

            item.material_name

        )



        if material is None:

            return



        row = layout.row(

            align=True

        )

        op = row.operator(

            "material_gallery.select_material",

            text=material.name,

            icon_value=get_material_icon(

                material

            )

        )



        op.material_name = material.name




        favorite = row.operator(
            "material_gallery.toggle_favorite",
            text="",
            icon=('SOLO_ON' if material.get("fabularis_favorite", False) else 'SOLO_OFF'),
            emboss=False
        )
        favorite.material_name = material.name

        apply_button = row.operator(
            "material_gallery.apply_material",
            text="",
            icon='CHECKMARK'
        )
        apply_button.material_name = material.name

        actions = row.operator(

            "material_gallery.material_actions",

            text="",

            icon='DOWNARROW_HLT'

        )



        actions.material_name = (

            material.name

        )





# ============================================================

# UI LIST REMAP

# ============================================================




class MATERIALGALLERY_UL_remap_sources(bpy.types.UIList):

    def filter_items(self, context, data, propname):
        collection = getattr(data, propname)

        search = (
            context.scene.material_remap_source_search
            .strip()
            .lower()
        )

        if not search:
            return (
                [self.bitflag_filter_item for _ in collection],
                []
            )

        flags = [
            self.bitflag_filter_item
            if search in item.material_name.lower()
            else 0
            for item in collection
        ]

        return (
            flags,
            []
        )

    def draw_item(
        self,
        context,
        layout,
        data,
        item,
        icon,
        active_data,
        active_propname,
        index
    ):
        material = bpy.data.materials.get(
            item.material_name
        )

        if material is None:
            return

        row = layout.row(
            align=True
        )

        # Selected source materials are visually marked in red.
        row.alert = bool(item.selected)

        row.prop(
            item,
            "selected",
            text=""
        )

        row.label(
            text=material.name,
            icon_value=get_material_icon(material)
        )

        row.label(
            text=f"Users: {material.users}"
        )


class MATERIALGALLERY_UL_remap_materials(

    bpy.types.UIList

):



    def filter_items(

        self,

        context,

        data,

        propname

    ):



        collection = getattr(

            data,

            propname

        )



        search = (

            context.scene.material_remap_search

            .strip()

            .lower()

        )



        if not search:



            return (

                [

                    self.bitflag_filter_item

                    for _ in collection

                ],

                []

            )



        flags = [

            self.bitflag_filter_item

            if search in item.material_name.lower()

            else 0

            for item in collection

        ]



        return (

            flags,

            []

        )





    def draw_item(

        self,

        context,

        layout,

        data,

        item,

        icon,

        active_data,

        active_propname,

        index

    ):



        material = bpy.data.materials.get(

            item.material_name

        )



        if material is None:

            return



        row = layout.row(

            align=True

        )



        row.label(

            text=material.name,

            icon_value=get_material_icon(

                material

            )

        )



        row.label(

            text=f"Users: {material.users}"

        )





# ============================================================

# APRI MATERIALE

# ============================================================



# ============================================================
# CREA MATERIALE
# ============================================================

class MATERIALGALLERY_OT_create_material(
    bpy.types.Operator
):
    bl_idname = "material_gallery.create_material"
    bl_label = "Crea Materiale"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: bpy.props.StringProperty(
        name="Nome materiale",
        default="Material"
    )

    def invoke(self, context, event):
        self.material_name = "Material"
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        self.layout.prop(self, "material_name", text="Nome")

    def execute(self, context):
        name = self.material_name.strip()
        if not name:
            self.report({'ERROR'}, "Il nome non può essere vuoto")
            return {'CANCELLED'}

        material = bpy.data.materials.new(name=name)
        material.use_nodes = True
        invalidate_material_cache()

        context.scene.material_gallery_selected = material.name
        context.scene.material_gallery_page = 0

        refresh_material_list(context)
        focus_material_in_blender(context, material)
        redraw_ui(context)
        return {'FINISHED'}


class MATERIALGALLERY_OT_select_material(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.select_material"

    )



    bl_label = (

        "Apri Materiale"

    )



    material_name: bpy.props.StringProperty()





    def execute(

        self,

        context

    ):



        material = bpy.data.materials.get(

            self.material_name

        )



        if material is None:

            return {'CANCELLED'}



        context.scene.material_gallery_selected = (

            material.name

        )



        focus_material_in_blender(

            context,

            material

        )



        redraw_ui(

            context

        )



        return {'FINISHED'}





# ============================================================

# MENU AZIONI

# ============================================================



class MATERIALGALLERY_OT_toggle_fake_user(
    bpy.types.Operator
):

    bl_idname = "material_gallery.toggle_fake_user"
    bl_label = "Toggle Fake User"
    bl_description = (
        "Protegge o rilascia il materiale tramite il Fake User di Blender"
    )
    bl_options = {'REGISTER', 'UNDO'}

    material_name: bpy.props.StringProperty()

    def execute(self, context):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            self.report(
                {'ERROR'},
                "Materiale non disponibile"
            )
            return {'CANCELLED'}

        material.use_fake_user = (
            not material.use_fake_user
        )

        redraw_ui(context)

        self.report(
            {'INFO'},
            (
                f"Fake User {'attivato' if material.use_fake_user else 'disattivato'}: "
                f"{material.name}"
            )
        )

        return {'FINISHED'}





class MATERIALGALLERY_OT_material_actions(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.material_actions"
    )

    bl_label = (
        "Azioni Materiale"
    )

    material_name: bpy.props.StringProperty()

    def invoke(
        self,
        context,
        event
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        material_name = self.material_name

        def draw_menu(
            menu,
            popup_context
        ):

            layout = menu.layout

            # Important: slot actions such as "Applica allo slot" have an
            # invoke() step that may open a confirmation popup. Force Blender
            # to use invoke instead of calling execute() directly.
            layout.operator_context = 'INVOKE_DEFAULT'

            material = bpy.data.materials.get(
                material_name
            )

            if material is None:
                layout.label(
                    text="Materiale non disponibile"
                )
                return

            layout.label(
                text=material.name,
                icon_value=get_material_icon(
                    material
                )
            )

            layout.label(
                text=f"Users: {material.users}"
            )

            layout.separator()

            # ----------------------------------------------
            # SLOT
            # ----------------------------------------------
            slot_header = layout.row()
            slot_header.enabled = False
            slot_header.label(
                text="SLOT MATERIALE",
                icon='MATERIAL'
            )

            add_slot = layout.operator(
                "material_gallery.add_material_slot",
                text="Aggiungi nuovo slot",
                icon='ADD'
            )
            add_slot.material_name = material_name

            active = popup_context.object

            if (
                active
                and active.type == 'MESH'
                and len(active.data.materials) > 0
            ):
                layout.separator()
                layout.label(
                    text="Applica allo slot:"
                )

                for index, current in enumerate(
                    active.data.materials[:12]
                ):
                    label = (
                        current.name
                        if current
                        else "Vuoto"
                    )

                    slot_op = layout.operator(
                        "material_gallery.apply_to_slot",
                        text=f"Slot {index + 1}: {label}"
                    )
                    slot_op.material_name = material_name
                    slot_op.slot_index = index

            layout.separator()

            # ----------------------------------------------
            # MATERIAL MANAGEMENT
            # ----------------------------------------------
            management_header = layout.row()
            management_header.enabled = False
            management_header.label(
                text="GESTIONE MATERIALE",
                icon='SETTINGS'
            )

            fake_user = layout.operator(
                "material_gallery.toggle_fake_user",
                text=(
                    "Fake User: ATTIVO"
                    if material.use_fake_user
                    else "Fake User: disattivo"
                ),
                icon=(
                    'FAKE_USER_ON'
                    if material.use_fake_user
                    else 'FAKE_USER_OFF'
                )
            )
            fake_user.material_name = material_name

            rename = layout.operator(
                "material_gallery.rename_material",
                text="Rinomina materiale...",
                icon='SORTALPHA'
            )
            rename.material_name = material_name

            duplicate = layout.operator(
                "material_gallery.duplicate_material",
                text="Duplica materiale",
                icon='DUPLICATE'
            )
            duplicate.material_name = material_name

            select_users = layout.operator(
                "material_gallery.select_objects_using_material",
                text="Seleziona oggetti che lo usano",
                icon='RESTRICT_SELECT_OFF'
            )
            select_users.material_name = material_name

            layout.separator()

            delete = layout.operator(
                "material_gallery.delete_material",
                text="Elimina materiale...",
                icon='TRASH'
            )
            delete.material_name = material_name

        context.window_manager.popup_menu(
            draw_menu,
            title="Materiale",
            icon='MATERIAL'
        )

        return {'FINISHED'}





class MATERIALGALLERY_OT_rename_material(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.rename_material"

    )



    bl_label = (

        "Rinomina Materiale"

    )



    bl_options = {

        'REGISTER',

        'UNDO'

    }



    material_name: bpy.props.StringProperty()



    new_name: bpy.props.StringProperty(

        name="Nuovo nome",

        default=""

    )





    def invoke(

        self,

        context,

        event

    ):



        material = bpy.data.materials.get(

            self.material_name

        )



        if material is None:

            return {'CANCELLED'}



        self.new_name = (

            material.name

        )



        return (

            context.window_manager

            .invoke_props_dialog(

                self,

                width=420

            )

        )





    def draw(

        self,

        context

    ):



        material = bpy.data.materials.get(

            self.material_name

        )



        if material:



            box = self.layout.box()



            row = box.row()



            icon_id = get_material_icon(

                material

            )



            if icon_id:



                row.template_icon(

                    icon_value=icon_id,

                    scale=3

                )



            column = row.column()



            column.label(

                text="Materiale da rinominare:"

            )



            column.label(

                text=material.name,

                icon='MATERIAL'

            )



            column.label(

                text=f"Users: {material.users}"

            )



        self.layout.separator()



        self.layout.prop(

            self,

            "new_name",

            text="Nuovo nome"

        )





    def execute(

        self,

        context

    ):



        material = bpy.data.materials.get(

            self.material_name

        )



        if material is None:

            return {'CANCELLED'}



        new_name = (

            self.new_name.strip()

        )



        if not new_name:



            self.report(

                {'ERROR'},

                "Il nome non può essere vuoto"

            )



            return {'CANCELLED'}



        old_name = (

            material.name

        )



        was_selected = (

            context.scene.material_gallery_selected

            ==

            old_name

        )



        material.name = (

            new_name

        )

        invalidate_material_cache()



        new_name = (

            material.name

        )



        for item in (

            context.scene.material_gallery_list

        ):



            if item.material_name == old_name:



                item.material_name = (

                    new_name

                )



        for item in (

            context.scene.material_remap_list

        ):



            if item.material_name == old_name:



                item.material_name = (

                    new_name

                )



        if was_selected:



            context.scene.material_gallery_selected = (

                new_name

            )



        redraw_ui(

            context

        )



        return {'FINISHED'}





# ============================================================

# ELIMINA

# ============================================================



class MATERIALGALLERY_OT_delete_material(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.delete_material"

    )



    bl_label = (

        "Elimina Materiale"

    )



    bl_options = {

        'REGISTER',

        'UNDO'

    }



    material_name: bpy.props.StringProperty()





    def invoke(

        self,

        context,

        event

    ):



        if not bpy.data.materials.get(

            self.material_name

        ):

            return {'CANCELLED'}



        return (

            context.window_manager

            .invoke_props_dialog(

                self,

                width=440

            )

        )





    def draw(

        self,

        context

    ):



        material = bpy.data.materials.get(

            self.material_name

        )



        if material is None:

            return



        box = self.layout.box()



        box.alert = True



        box.label(

            text="ELIMINA MATERIALE",

            icon='ERROR'

        )



        box.separator()



        row = box.row()



        icon_id = get_material_icon(

            material

        )



        if icon_id:



            row.template_icon(

                icon_value=icon_id,

                scale=3

            )



        column = row.column()



        column.alert = True



        column.label(

            text=material.name,

            icon='MATERIAL'

        )



        column.label(

            text=f"Users: {material.users}"

        )



        self.layout.separator()



        warning = self.layout.row()



        warning.alert = True



        warning.label(

            text=(

                "Il materiale verrà rimosso anche "

                "dagli oggetti che lo utilizzano."

            ),

            icon='ERROR'

        )





    def execute(

        self,

        context

    ):



        material = bpy.data.materials.get(

            self.material_name

        )



        if material is None:

            return {'CANCELLED'}



        if (

            context.scene.material_gallery_selected

            ==

            material.name

        ):



            context.scene.material_gallery_selected = ""



        bpy.data.materials.remove(

            material,

            do_unlink=True

        )

        invalidate_material_cache()



        refresh_material_list(

            context

        )



        redraw_ui(

            context

        )



        return {'FINISHED'}





# ============================================================

# MULTI SELECT

# ============================================================



class MATERIALGALLERY_OT_select_visible(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.select_visible"

    )



    bl_label = (

        "Seleziona / Deseleziona"

    )



    select_state: bpy.props.BoolProperty(

        default=True

    )



    page: bpy.props.IntProperty(

        default=0

    )



    per_page: bpy.props.IntProperty(

        default=1,

        min=1

    )





    def execute(

        self,

        context

    ):



        scene = context.scene



        refresh_material_list(

            context

        )



        if (

            scene.material_gallery_mode

            ==

            'GALLERY'

        ):



            materials = get_display_materials(

                context

            )



            start = (

                self.page

                *

                self.per_page

            )



            end = (

                start

                +

                self.per_page

            )



            names = {

                material.name

                for material

                in materials[start:end]

            }



        else:



            names = {

                item.material_name

                for item

                in scene.material_gallery_list

            }



        for item in scene.material_gallery_list:



            if item.material_name in names:



                item.selected = (

                    self.select_state

                )



        redraw_ui(

            context

        )



        return {'FINISHED'}





class MATERIALGALLERY_OT_clear_multi(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.clear_multi"

    )



    bl_label = (

        "Deseleziona tutto"

    )





    def execute(

        self,

        context

    ):



        for item in (

            context.scene.material_gallery_list

        ):



            item.selected = False



        redraw_ui(

            context

        )



        return {'FINISHED'}





# ============================================================

# APPLY

# ============================================================





class MATERIALGALLERY_OT_select_all_multi(bpy.types.Operator):
    bl_idname = "material_gallery.select_all_multi"
    bl_label = "Seleziona tutto"
    bl_description = "Seleziona tutti i materiali della Material Gallery"

    def execute(self, context):
        refresh_material_list(context)

        for item in context.scene.material_gallery_list:
            item.selected = True

        redraw_ui(context)
        return {'FINISHED'}


class MATERIALGALLERY_OT_multi_selection_tools(bpy.types.Operator):
    bl_idname = "material_gallery.multi_selection_tools"
    bl_label = "Filtra selezione"
    bl_description = "Seleziona o deseleziona materiali in base al nome"

    action: bpy.props.EnumProperty(
        name="Azione",
        items=[
            ('SELECT', "Seleziona", "Seleziona i materiali trovati"),
            ('DESELECT', "Deseleziona", "Deseleziona i materiali trovati"),
        ],
        default='DESELECT'
    )

    search: bpy.props.StringProperty(
        name="Nome",
        description="Trova tutti i materiali il cui nome contiene questo testo",
        default=""
    )

    def invoke(self, context, event):
        self.search = ""
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "action", expand=True)
        layout.prop(self, "search", text="Cerca", icon='VIEWZOOM')

        query = self.search.strip().lower()
        if query:
            matches = sum(
                1 for item in context.scene.material_gallery_list
                if query in item.material_name.lower()
            )
            layout.label(text=f"{matches} materiali trovati")
        else:
            layout.label(text="Scrivi una parte del nome", icon='INFO')

    def execute(self, context):
        query = self.search.strip().lower()
        if not query:
            self.report({'WARNING'}, "Inserisci un nome da cercare")
            return {'CANCELLED'}

        refresh_material_list(context)
        select_state = self.action == 'SELECT'
        matched = 0

        for item in context.scene.material_gallery_list:
            if query in item.material_name.lower():
                item.selected = select_state
                matched += 1

        redraw_ui(context)
        verb = "selezionati" if select_state else "deselezionati"
        self.report({'INFO'}, f"{matched} materiali {verb}")
        return {'FINISHED'}


class MATERIALGALLERY_OT_multi_selection_menu(bpy.types.Operator):
    bl_idname = "material_gallery.multi_selection_menu"
    bl_label = "Opzioni selezione"
    bl_description = "Altre opzioni per la selezione multipla"

    def invoke(self, context, event):
        context.window_manager.popup_menu(
            self.draw_menu,
            title="Selezione multipla",
            icon='CHECKBOX_HLT'
        )
        return {'FINISHED'}

    def execute(self, context):
        return {'FINISHED'}

    @staticmethod
    def draw_menu(menu, context):
        layout = menu.layout
        scene = context.scene

        # Important: operators that open dialogs must be invoked,
        # otherwise Blender executes them immediately.
        layout.operator_context = 'INVOKE_DEFAULT'

        # ----------------------------------------------------
        # PAGE / CURRENT VIEW
        # ----------------------------------------------------
        if scene.material_gallery_mode == 'GALLERY':
            _, _, per_page = get_gallery_layout(context)

            materials = get_display_materials(context)
            total_pages = max(
                1,
                math.ceil(len(materials) / per_page)
            )

            current_page = min(
                scene.material_gallery_page,
                total_pages - 1
            )

            op = layout.operator(
                "material_gallery.select_visible",
                text="Seleziona pagina",
                icon='CHECKBOX_HLT'
            )
            op.select_state = True
            op.page = current_page
            op.per_page = per_page

            op = layout.operator(
                "material_gallery.select_visible",
                text="Deseleziona pagina",
                icon='CHECKBOX_DEHLT'
            )
            op.select_state = False
            op.page = current_page
            op.per_page = per_page

        else:
            op = layout.operator(
                "material_gallery.select_visible",
                text="Seleziona lista",
                icon='CHECKBOX_HLT'
            )
            op.select_state = True
            op.page = 0
            op.per_page = max(
                1,
                len(scene.material_gallery_list)
            )

            op = layout.operator(
                "material_gallery.select_visible",
                text="Deseleziona lista",
                icon='CHECKBOX_DEHLT'
            )
            op.select_state = False
            op.page = 0
            op.per_page = max(
                1,
                len(scene.material_gallery_list)
            )

        layout.separator()

        # ----------------------------------------------------
        # ALL
        # ----------------------------------------------------
        layout.operator(
            "material_gallery.select_all_multi",
            text="Seleziona tutto",
            icon='CHECKMARK'
        )

        layout.operator(
            "material_gallery.clear_multi",
            text="Deseleziona tutto",
            icon='X'
        )

        layout.separator()

        # ----------------------------------------------------
        # BY NAME
        # ----------------------------------------------------
        op = layout.operator(
            "material_gallery.multi_selection_tools",
            text="Seleziona per nome...",
            icon='ADD'
        )
        op.action = 'SELECT'

        op = layout.operator(
            "material_gallery.multi_selection_tools",
            text="Deseleziona per nome...",
            icon='REMOVE'
        )
        op.action = 'DESELECT'


class MATERIALGALLERY_OT_apply_material(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.apply_material"
    )

    bl_label = (
        "Applica Materiale"
    )

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    material_name: bpy.props.StringProperty()

    cleanup_duplicate_slots: bpy.props.BoolProperty(
        name="Rimuovi slot duplicati",
        description=(
            "Se dopo l'Apply più slot puntano allo stesso identico materiale, "
            "mantiene un solo slot e preserva le assegnazioni delle facce"
        ),
        default=True
    )

    show_cleanup_warning: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'}
    )

    def _object_mode_will_create_duplicates(
        self,
        context,
        material
    ):
        """Predict whether replacing the active slot would create
        duplicate slots pointing to the same target material.
        """
        for obj in context.selected_objects:

            if obj.type != 'MESH':
                continue

            materials = obj.data.materials

            if len(materials) == 0:
                continue

            slot = obj.active_material_index

            if slot >= len(materials):
                slot = 0

            # If the active slot already contains the material,
            # duplicates matter only if another slot also contains it.
            for index, current in enumerate(materials):
                if index == slot:
                    continue

                if current == material:
                    return True

        return False

    def invoke(
        self,
        context,
        event
    ):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        # In Edit Mode keep the current direct Smart Apply behaviour.
        if context.mode == 'EDIT_MESH':
            return self.execute(
                context
            )

        # In Object Mode ask only when duplicate same-material
        # slots would actually be produced.
        if self._object_mode_will_create_duplicates(
            context,
            material
        ):
            self.show_cleanup_warning = True

            return context.window_manager.invoke_props_dialog(
                self,
                width=430
            )

        self.show_cleanup_warning = False

        return self.execute(
            context
        )

    def draw(
        self,
        context
    ):
        layout = self.layout

        if self.show_cleanup_warning:

            box = layout.box()

            box.label(
                text="Sono presenti slot con lo stesso materiale.",
                icon='INFO'
            )

            box.label(
                text="Vuoi unificarli dopo l'Apply?"
            )

            box.prop(
                self,
                "cleanup_duplicate_slots",
                text="Rimuovi slot duplicati"
            )

    def execute(
        self,
        context
    ):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        # ----------------------------------------------------
        # EDIT MODE:
        # Apply to selected faces on ALL meshes currently in
        # multi-object Edit Mode, then clean unused/duplicate slots.
        # ----------------------------------------------------
        if context.mode == 'EDIT_MESH':

            objects_in_mode = getattr(
                context,
                "objects_in_mode_unique_data",
                None
            )

            if not objects_in_mode:
                obj = context.object
                objects_in_mode = (
                    [obj]
                    if obj is not None
                    else []
                )

            total_selected_faces = 0
            total_removed_slots = 0
            modified_objects = 0

            for obj in objects_in_mode:
                if obj is None or obj.type != 'MESH':
                    continue

                mesh = obj.data

                try:
                    bm = bmesh.from_edit_mesh(
                        mesh
                    )
                except:
                    continue

                selected_faces = [
                    face
                    for face in bm.faces
                    if face.select
                ]

                if not selected_faces:
                    continue

                total_selected_faces += len(
                    selected_faces
                )

                slot_index = None

                for index, current in enumerate(
                    mesh.materials
                ):
                    if current == material:
                        slot_index = index
                        break

                if slot_index is None:
                    mesh.materials.append(
                        material
                    )
                    slot_index = (
                        len(mesh.materials) - 1
                    )

                for face in selected_faces:
                    face.material_index = (
                        slot_index
                    )

                # Keep Edit Mode cleanup automatic as before.
                material_to_first_slot = {}
                duplicate_slot_map = {}

                for index, current_material in enumerate(
                    mesh.materials
                ):
                    if current_material is None:
                        continue

                    key = current_material.as_pointer()

                    if key not in material_to_first_slot:
                        material_to_first_slot[key] = index
                    else:
                        duplicate_slot_map[index] = (
                            material_to_first_slot[key]
                        )

                for face in bm.faces:
                    if face.material_index in duplicate_slot_map:
                        face.material_index = (
                            duplicate_slot_map[
                                face.material_index
                            ]
                        )

                used_indices = {
                    face.material_index
                    for face in bm.faces
                }

                removed_slots = 0

                for remove_index in reversed(
                    range(len(mesh.materials))
                ):
                    if remove_index in used_indices:
                        continue

                    mesh.materials.pop(
                        index=remove_index
                    )
                    removed_slots += 1

                    for face in bm.faces:
                        if face.material_index > remove_index:
                            face.material_index -= 1

                    used_indices = {
                        (
                            index - 1
                            if index > remove_index
                            else index
                        )
                        for index in used_indices
                        if index != remove_index
                    }

                total_removed_slots += removed_slots
                modified_objects += 1

                bmesh.update_edit_mesh(
                    mesh,
                    loop_triangles=False,
                    destructive=False
                )

            if total_selected_faces == 0:
                self.report(
                    {'WARNING'},
                    "Nessuna faccia selezionata"
                )
                return {'CANCELLED'}

            context.scene.material_gallery_selected = (
                material.name
            )

            redraw_ui(
                context
            )

            self.report(
                {'INFO'},
                (
                    f"{material.name} assegnato a "
                    f"{total_selected_faces} facce "
                    f"su {modified_objects} oggetti"
                    + (
                        f" | {total_removed_slots} "
                        f"slot inutilizzati rimossi"
                        if total_removed_slots
                        else ""
                    )
                )
            )

            return {'FINISHED'}

        # ----------------------------------------------------
        # OBJECT MODE:
        # Replace only the active slot.
        # Ask before collapsing same-material duplicate slots.
        # ----------------------------------------------------
        modified = 0
        merged = 0

        for obj in context.selected_objects:

            if obj.type != 'MESH':
                continue

            materials = obj.data.materials

            if len(materials) == 0:

                materials.append(
                    material
                )

            else:

                slot = obj.active_material_index

                if slot >= len(materials):
                    slot = 0

                materials[
                    slot
                ] = material

            if self.cleanup_duplicate_slots:

                merged += merge_duplicate_material_slots_object(
                    obj
                )

            modified += 1

        context.scene.material_gallery_selected = (
            material.name
        )

        self.report(
            {'INFO'},
            (
                f"{material.name} applicato a "
                f"{modified} oggetti"
                + (
                    f" | {merged} slot duplicati rimossi"
                    if merged
                    else ""
                )
            )
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}



def merge_duplicate_material_slots_object(obj):
    """Merge only slots that point to the exact same material datablock.

    Polygon assignments are redirected to the first occurrence.
    Different materials are never removed.
    """
    if obj is None or obj.type != 'MESH':
        return 0

    mesh = obj.data
    materials = mesh.materials

    first_slot_for_material = {}
    duplicate_map = {}

    for index, material in enumerate(materials):
        if material is None:
            continue

        key = material.as_pointer()

        if key not in first_slot_for_material:
            first_slot_for_material[key] = index
        else:
            duplicate_map[index] = first_slot_for_material[key]

    if not duplicate_map:
        return 0

    # Redirect polygons before removing duplicate slots.
    for polygon in mesh.polygons:
        if polygon.material_index in duplicate_map:
            polygon.material_index = duplicate_map[
                polygon.material_index
            ]

    removed = 0

    for remove_index in sorted(
        duplicate_map.keys(),
        reverse=True
    ):
        materials.pop(
            index=remove_index
        )
        removed += 1

        for polygon in mesh.polygons:
            if polygon.material_index > remove_index:
                polygon.material_index -= 1

    return removed


class MATERIALGALLERY_OT_add_material_slot(bpy.types.Operator):
    bl_idname = "material_gallery.add_material_slot"
    bl_label = "Aggiungi nuovo slot"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: bpy.props.StringProperty()

    force_duplicate_slot: bpy.props.BoolProperty(
        name="Aggiungi comunque uno slot duplicato",
        description=(
            "Crea un nuovo slot anche se questo materiale è già presente "
            "nell'oggetto selezionato"
        ),
        default=False
    )

    show_existing_warning: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'}
    )

    def _material_already_present(self, context, material):
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            if any(
                current == material
                for current in obj.data.materials
            ):
                return True

        return False

    def invoke(self, context, event):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        if self._material_already_present(
            context,
            material
        ):
            self.show_existing_warning = True

            return context.window_manager.invoke_props_dialog(
                self,
                width=430
            )

        self.show_existing_warning = False
        return self.execute(context)

    def draw(self, context):
        if not self.show_existing_warning:
            return

        box = self.layout.box()

        box.label(
            text="Questo materiale è già presente nell'oggetto.",
            icon='INFO'
        )

        box.label(
            text="Vuoi aggiungere comunque un nuovo slot?"
        )

        box.prop(
            self,
            "force_duplicate_slot",
            text="Aggiungi slot duplicato"
        )

    def execute(self, context):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        added = 0
        skipped = 0

        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            existing = any(
                current == material
                for current in obj.data.materials
            )

            if existing and not self.force_duplicate_slot:
                skipped += 1
                continue

            obj.data.materials.append(
                material
            )
            added += 1

        self.report(
            {'INFO'},
            (
                f"Nuovo slot aggiunto a {added} oggetti"
                + (
                    f" | non aggiunto su {skipped}: materiale già presente"
                    if skipped
                    else ""
                )
            )
        )

        redraw_ui(context)
        return {'FINISHED'}


class MATERIALGALLERY_OT_apply_to_slot(bpy.types.Operator):
    bl_idname = "material_gallery.apply_to_slot"
    bl_label = "Applica a slot"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: bpy.props.StringProperty()
    slot_index: bpy.props.IntProperty(min=0)

    cleanup_duplicate_slots: bpy.props.BoolProperty(
        name="Rimuovi slot duplicati",
        description=(
            "Se due slot finiscono per usare lo stesso identico materiale, "
            "mantiene un solo slot e preserva le facce"
        ),
        default=True
    )

    show_cleanup_warning: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'}
    )

    def _will_create_duplicate(self, context, material):
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            materials = obj.data.materials

            if self.slot_index >= len(materials):
                continue

            for index, current in enumerate(materials):
                if index == self.slot_index:
                    continue

                if current == material:
                    return True

        return False

    def invoke(self, context, event):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        if self._will_create_duplicate(
            context,
            material
        ):
            self.show_cleanup_warning = True

            return context.window_manager.invoke_props_dialog(
                self,
                width=430
            )

        self.show_cleanup_warning = False
        return self.execute(context)

    def draw(self, context):
        if not self.show_cleanup_warning:
            return

        box = self.layout.box()

        box.label(
            text="Questo materiale è già presente in un altro slot.",
            icon='INFO'
        )

        box.label(
            text="Vuoi unificare gli slot dopo l'assegnazione?"
        )

        box.prop(
            self,
            "cleanup_duplicate_slots",
            text="Rimuovi slot duplicati"
        )

    def execute(self, context):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        modified = 0
        merged = 0

        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            if self.slot_index >= len(obj.data.materials):
                continue

            obj.data.materials[
                self.slot_index
            ] = material

            modified += 1

            if self.cleanup_duplicate_slots:
                merged += merge_duplicate_material_slots_object(
                    obj
                )

        self.report(
            {'INFO'},
            (
                f"{material.name} applicato allo slot "
                f"{self.slot_index + 1} su {modified} oggetti"
                + (
                    f" | {merged} slot duplicati rimossi"
                    if merged
                    else ""
                )
            )
        )

        redraw_ui(context)
        return {'FINISHED'}


class MATERIALGALLERY_OT_page_previous(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.page_previous"

    )



    bl_label = (

        "Pagina precedente"

    )



    current_page: bpy.props.IntProperty(

        default=0

    )





    def execute(

        self,

        context

    ):



        context.scene.material_gallery_page = max(

            0,

            self.current_page - 1

        )



        redraw_ui(

            context

        )



        return {'FINISHED'}





class MATERIALGALLERY_OT_page_next(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.page_next"

    )



    bl_label = (

        "Pagina successiva"

    )



    current_page: bpy.props.IntProperty(

        default=0

    )



    total_pages: bpy.props.IntProperty(

        default=1,

        min=1

    )





    def execute(

        self,

        context

    ):



        context.scene.material_gallery_page = min(

            self.current_page + 1,

            self.total_pages - 1

        )



        redraw_ui(

            context

        )



        return {'FINISHED'}





# ============================================================

# REMAP UTILITY

# ============================================================




def replace_material_in_object_slots(source, target):
    """Sostituisce source con target in tutti gli slot materiale degli oggetti."""
    if source is None or target is None or source == target:
        return 0

    replaced = 0

    for obj in bpy.data.objects:
        data = getattr(obj, "data", None)

        if data is None or not hasattr(data, "materials"):
            continue

        materials = data.materials

        for index, material in enumerate(materials):
            if material == source:
                materials[index] = target
                replaced += 1

    return replaced



def _signature_value(value):
    """Convert common Blender values to stable comparable tuples."""
    if value is None:
        return None

    if isinstance(value, (bool, int, str)):
        return value

    if isinstance(value, float):
        return round(value, 6)

    try:
        return tuple(round(float(v), 6) for v in value)
    except:
        pass

    # Datablocks such as Image / Object / Texture.
    if hasattr(value, "name"):
        extra = None

        if hasattr(value, "filepath"):
            try:
                extra = value.filepath
            except:
                extra = None

        return (
            value.__class__.__name__,
            value.name,
            extra
        )

    return str(value)


def _node_signature(node):
    inputs = []

    for socket in node.inputs:
        if hasattr(socket, "default_value"):
            try:
                default = _signature_value(socket.default_value)
            except:
                default = None
        else:
            default = None

        inputs.append(
            (
                socket.identifier,
                socket.name,
                default
            )
        )

    attrs = []

    # Common node properties that materially change shader behaviour.
    for attr in (
        "operation",
        "blend_type",
        "data_type",
        "interpolation",
        "projection",
        "projection_blend",
        "extension",
        "space",
        "uv_map",
        "attribute_name",
        "layer_name",
        "mapping",
        "vector_type",
        "distribution",
        "subsurface_method",
        "normalize",
        "clamp",
        "use_clamp",
        "invert",
    ):
        if hasattr(node, attr):
            try:
                attrs.append(
                    (
                        attr,
                        _signature_value(
                            getattr(node, attr)
                        )
                    )
                )
            except:
                pass

    # Images are especially important for imported materials.
    image = getattr(node, "image", None)

    if image is not None:
        attrs.append(
            (
                "image",
                _signature_value(image)
            )
        )

    return (
        node.bl_idname,
        tuple(inputs),
        tuple(attrs),
    )


def get_material_signature(material):
    """Signature used to identify functionally identical materials.

    Ignores material/node names and editor positions.
    Compares shader structure, socket values, images and key material settings.
    """
    if material is None:
        return None

    material_settings = (
        bool(material.use_nodes),
        _signature_value(material.diffuse_color),
        round(float(material.metallic), 6),
        round(float(material.roughness), 6),
    )

    if (
        not material.use_nodes
        or material.node_tree is None
    ):
        return (
            material_settings,
            None,
            None
        )

    nodes = list(material.node_tree.nodes)
    node_index = {
        node: index
        for index, node in enumerate(nodes)
    }

    node_signatures = tuple(
        _node_signature(node)
        for node in nodes
    )

    links = []

    for link in material.node_tree.links:
        try:
            links.append(
                (
                    node_index[link.from_node],
                    link.from_socket.identifier,
                    node_index[link.to_node],
                    link.to_socket.identifier,
                )
            )
        except:
            links.append(
                (
                    node_index.get(link.from_node, -1),
                    link.from_socket.name,
                    node_index.get(link.to_node, -1),
                    link.to_socket.name,
                )
            )

    links.sort()

    return (
        material_settings,
        node_signatures,
        tuple(links)
    )


def find_identical_materials(source):
    """Return all materials identical to source, excluding source itself."""
    source_signature = get_material_signature(
        source
    )

    if source_signature is None:
        return []

    result = []

    for material in bpy.data.materials:
        if material == source:
            continue

        try:
            if get_material_signature(material) == source_signature:
                result.append(material)
        except Exception as error:
            print(
                "Fabularis Material Gallery - Duplicate check:",
                material.name,
                error
            )

    return result


def build_remap_target_list(

    context,

    excluded_names

):



    scene = context.scene



    scene.material_remap_list.clear()



    materials = sorted(

        [

            material

            for material

            in bpy.data.materials

            if material.name not in excluded_names

        ],

        key=lambda mat: mat.name.lower()

    )



    for material in materials:



        item = scene.material_remap_list.add()



        item.material_name = (

            material.name

        )



    scene.material_remap_index = 0





def get_current_remap_target(context):



    scene = context.scene



    index = (

        scene.material_remap_index

    )



    if not (

        0

        <= index

        <

        len(scene.material_remap_list)

    ):



        return None



    return bpy.data.materials.get(

        scene.material_remap_list[

            index

        ].material_name

    )





# ============================================================

# REMAP SINGOLO

# ============================================================




class MATERIALGALLERY_OT_remap_source_select_all(bpy.types.Operator):
    bl_idname = "material_gallery.remap_source_select_all"
    bl_label = "Seleziona tutto"

    select_state: bpy.props.BoolProperty(
        default=True
    )

    only_filtered: bpy.props.BoolProperty(
        default=False
    )

    def execute(self, context):
        search = (
            context.scene.material_remap_source_search
            .strip()
            .lower()
        )

        for item in context.scene.material_gallery_list:
            if self.only_filtered and search:
                if search not in item.material_name.lower():
                    continue

            item.selected = self.select_state

        redraw_ui(context)
        return {'FINISHED'}





def remap_mode_update(self, context):
    """Keep single and multi source selection visually separate."""
    if context is None:
        return

    scene = context.scene

    for item in scene.material_gallery_list:
        item.selected = False

    # Clear any auto-identical tracking when changing mode.
    self.auto_identical_names = ""
    self.include_identical = False

    if not self.use_multiple_sources:
        source_name = (
            self.source_material
            or scene.material_gallery_selected
            or scene.material_remap_single_source
        )

        scene.material_remap_single_source = (
            source_name
            if source_name
            else ""
        )

        if source_name:
            item = get_gallery_item(
                scene,
                source_name
            )

            if item is not None:
                item.selected = True

    redraw_ui(context)


def remap_include_identical_update(self, context):
    """Select/deselect identical materials visibly in both single and multi mode."""
    if context is None:
        return

    scene = context.scene

    previous = {
        name
        for name in self.auto_identical_names.split("\n")
        if name
    }

    # First remove only the materials that were auto-selected by this option.
    for item in scene.material_gallery_list:
        if item.material_name in previous:
            item.selected = False

    self.auto_identical_names = ""

    if not self.include_identical:
        redraw_ui(context)
        return

    if self.use_multiple_sources:
        base_sources = get_multi_selected_materials(
            scene
        )
    else:
        source = bpy.data.materials.get(
            scene.material_remap_single_source
            or self.source_material
            or scene.material_gallery_selected
        )
        base_sources = [source] if source is not None else []

        # Keep the single source itself visibly selected too.
        if source is not None:
            item = get_gallery_item(
                scene,
                source.name
            )
            if item is not None:
                item.selected = True

    auto_names = set()

    for source in base_sources:
        if source is None:
            continue

        for duplicate in find_identical_materials(
            source
        ):
            item = get_gallery_item(
                scene,
                duplicate.name
            )

            if item is not None and not item.selected:
                item.selected = True
                auto_names.add(
                    duplicate.name
                )

    self.auto_identical_names = "\n".join(
        sorted(auto_names)
    )

    redraw_ui(context)



class MATERIALGALLERY_OT_change_single_remap_source(bpy.types.Operator):
    bl_idname = "material_gallery.change_single_remap_source"
    bl_label = "Cambia materiale sorgente"
    bl_description = "Scegli un altro materiale da usare come sorgente del Remap"

    material_name: bpy.props.StringProperty(
        name="Materiale"
    )

    def invoke(self, context, event):
        self.material_name = (
            context.scene.material_remap_single_source
            or context.scene.material_gallery_selected
        )

        return context.window_manager.invoke_props_dialog(
            self,
            width=420
        )

    def draw(self, context):
        self.layout.prop_search(
            self,
            "material_name",
            bpy.data,
            "materials",
            text="Materiale"
        )

    def execute(self, context):
        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            self.report(
                {'ERROR'},
                "Seleziona un materiale valido"
            )
            return {'CANCELLED'}

        scene = context.scene
        scene.material_remap_single_source = material.name

        for item in scene.material_gallery_list:
            item.selected = False

        item = get_gallery_item(
            scene,
            material.name
        )

        if item is not None:
            item.selected = True

        redraw_ui(context)

        return {'FINISHED'}


class MATERIALGALLERY_OT_remap_users(bpy.types.Operator):

    bl_idname = "material_gallery.remap_users"
    bl_label = "Remap Material Users"
    bl_options = {'REGISTER', 'UNDO'}

    source_material: bpy.props.StringProperty()

    use_multiple_sources: bpy.props.BoolProperty(
        name="Multi Remap",
        description=(
            "Permette di scegliere più materiali sorgente "
            "direttamente dentro il Remap"
        ),
        default=False,
        update=remap_mode_update
    )

    auto_identical_names: bpy.props.StringProperty(
        default="",
        options={'HIDDEN'}
    )

    include_identical: bpy.props.BoolProperty(
        name="Includi materiali identici",
        description=(
            "Seleziona automaticamente i materiali identici "
            "ai sorgenti selezionati"
        ),
        default=False,
        update=remap_include_identical_update
    )

    remove_sources: bpy.props.BoolProperty(
        name="Elimina materiali originali",
        default=False
    )

    def invoke(self, context, event):
        refresh_material_list(context)

        scene = context.scene
        scene.material_remap_source_search = ""
        scene.material_remap_search = ""

        self.use_multiple_sources = False
        self.include_identical = False
        self.auto_identical_names = ""

        for item in scene.material_gallery_list:
            item.selected = False

        source_name = (
            scene.material_remap_single_source
            or self.source_material
            or scene.material_gallery_selected
        )

        if source_name:
            item = get_gallery_item(
                scene,
                source_name
            )

            if item is not None:
                item.selected = True

        if not get_multi_selected_names(scene):
            self.report(
                {'ERROR'},
                "Nessun materiale sorgente selezionato"
            )
            return {'CANCELLED'}

        # Build once here. Never mutate Scene data from draw().
        # The target list may contain a selected source; execute() safely excludes
        # the chosen target from the source set.
        build_remap_target_list(
            context,
            set()
        )

        if len(scene.material_remap_list) == 0:
            self.report(
                {'ERROR'},
                "Nessun materiale di destinazione disponibile"
            )
            return {'CANCELLED'}

        return context.window_manager.invoke_props_dialog(
            self,
            width=620
        )

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        selected_materials = get_multi_selected_materials(
            scene
        )

        primary = bpy.data.materials.get(
            scene.material_remap_single_source
            or self.source_material
            or scene.material_gallery_selected
        )

        # ====================================================
        # SOURCE MODE
        # ====================================================
        mode_box = layout.box()

        mode_row = mode_box.row(
            align=True
        )

        mode_row.prop(
            self,
            "use_multiple_sources",
            text="Multi Remap",
            toggle=True,
            icon='CHECKBOX_HLT'
        )

        change_row = mode_row.row(
            align=True
        )

        change_row.enabled = (
            not self.use_multiple_sources
        )

        change_row.operator(
            "material_gallery.change_single_remap_source",
            text="Cambia materiale",
            icon='EYEDROPPER'
        )

        source_box = layout.box()

        if not self.use_multiple_sources:
            header = source_box.row()
            header.alert = True
            header.label(
                text="MATERIALE DA CAMBIARE",
                icon='ERROR'
            )

            if primary is not None:
                row = source_box.row()

                icon_id = get_material_icon(
                    primary
                )

                if icon_id:
                    row.template_icon(
                        icon_value=icon_id,
                        scale=4
                    )

                col = row.column()
                col.label(
                    text=primary.name,
                    icon='MATERIAL'
                )
                col.label(
                    text=f"Users: {primary.users}"
                )
            else:
                source_box.label(
                    text="Nessun materiale selezionato",
                    icon='ERROR'
                )

        else:
            header = source_box.row()
            header.alert = True
            header.label(
                text=(
                    f"MATERIALI DA CAMBIARE "
                    f"({len(selected_materials)} selezionati)"
                ),
                icon='ERROR'
            )

            source_box.prop(
                scene,
                "material_remap_source_search",
                text="",
                icon='VIEWZOOM'
            )

            source_box.template_list(
                "MATERIALGALLERY_UL_remap_sources",
                "",
                scene,
                "material_gallery_list",
                scene,
                "material_gallery_list_index",
                rows=7
            )

            row = source_box.row(
                align=True
            )

            search_active = bool(
                scene.material_remap_source_search.strip()
            )

            op = row.operator(
                "material_gallery.remap_source_select_all",
                text=(
                    "Seleziona visibili"
                    if search_active
                    else "Seleziona tutto"
                ),
                icon='CHECKBOX_HLT'
            )
            op.select_state = True
            op.only_filtered = search_active

            op = row.operator(
                "material_gallery.remap_source_select_all",
                text=(
                    "Deseleziona visibili"
                    if search_active
                    else "Deseleziona tutto"
                ),
                icon='CHECKBOX_DEHLT'
            )
            op.select_state = False
            op.only_filtered = search_active



        # ====================================================
        # IDENTICAL MATERIALS
        # ====================================================
        if self.use_multiple_sources:
            duplicate_sources = get_multi_selected_materials(
                scene
            )
        else:
            single_source = bpy.data.materials.get(
                scene.material_remap_single_source
                or self.source_material
                or scene.material_gallery_selected
            )
            duplicate_sources = (
                [single_source]
                if single_source is not None
                else []
            )

        selected_names_for_duplicates = {
            material.name
            for material in get_multi_selected_materials(scene)
        }

        identical_names = set()

        for source in duplicate_sources:
            if source is None:
                continue

            for duplicate in find_identical_materials(
                source
            ):
                if duplicate.name not in selected_names_for_duplicates:
                    identical_names.add(
                        duplicate.name
                    )

        identical_box = layout.box()

        identical_row = identical_box.row()
        identical_row.enabled = (
            len(identical_names) > 0
            or self.include_identical
        )

        identical_row.prop(
            self,
            "include_identical",
            text=(
                f"Includi materiali identici "
                f"(+{len(identical_names)})"
            )
        )

        # ====================================================
        # DESTINATION
        # ====================================================
        layout.separator()

        destination_box = layout.box()

        destination_box.label(
            text="SOSTITUISCI CON",
            icon='CHECKMARK'
        )

        destination_box.prop(
            scene,
            "material_remap_search",
            text="",
            icon='VIEWZOOM'
        )

        destination_box.template_list(
            "MATERIALGALLERY_UL_remap_materials",
            "unified_remap",
            scene,
            "material_remap_list",
            scene,
            "material_remap_index",
            rows=7
        )

        target = get_current_remap_target(
            context
        )

        if target is not None:
            destination_box.separator()

            preview_box = destination_box.box()

            preview_box.label(
                text="MATERIALE DI DESTINAZIONE",
                icon='CHECKMARK'
            )

            row = preview_box.row()

            icon_id = get_material_icon(
                target
            )

            if icon_id:
                row.template_icon(
                    icon_value=icon_id,
                    scale=4
                )

            col = row.column()

            col.label(
                text=target.name,
                icon='MATERIAL'
            )

            col.label(
                text=f"Users: {target.users}"
            )
        else:
            destination_box.label(
                text="Seleziona un materiale di destinazione",
                icon='INFO'
            )

        # ====================================================
        # OPTIONS
        # ====================================================
        layout.separator()

        options_box = layout.box()

        options_box.prop(
            self,
            "remove_sources"
        )

    def execute(self, context):
        scene = context.scene

        target = get_current_remap_target(
            context
        )

        if target is None:
            self.report(
                {'ERROR'},
                "Seleziona un materiale di destinazione"
            )
            return {'CANCELLED'}

        if self.use_multiple_sources:
            sources = get_multi_selected_materials(
                scene
            )
        else:
            source = bpy.data.materials.get(
                scene.material_remap_single_source
                or self.source_material
                or scene.material_gallery_selected
            )

            sources = (
                [source]
                if source is not None
                else []
            )

            if self.include_identical and source is not None:
                sources.extend(
                    find_identical_materials(
                        source
                    )
                )

        if not sources:
            self.report(
                {'ERROR'},
                "Seleziona almeno un materiale da cambiare"
            )
            return {'CANCELLED'}

        # If target is accidentally among the sources, it is simply kept.
        sources = [
            source
            for source in sources
            if source is not None
            and source != target
        ]

        if not sources:
            self.report(
                {'ERROR'},
                "Il materiale di destinazione coincide con i materiali da cambiare"
            )
            return {'CANCELLED'}

        target_name = target.name

        source_names = [
            source.name
            for source in sources
        ]

        replaced_slots = 0

        for source in sources:
            replaced_slots += replace_material_in_object_slots(
                source,
                target
            )

            source.user_remap(
                target
            )

        if self.remove_sources:
            for name in source_names:
                source = bpy.data.materials.get(
                    name
                )

                if (
                    source is not None
                    and source != target
                    and source.users == 0
                ):
                    bpy.data.materials.remove(
                        source
                    )

            invalidate_material_cache()

        for item in scene.material_gallery_list:
            item.selected = False

        scene.material_gallery_selected = (
            target_name
        )

        refresh_material_list(
            context
        )

        redraw_ui(
            context
        )

        self.report(
            {'INFO'},
            (
                f"{len(source_names)} materiali -> "
                f"{target_name} "
                f"({replaced_slots} slot aggiornati)"
            )
        )

        return {'FINISHED'}



def refresh_visible_material_previews(context):
    """Refresh only materials currently relevant to the visible UI."""
    if context is None:
        return 0

    scene = context.scene
    materials = get_display_materials(context)

    if scene.material_gallery_mode == 'GALLERY':
        _, _, per_page = get_gallery_layout(context)

        total_pages = max(
            1,
            math.ceil(len(materials) / per_page)
        )

        page = min(
            scene.material_gallery_page,
            total_pages - 1
        )

        start = page * per_page
        materials = materials[
            start:start + per_page
        ]

    refreshed = 0

    for material in materials:
        try:
            material.update_tag()

            preview = material.preview_ensure()

            if (
                preview is not None
                and hasattr(preview, "reload")
            ):
                try:
                    preview.reload()
                except:
                    pass

            material.preview_ensure()
            refreshed += 1

        except:
            pass

    return refreshed


class MATERIALGALLERY_OT_refresh(

    bpy.types.Operator

):



    bl_idname = (

        "material_gallery.refresh"

    )



    bl_label = (

        "Aggiorna"

    )

    bl_description = (
        "Aggiorna lista e preview visibili dei materiali"
    )





    def execute(

        self,

        context

    ):

        # Refresh data cache.
        invalidate_material_cache()

        # Keep the current page: the user is usually refreshing what is visible.
        refresh_material_list(
            context
        )

        refreshed = refresh_visible_material_previews(
            context
        )

        redraw_ui(
            context
        )

        self.report(
            {'INFO'},
            f"Preview aggiornate: {refreshed}"
        )




        return {'FINISHED'}





# ============================================================

# PANEL MATERIAL

# ============================================================



class FABULARIS_PT_material(

    bpy.types.Panel

):



    bl_label = "Material"



    bl_idname = (

        "FABULARIS_PT_material"

    )



    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'



    bl_category = (

        "Fabularis Tools"

    )





    def draw(

        self,

        context

    ):



        pass





# ============================================================

# MATERIAL GALLERY PANEL

# ============================================================



class MATERIALGALLERY_PT_panel(

    bpy.types.Panel

):



    bl_label = (

        "Material Gallery"

    )



    bl_idname = (

        "MATERIALGALLERY_PT_panel"

    )



    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'



    bl_category = (

        "Fabularis Tools"

    )



    bl_parent_id = (

        "FABULARIS_PT_material"

    )





    def draw(

        self,

        context

    ):



        layout = self.layout

        scene = context.scene





        # ====================================================

        # SEARCH

        # ====================================================



        row = layout.row(

            align=True

        )



        row.prop(

            scene,

            "material_gallery_search",

            text="",

            icon='VIEWZOOM'

        )



        row.operator(

            "material_gallery.refresh",

            text="",

            icon='FILE_REFRESH'

        )

        row.operator(
            "material_gallery.create_material",
            text="",
            icon='ADD'
        )

        row.operator(
            "material_gallery.purge_unused_materials",
            text="",
            icon='TRASH'
        )

        filter_row = layout.row(align=True)
        filter_row.prop(
            scene,
            "material_gallery_filter_mode",
            text=""
        )





        # ====================================================

        # MODE

        # ====================================================



        layout.separator()



        layout.prop(

            scene,

            "material_gallery_mode",

            expand=True

        )



        materials = get_display_materials(

            context

        )



        layout.label(

            text=f"{len(materials)} materiali",

            icon='MATERIAL'

        )





        # ====================================================

        # PAGINAZIONE

        # ====================================================



        columns = 1

        rows = 1

        per_page = 1

        total_pages = 1

        current_page = 0



        if (

            scene.material_gallery_mode

            ==

            'GALLERY'

        ):



            (

                columns,

                rows,

                per_page

            ) = get_gallery_layout(

                context

            )



            total_pages = max(

                1,

                math.ceil(

                    len(materials)

                    /

                    per_page

                )

            )



            current_page = min(

                scene.material_gallery_page,

                total_pages - 1

            )





        # GALLERY

        # ====================================================



        if (

            scene.material_gallery_mode

            ==

            'GALLERY'

        ):



            layout.separator()



            layout.label(

                text="Dimensione Preview"

            )



            layout.prop(

                scene,

                "material_gallery_size",

                text="",

                slider=True

            )



            info = layout.row()



            info.enabled = False



            info.label(

                text=(

                    f"{columns} colonne  |  "

                    f"{rows} righe  |  "

                    f"{per_page} per pagina"

                )

            )



            start = (

                current_page

                *

                per_page

            )



            end = (

                start

                +

                per_page

            )



            grid = layout.grid_flow(

                row_major=True,

                columns=columns,

                even_columns=True,

                even_rows=False,

                align=True

            )



            for material in materials[start:end]:



                box = grid.box()



                icon_id = get_material_icon(

                    material

                )



                item = get_gallery_item(

                    scene,

                    material.name

                )



                name_row = box.row(

                    align=True

                )

                op = name_row.operator(

                    "material_gallery.select_material",

                    text=material.name,

                    emboss=False

                )



                op.material_name = (

                    material.name

                )



                favorite = name_row.operator(
                    "material_gallery.toggle_favorite",
                    text="",
                    icon=('SOLO_ON' if material.get("fabularis_favorite", False) else 'SOLO_OFF'),
                    emboss=False
                )
                favorite.material_name = material.name

                actions = name_row.operator(

                    "material_gallery.material_actions",

                    text="",

                    icon='DOWNARROW_HLT'

                )



                actions.material_name = (

                    material.name

                )





                if icon_id:



                    preview_row = box.row()



                    preview_row.alignment = (

                        'CENTER'

                    )



                    preview_row.template_icon(

                        icon_value=icon_id,

                        scale=(

                            1.4

                            +

                            scene.material_gallery_size

                            *

                            0.50

                        )

                    )





                users = box.row()



                users.enabled = False



                users.label(

                    text=f"Users: {material.users}"

                )





                apply_button = box.operator(
                    "material_gallery.apply_material",
                    text="Applica",
                    icon='CHECKMARK'
                )
                apply_button.material_name = material.name





            # =================================================

            # CAMBIO PAGINA

            # =================================================



            layout.separator()



            row = layout.row(

                align=True

            )



            previous = row.operator(

                "material_gallery.page_previous",

                text="",

                icon='TRIA_LEFT'

            )



            previous.current_page = (

                current_page

            )



            row.label(

                text=(

                    f"Pagina "

                    f"{current_page + 1}"

                    f" / "

                    f"{total_pages}"

                )

            )



            next_page = row.operator(

                "material_gallery.page_next",

                text="",

                icon='TRIA_RIGHT'

            )



            next_page.current_page = (

                current_page

            )



            next_page.total_pages = (

                total_pages

            )





        # ====================================================

        # LISTA

        # ====================================================



        else:



            layout.separator()



            layout.template_list(

                "MATERIALGALLERY_UL_materials",

                "",

                scene,

                "material_gallery_list",

                scene,

                "material_gallery_list_index",

                rows=8

            )





        # ====================================================

        # REMAP

        # ====================================================



        layout.separator()



        selected = bpy.data.materials.get(

            scene.material_gallery_selected

        )



        remap_row = layout.row()



        remap_row.enabled = (

            selected is not None

        )



        op = remap_row.operator(

            "material_gallery.remap_users",

            text="Remap...",

            icon='FILE_REFRESH'

        )



        if selected:

            op.source_material = (

                selected.name

            )





        # SELECTED MATERIAL

        # ====================================================



        selected = bpy.data.materials.get(

            scene.material_gallery_selected

        )



        if selected:



            layout.separator()



            box = layout.box()



            row = box.row()



            icon_id = get_material_icon(

                selected

            )



            if icon_id:



                row.template_icon(

                    icon_value=icon_id,

                    scale=2

                )



            column = row.column()



            column.label(

                text=selected.name

            )



            column.label(

                text=f"Users: {selected.users}"

            )





# ============================================================

# CLASSI

# ============================================================



class MATERIALGALLERY_OT_toggle_favorite(bpy.types.Operator):
    bl_idname = "material_gallery.toggle_favorite"
    bl_label = "Preferito"
    bl_description = "Aggiunge o rimuove il materiale dai preferiti"

    material_name: bpy.props.StringProperty()

    def execute(self, context):
        material = bpy.data.materials.get(self.material_name)
        if material is None:
            return {'CANCELLED'}

        material["fabularis_favorite"] = not bool(
            material.get("fabularis_favorite", False)
        )
        redraw_ui(context)
        return {'FINISHED'}


class MATERIALGALLERY_OT_duplicate_material(
    bpy.types.Operator
):

    bl_idname = "material_gallery.duplicate_material"
    bl_label = "Duplica Materiale"

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    material_name: bpy.props.StringProperty()

    def execute(
        self,
        context
    ):

        source = bpy.data.materials.get(
            self.material_name
        )

        if source is None:
            return {'CANCELLED'}

        material = source.copy()
        material.name = source.name + "_Copy"
        invalidate_material_cache()

        context.scene.material_gallery_selected = (
            material.name
        )

        refresh_material_list(
            context
        )

        focus_material_in_blender(
            context,
            material
        )

        redraw_ui(
            context
        )

        self.report(
            {'INFO'},
            f"Creato {material.name}"
        )

        return {'FINISHED'}


class MATERIALGALLERY_OT_select_objects_using_material(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.select_objects_using_material"
    )

    bl_label = (
        "Seleziona Oggetti che Usano il Materiale"
    )

    bl_description = (
        "Seleziona gli oggetti che usano il materiale. "
        "Entrando poi in Edit Mode seleziona automaticamente le facce che lo usano"
    )

    material_name: bpy.props.StringProperty()

    def execute(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        was_edit_mode = (
            context.mode == 'EDIT_MESH'
        )

        # Remember the material for a later transition to Edit Mode.
        context.scene.material_gallery_face_select_material = (
            material.name
        )

        if context.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(
                    mode='OBJECT'
                )
            except:
                pass

        bpy.ops.object.select_all(
            action='DESELECT'
        )

        found = []

        for obj in context.view_layer.objects:
            if obj.type != 'MESH':
                continue

            uses_material = any(
                slot.material == material
                for slot in obj.material_slots
            )

            if uses_material:
                obj.select_set(
                    True
                )
                found.append(
                    obj
                )

        if found:
            context.view_layer.objects.active = (
                found[0]
            )

        # If the command was launched while already in Edit Mode,
        # immediately return to Edit Mode and select the matching faces.
        if found and was_edit_mode:
            try:
                bpy.ops.object.mode_set(
                    mode='EDIT'
                )
                select_faces_using_pending_material()
            except Exception as error:
                print(
                    "Fabularis Material Gallery - restore Edit Mode:",
                    error
                )

        self.report(
            {'INFO'},
            (
                f"{len(found)} oggetti selezionati"
                + (
                    " | facce del materiale selezionate"
                    if was_edit_mode and found
                    else " | entra in Edit Mode per vedere le facce"
                )
            )
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


class MATERIALGALLERY_OT_purge_unused_materials(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.purge_unused_materials"
    )

    bl_label = (
        "Elimina Materiali Non Utilizzati"
    )

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    def invoke(
        self,
        context,
        event
    ):

        unused_count = len([
            material
            for material in bpy.data.materials
            if material.users == 0
        ])

        if unused_count == 0:

            self.report(
                {'INFO'},
                "Nessun materiale inutilizzato"
            )

            return {'CANCELLED'}

        return (
            context.window_manager
            .invoke_confirm(
                self,
                event
            )
        )

    def execute(
        self,
        context
    ):

        unused = [
            material
            for material in list(
                bpy.data.materials
            )
            if material.users == 0
        ]

        count = len(
            unused
        )

        for material in unused:

            bpy.data.materials.remove(
                material
            )

        invalidate_material_cache()

        refresh_material_list(
            context
        )

        redraw_ui(
            context
        )

        self.report(
            {'INFO'},
            f"Eliminati {count} materiali inutilizzati"
        )

        return {'FINISHED'}


classes = (



    MATERIALGALLERY_PG_list_item,



    MATERIALGALLERY_UL_materials,

    MATERIALGALLERY_UL_remap_sources,
    MATERIALGALLERY_UL_remap_materials,



    MATERIALGALLERY_OT_create_material,

    MATERIALGALLERY_OT_select_material,



    MATERIALGALLERY_OT_toggle_fake_user,
    MATERIALGALLERY_OT_material_actions,

    MATERIALGALLERY_OT_rename_material,

    MATERIALGALLERY_OT_delete_material,



    MATERIALGALLERY_OT_select_visible,

    MATERIALGALLERY_OT_clear_multi,
    MATERIALGALLERY_OT_select_all_multi,
    MATERIALGALLERY_OT_multi_selection_tools,
    MATERIALGALLERY_OT_multi_selection_menu,



    MATERIALGALLERY_OT_apply_material,



    MATERIALGALLERY_OT_page_previous,

    MATERIALGALLERY_OT_page_next,



    MATERIALGALLERY_OT_remap_source_select_all,
    MATERIALGALLERY_OT_change_single_remap_source,
    MATERIALGALLERY_OT_remap_users,




    MATERIALGALLERY_OT_toggle_favorite,
    MATERIALGALLERY_OT_add_material_slot,
    MATERIALGALLERY_OT_apply_to_slot,

    MATERIALGALLERY_OT_duplicate_material,
    MATERIALGALLERY_OT_select_objects_using_material,
    MATERIALGALLERY_OT_purge_unused_materials,

    MATERIALGALLERY_OT_refresh,



    FABULARIS_PT_material,

    MATERIALGALLERY_PT_panel,



)





# ============================================================

# REGISTER

# ============================================================



def register():



    for cls in classes:



        bpy.utils.register_class(

            cls

        )





    bpy.types.Scene.material_gallery_face_select_material = (
        bpy.props.StringProperty(
            name="Materiale facce da selezionare",
            default=""
        )
    )


    bpy.types.Scene.material_gallery_search = (

        bpy.props.StringProperty(

            name="Search",

            default="",

            update=gallery_updated

        )

    )





    bpy.types.Scene.material_gallery_filter_mode = (
        bpy.props.EnumProperty(
            name="Filtro",
            items=[
                ('ALL', "Tutti", "Mostra tutti i materiali"),
                ('USED', "Usati", "Mostra solo materiali con almeno un utilizzatore"),
                ('UNUSED', "Non usati", "Mostra solo materiali senza utilizzatori"),
                ('ACTIVE_OBJECT', "Oggetto attivo", "Mostra solo i materiali dell'oggetto attivo"),
                ('FAVORITES', "Preferiti", "Mostra solo i materiali preferiti"),
            ],
            default='ALL',
            update=gallery_updated
        )
    )


    bpy.types.Scene.material_gallery_mode = (

        bpy.props.EnumProperty(

            name="Visualizzazione",

            items=[

                (

                    'GALLERY',

                    "Gallery",

                    "Gallery responsive"

                ),

                (

                    'LIST',

                    "Lista",

                    "Lista interna scrollabile"

                ),

            ],

            default='GALLERY'

        )

    )





    bpy.types.Scene.material_gallery_selected = (

        bpy.props.StringProperty(

            name="Materiale selezionato",

            default=""

        )

    )





    bpy.types.Scene.material_gallery_size = (

        bpy.props.IntProperty(

            name="Dimensione Preview",

            default=7,

            min=1,

            max=10,

            update=gallery_updated

        )

    )





    bpy.types.Scene.material_gallery_page = (

        bpy.props.IntProperty(

            default=0,

            min=0

        )

    )





    bpy.types.Scene.material_multi_mode = (

        bpy.props.BoolProperty(

            name="Multi Remap",

            description=(

                "Permette di selezionare "

                "più materiali e rimapparli "

                "verso un unico materiale"

            ),

            default=False

        )

    )





    bpy.types.Scene.material_gallery_list = (

        bpy.props.CollectionProperty(

            type=MATERIALGALLERY_PG_list_item

        )

    )





    bpy.types.Scene.material_gallery_list_index = (

        bpy.props.IntProperty(

            default=0

        )

    )





    bpy.types.Scene.material_remap_list = (

        bpy.props.CollectionProperty(

            type=MATERIALGALLERY_PG_list_item

        )

    )





    bpy.types.Scene.material_remap_index = (

        bpy.props.IntProperty(

            default=0

        )

    )





    bpy.types.Scene.material_remap_single_source = (
        bpy.props.StringProperty(
            name="Materiale sorgente Remap",
            default=""
        )
    )


    bpy.types.Scene.material_remap_source_search = (
        bpy.props.StringProperty(
            name="Cerca sorgenti",
            default=""
        )
    )


    bpy.types.Scene.material_remap_search = (

        bpy.props.StringProperty(

            name="Cerca materiale",

            default=""

        )

    )





    register_msgbus()





    if (

        material_gallery_load_post

        not in

        bpy.app.handlers.load_post

    ):



        bpy.app.handlers.load_post.append(

            material_gallery_load_post

        )





# ============================================================

# UNREGISTER

# ============================================================



def unregister():



    unregister_msgbus()





    if (

        material_gallery_load_post

        in

        bpy.app.handlers.load_post

    ):



        bpy.app.handlers.load_post.remove(

            material_gallery_load_post

        )





    try:

        restore_normal_properties()

    except:

        pass





    properties = (

        "material_gallery_face_select_material",




        "material_remap_search",



        "material_remap_index",



        "material_remap_list",



        "material_gallery_list_index",



        "material_gallery_list",



        "material_multi_mode",



        "material_gallery_page",



        "material_gallery_size",



        "material_gallery_selected",



        "material_gallery_mode",



        "material_gallery_search",



    )





    for prop in properties:



        if hasattr(

            bpy.types.Scene,

            prop

        ):



            delattr(

                bpy.types.Scene,

                prop

            )





    for cls in reversed(

        classes

    ):



        try:



            bpy.utils.unregister_class(

                cls

            )



        except:



            pass

