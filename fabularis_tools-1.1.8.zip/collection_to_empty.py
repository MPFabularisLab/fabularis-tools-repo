import bpy


# ============================================================
# FABULARIS TOOLS - COLLECTION TO EMPTY
# ============================================================


# ============================================================
# UTILITY
# ============================================================

def is_collection_instance(obj):

    return (
        obj is not None
        and obj.type == 'EMPTY'
        and obj.instance_type == 'COLLECTION'
        and obj.instance_collection is not None
    )


# ============================================================
# MAKE INSTANCES REAL - BATCH
# ============================================================

def make_instances_real_batch(
    root_collection,
    context
):

    """
    Trova tutte le Collection Instance contenute nella
    Collection selezionata e nelle sue sotto-Collection.

    Esegue UNA SOLA VOLTA:

        Make Instances Real
        Parent = ON
        Keep Hierarchy = ON

    È equivalente al comando manuale di Blender.
    """

    view_layer = context.view_layer

    print("")
    print("============================================")
    print("MAKE INSTANCES REAL - BATCH")
    print("Parent: ON")
    print("Keep Hierarchy: ON")
    print("============================================")

    # --------------------------------------------------------
    # RACCOGLI TUTTE LE COLLECTION
    # --------------------------------------------------------

    all_collections = []

    def raccogli_collection(col):

        all_collections.append(col)

        for child in col.children:
            raccogli_collection(child)

    raccogli_collection(
        root_collection
    )

    # --------------------------------------------------------
    # TROVA TUTTE LE COLLECTION INSTANCE
    # --------------------------------------------------------

    instances = []

    already_found = set()

    for col in all_collections:

        for obj in col.objects:

            if obj in already_found:
                continue

            if is_collection_instance(obj):

                already_found.add(obj)

                instances.append(obj)

                print(
                    f"INSTANCE TROVATA: "
                    f"{obj.name}"
                )

    # --------------------------------------------------------
    # NESSUNA INSTANCE
    # --------------------------------------------------------

    if not instances:

        print(
            "Nessuna Collection Instance trovata."
        )

        print("")

        return 0

    print("")
    print(
        f"Totale Instance da rendere reali: "
        f"{len(instances)}"
    )

    # --------------------------------------------------------
    # OBJECT MODE
    # --------------------------------------------------------

    if context.mode != 'OBJECT':

        try:

            bpy.ops.object.mode_set(
                mode='OBJECT'
            )

        except:

            pass

    # --------------------------------------------------------
    # SALVA SELEZIONE ATTUALE
    # --------------------------------------------------------

    old_selected = list(
        context.selected_objects
    )

    old_active = (
        view_layer.objects.active
    )

    # --------------------------------------------------------
    # DESELEZIONA TUTTO
    # --------------------------------------------------------

    bpy.ops.object.select_all(
        action='DESELECT'
    )

    # --------------------------------------------------------
    # SELEZIONA SOLO LE COLLECTION INSTANCE
    # --------------------------------------------------------

    valid_instances = []

    for obj in instances:

        try:

            obj.select_set(True)

            valid_instances.append(
                obj
            )

        except:

            print(
                f"ATTENZIONE: impossibile selezionare "
                f"{obj.name}"
            )

    if not valid_instances:

        print(
            "Nessuna Instance valida da convertire."
        )

        return 0

    view_layer.objects.active = (
        valid_instances[0]
    )

    # --------------------------------------------------------
    # MAKE INSTANCES REAL
    # --------------------------------------------------------

    print("")
    print(
        "Esecuzione Make Instances Real..."
    )

    try:

        bpy.ops.object.duplicates_make_real(
            use_base_parent=True,
            use_hierarchy=True
        )

    except Exception as e:

        print("")
        print(
            f"ERRORE MAKE INSTANCES REAL: {e}"
        )

        raise

    view_layer.update()

    print("")
    print(
        "Make Instances Real completato."
    )

    # --------------------------------------------------------
    # RIPRISTINA SELEZIONE QUANDO POSSIBILE
    # --------------------------------------------------------

    bpy.ops.object.select_all(
        action='DESELECT'
    )

    for obj in old_selected:

        if obj.name in bpy.data.objects:

            try:

                obj.select_set(True)

            except:

                pass

    if (
        old_active is not None
        and old_active.name in bpy.data.objects
    ):

        try:

            view_layer.objects.active = (
                old_active
            )

        except:

            pass

    print("============================================")
    print("")

    return len(valid_instances)


# ============================================================
# FUNZIONE PRINCIPALE
# ============================================================

def converti_collection_in_nulli(
    root_collection,
    context
):

    scene = context.scene
    view_layer = context.view_layer

    if root_collection is None:

        raise RuntimeError(
            "Nessuna Collection selezionata."
        )

    if root_collection == scene.collection:

        raise RuntimeError(
            "Non puoi convertire la Scene Collection principale."
        )

    print("")
    print("============================================")
    print("CONVERSIONE COLLECTION -> EMPTY")
    print(f"Root: {root_collection.name}")
    print("============================================")

    # ========================================================
    # 0. MAKE INSTANCES REAL
    # ========================================================

    numero_instances = (
        make_instances_real_batch(
            root_collection,
            context
        )
    )

    print(
        f"Instance processate: "
        f"{numero_instances}"
    )

    view_layer.update()

    # ========================================================
    # 1. RACCOGLI COLLECTION
    # ========================================================

    collections_data = []

    def raccogli(
        col,
        depth=0,
        parent=None
    ):

        collections_data.append({
            "collection": col,
            "depth": depth,
            "parent": parent,
        })

        for child in col.children:

            raccogli(
                child,
                depth + 1,
                col
            )

    raccogli(root_collection)

    collections_set = {
        item["collection"]
        for item in collections_data
    }

    print(
        f"Collection trovate: "
        f"{len(collections_data)}"
    )

    for item in collections_data:

        col = item["collection"]
        depth = item["depth"]

        print(
            "    " * depth +
            f"- {col.name}"
        )

    # ========================================================
    # 2. TROVA EMPTY ESISTENTI
    # ========================================================

    print("")
    print("Ricerca Empty esistenti...")

    existing_empties = set()

    collection_instances = set()

    for item in collections_data:

        col = item["collection"]

        for obj in col.objects:

            if obj.type != 'EMPTY':
                continue

            if is_collection_instance(obj):

                collection_instances.add(
                    obj
                )

                print(
                    f"INSTANCE ANCORA PRESENTE: "
                    f"{obj.name}"
                )

                continue

            existing_empties.add(
                obj
            )

            print(
                f"EMPTY PROTETTO: "
                f"{obj.name}"
            )

    # ========================================================
    # 3. PROTEGGI GERARCHIE DEGLI EMPTY ORIGINALI
    # ========================================================

    protected_objects = set()

    def protect_hierarchy(obj):

        if obj in protected_objects:
            return

        protected_objects.add(
            obj
        )

        for child in obj.children:

            protect_hierarchy(
                child
            )

    for empty in existing_empties:

        protect_hierarchy(
            empty
        )

    print("")
    print(
        f"Oggetti protetti: "
        f"{len(protected_objects)}"
    )

    # ========================================================
    # 4. CREA EMPTY PER LE COLLECTION
    # ========================================================

    collection_to_empty = {}

    for item in collections_data:

        col = item["collection"]

        empty = bpy.data.objects.new(
            name=col.name,
            object_data=None
        )

        empty.empty_display_type = (
            'PLAIN_AXES'
        )

        empty.empty_display_size = (
            0.5
        )

        scene.collection.objects.link(
            empty
        )

        collection_to_empty[col] = (
            empty
        )

    root_empty = (
        collection_to_empty[
            root_collection
        ]
    )

    # ========================================================
    # 5. RICREA GERARCHIA COLLECTION
    # ========================================================

    for item in collections_data:

        col = item["collection"]

        parent_col = item["parent"]

        empty = (
            collection_to_empty[col]
        )

        if parent_col is not None:

            parent_empty = (
                collection_to_empty[
                    parent_col
                ]
            )

            empty.parent = (
                parent_empty
            )

    # ========================================================
    # 6. GESTISCI OGGETTI
    # ========================================================

    print("")
    print("Gestione oggetti...")

    generated_empties = set(
        collection_to_empty.values()
    )

    for item in collections_data:

        col = item["collection"]

        generated_empty = (
            collection_to_empty[col]
        )

        for obj in list(col.objects):

            if obj in generated_empties:
                continue

            # =================================================
            # OGGETTO PROTETTO
            # =================================================

            if obj in protected_objects:

                print(
                    f"PROTETTO: "
                    f"{obj.name}"
                )

                has_external_collection = False

                for user_col in obj.users_collection:

                    if (
                        user_col
                        not in collections_set
                    ):

                        has_external_collection = True
                        break

                if not has_external_collection:

                    if (
                        obj.name
                        not in scene.collection.objects
                    ):

                        scene.collection.objects.link(
                            obj
                        )

                continue

            # =================================================
            # OGGETTO NORMALE
            # =================================================

            print(
                f"OGGETTO: "
                f"{obj.name} -> "
                f"{generated_empty.name}"
            )

            matrix_world = (
                obj.matrix_world.copy()
            )

            obj.parent = (
                generated_empty
            )

            obj.matrix_world = (
                matrix_world
            )

            if (
                obj.name
                not in scene.collection.objects
            ):

                scene.collection.objects.link(
                    obj
                )

    # ========================================================
    # 7. RIPOSIZIONA EMPTY ORIGINALI NELLA GERARCHIA
    # ========================================================

    print("")
    print(
        "Ripristino posizione Empty originali..."
    )

    processed_existing_empties = set()

    for item in collections_data:

        col = item["collection"]

        generated_empty = (
            collection_to_empty[col]
        )

        for obj in list(col.objects):

            if obj not in existing_empties:
                continue

            if obj in processed_existing_empties:
                continue

            processed_existing_empties.add(
                obj
            )

            # ------------------------------------------------
            # EMPTY CON PARENT ESISTENTE
            # ------------------------------------------------

            if obj.parent is not None:

                print(
                    f"EMPTY GERARCHIA PRESERVATA: "
                    f"{obj.name} -> "
                    f"{obj.parent.name}"
                )

            # ------------------------------------------------
            # EMPTY ROOT
            # ------------------------------------------------

            else:

                matrix_world = (
                    obj.matrix_world.copy()
                )

                obj.parent = (
                    generated_empty
                )

                obj.matrix_world = (
                    matrix_world
                )

                print(
                    f"EMPTY ROOT: "
                    f"{obj.name} -> "
                    f"{generated_empty.name}"
                )

            # ------------------------------------------------
            # SICUREZZA
            # ------------------------------------------------

            has_external_collection = False

            for user_col in obj.users_collection:

                if (
                    user_col
                    not in collections_set
                ):

                    has_external_collection = True
                    break

            if not has_external_collection:

                if (
                    obj.name
                    not in scene.collection.objects
                ):

                    scene.collection.objects.link(
                        obj
                    )

    # ========================================================
    # 8. SICUREZZA GERARCHIE PROTETTE
    # ========================================================

    print("")
    print(
        "Controllo gerarchie protette..."
    )

    for obj in protected_objects:

        has_external_collection = False

        for user_col in obj.users_collection:

            if (
                user_col
                not in collections_set
            ):

                has_external_collection = True
                break

        if not has_external_collection:

            if (
                obj.name
                not in scene.collection.objects
            ):

                scene.collection.objects.link(
                    obj
                )

    # ========================================================
    # 9. ELIMINA COLLECTION ORIGINALI
    # ========================================================

    print("")
    print(
        "Eliminazione Collection originali..."
    )

    sorted_data = sorted(
        collections_data,
        key=lambda x: x["depth"],
        reverse=True
    )

    for item in sorted_data:

        col = item["collection"]

        print(
            f"Eliminazione: "
            f"{col.name}"
        )

        try:

            bpy.data.collections.remove(
                col,
                do_unlink=True
            )

        except Exception as e:

            print(
                f"Errore su "
                f"{col.name}: {e}"
            )

    # ========================================================
    # 10. UPDATE
    # ========================================================

    view_layer.update()

    # ========================================================
    # FINE
    # ========================================================

    print("")
    print("============================================")
    print("CONVERSIONE COMPLETATA")
    print("")

    print(
        f"Make Instances Real: "
        f"{numero_instances}"
    )

    print(
        f"Empty originali protetti: "
        f"{len(existing_empties)}"
    )

    print(
        f"Oggetti protetti: "
        f"{len(protected_objects)}"
    )

    print("============================================")
    print("")

    return root_empty


# ============================================================
# OPERATORE
# ============================================================

class FABULARIS_OT_convert_collection_to_empty(
    bpy.types.Operator
):

    bl_idname = (
        "fabularis.convert_collection_to_empty"
    )

    bl_label = (
        "Converti Collection in Empty"
    )

    bl_description = (
        "Converte Collection e sotto-Collection in Empty, "
        "eseguendo prima Make Instances Real "
        "con Parent e Keep Hierarchy"
    )

    bl_options = {
        'REGISTER',
        'UNDO',
    }

    collection_name: (
        bpy.props.StringProperty()
    )


    def execute(
        self,
        context
    ):

        collection = (
            bpy.data.collections.get(
                self.collection_name
            )
        )

        if collection is None:

            self.report(
                {'ERROR'},
                "Collection non trovata."
            )

            return {'CANCELLED'}

        try:

            converti_collection_in_nulli(
                collection,
                context
            )

        except Exception as e:

            self.report(
                {'ERROR'},
                str(e)
            )

            return {'CANCELLED'}

        self.report(
            {'INFO'},
            f"Collection "
            f"'{self.collection_name}' "
            f"convertita in Empty."
        )

        return {'FINISHED'}


# ============================================================
# MENU CONTESTUALE OUTLINER
# ============================================================

def menu_outliner_collection(
    self,
    context
):

    active_id = context.id

    if not isinstance(
        active_id,
        bpy.types.Collection
    ):

        return

    layout = self.layout

    layout.separator()

    operator = layout.operator(
        FABULARIS_OT_convert_collection_to_empty.bl_idname,
        text="Collection to Empty",
        icon='EMPTY_AXIS'
    )

    operator.collection_name = (
        active_id.name
    )


# ============================================================
# MACRO GRUPPO - CONVERTITORE
# ============================================================

class FABULARIS_PT_converter(
    bpy.types.Panel
):

    bl_label = "Convertitore"

    bl_idname = (
        "FABULARIS_PT_converter"
    )

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = (
        "Fabularis Tools"
    )

    def draw(
        self,
        context
    ):

        pass


# ============================================================
# PANNELLO FIGLIO
# ============================================================

class FABULARIS_PT_collection_tools(
    bpy.types.Panel
):

    bl_label = (
        "Collection to Empty"
    )

    bl_idname = (
        "FABULARIS_PT_collection_tools"
    )

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = (
        "Fabularis Tools"
    )

    bl_parent_id = (
        "FABULARIS_PT_converter"
    )

    def draw(
        self,
        context
    ):

        layout = self.layout

        layout.label(
            text="Collection -> Empty",
            icon='OUTLINER_COLLECTION'
        )

        layout.separator()

        layout.label(
            text="Make Instances Real automatico",
            icon='DUPLICATE'
        )

        layout.label(
            text="Parent + Keep Hierarchy"
        )

        layout.separator()

        layout.label(
            text="Empty originali preservati",
            icon='LOCKED'
        )


# ============================================================
# CLASSI
# ============================================================

classes = (

    FABULARIS_OT_convert_collection_to_empty,

    FABULARIS_PT_converter,

    FABULARIS_PT_collection_tools,

)


# ============================================================
# REGISTER
# ============================================================

def register():

    for cls in classes:

        bpy.utils.register_class(
            cls
        )

    bpy.types.OUTLINER_MT_collection.append(
        menu_outliner_collection
    )


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    try:

        bpy.types.OUTLINER_MT_collection.remove(
            menu_outliner_collection
        )

    except:

        pass

    for cls in reversed(classes):

        try:

            bpy.utils.unregister_class(
                cls
            )

        except:

            pass