import bpy


# ============================================================
# FABULARIS TOOLS - EMPTY TO COLLECTION
# ============================================================


def link_object_to_collection(obj, collection):
    """Sposta l'oggetto nella Collection indicata."""

    for col in list(obj.users_collection):
        col.objects.unlink(obj)

    if obj.name not in collection.objects:
        collection.objects.link(obj)


def get_parent_collection_for_object(obj):

    if obj.users_collection:
        return obj.users_collection[0]

    return bpy.context.scene.collection


def create_collection_for_empty(empty, parent_collection):

    print(f"Conversione Empty: {empty.name}")

    # ========================================================
    # CREA COLLECTION
    # ========================================================

    new_collection = bpy.data.collections.get(
        empty.name
    )

    if new_collection is not None:

        new_collection = bpy.data.collections.new(
            empty.name + "_COL"
        )

    else:

        new_collection = bpy.data.collections.new(
            empty.name
        )

    parent_collection.children.link(
        new_collection
    )

    children = list(
        empty.children
    )


    # ========================================================
    # PROCESSA FIGLI
    # ========================================================

    for child in children:

        # ----------------------------------------------------
        # EMPTY -> COLLECTION ANNIDATA
        # ----------------------------------------------------

        if child.type == 'EMPTY':

            create_collection_for_empty(
                child,
                new_collection
            )


        # ----------------------------------------------------
        # OGGETTO NORMALE -> COLLECTION
        # ----------------------------------------------------

        else:

            world_matrix = (
                child.matrix_world.copy()
            )

            child.parent = None

            child.matrix_world = (
                world_matrix
            )

            link_object_to_collection(
                child,
                new_collection
            )


    # ========================================================
    # ELIMINA EMPTY
    # ========================================================

    print(
        f"Eliminazione Empty: {empty.name}"
    )

    bpy.data.objects.remove(
        empty,
        do_unlink=True
    )

    return new_collection


# ============================================================
# CONVERSIONE PRINCIPALE
# ============================================================

def converti_empty_in_collection(
    root_empty,
    context
):

    if root_empty is None:

        raise RuntimeError(
            "Nessun Empty selezionato."
        )


    if root_empty.type != 'EMPTY':

        raise RuntimeError(
            f"'{root_empty.name}' non e un Empty."
        )


    print("")
    print("============================================")
    print("CONVERSIONE EMPTY -> COLLECTION")
    print(f"Root: {root_empty.name}")
    print("============================================")


    empty_name = (
        root_empty.name
    )


    parent_collection = (
        get_parent_collection_for_object(
            root_empty
        )
    )


    root_collection = (
        create_collection_for_empty(
            root_empty,
            parent_collection
        )
    )


    context.view_layer.update()


    print("")
    print("CONVERSIONE COMPLETATA")
    print(
        f"Root Collection: {empty_name}"
    )
    print("============================================")
    print("")


    return root_collection


# ============================================================
# OPERATORE
# ============================================================

class FABULARIS_OT_convert_empty_to_collection(
    bpy.types.Operator
):

    bl_idname = (
        "fabularis.convert_empty_to_collection"
    )

    bl_label = (
        "Converti Empty in Collection"
    )

    bl_description = (
        "Converte questo Empty e tutti gli "
        "Empty figli in una gerarchia di Collections"
    )

    bl_options = {
        'REGISTER',
        'UNDO',
    }


    object_name: bpy.props.StringProperty()


    def execute(self, context):

        obj = bpy.data.objects.get(
            self.object_name
        )


        if obj is None:

            self.report(
                {'ERROR'},
                "Oggetto non trovato."
            )

            return {'CANCELLED'}


        if obj.type != 'EMPTY':

            self.report(
                {'ERROR'},
                f"'{obj.name}' non e un Empty."
            )

            return {'CANCELLED'}


        try:

            converti_empty_in_collection(
                obj,
                context
            )


        except Exception as e:

            self.report(
                {'ERROR'},
                str(e)
            )

            return {'CANCELLED'}


        self.report(
            {'INFO'},
            f"Empty '{self.object_name}' "
            "convertito in Collection."
        )


        return {'FINISHED'}


# ============================================================
# MENU TASTO DESTRO OUTLINER
# ============================================================

def menu_outliner_object(
    self,
    context
):

    active_id = context.id


    if not isinstance(
        active_id,
        bpy.types.Object
    ):
        return


    if active_id.type != 'EMPTY':
        return


    layout = self.layout

    layout.separator()


    operator = layout.operator(
        FABULARIS_OT_convert_empty_to_collection.bl_idname,
        text="Converti Empty in Collection",
        icon='OUTLINER_COLLECTION'
    )


    operator.object_name = (
        active_id.name
    )


# ============================================================
# PANNELLO FIGLIO - EMPTY TO COLLECTION
# ============================================================

class FABULARIS_PT_empty_to_collection(
    bpy.types.Panel
):

    bl_label = "Empty to Collection"

    bl_idname = (
        "FABULARIS_PT_empty_to_collection"
    )

    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    bl_category = "Fabularis Tools"


    # ========================================================
    # FIGLIO DEL MACRO GRUPPO CONVERTITORE
    # ========================================================

    bl_parent_id = (
        "FABULARIS_PT_converter"
    )


    def draw(self, context):

        layout = self.layout


        layout.label(
            text="Empty -> Collection",
            icon='OUTLINER_COLLECTION'
        )


        layout.separator()


        layout.label(
            text="Usa il tasto destro",
            icon='INFO'
        )


        layout.label(
            text="su un Empty nell'Outliner"
        )


        layout.label(
            text="per convertirlo in Collection."
        )


# ============================================================
# CLASSI
# ============================================================

classes = (

    FABULARIS_OT_convert_empty_to_collection,

    FABULARIS_PT_empty_to_collection,

)


# ============================================================
# REGISTER
# ============================================================

def register():

    for cls in classes:

        bpy.utils.register_class(
            cls
        )


    bpy.types.OUTLINER_MT_object.append(
        menu_outliner_object
    )


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    try:

        bpy.types.OUTLINER_MT_object.remove(
            menu_outliner_object
        )

    except:

        pass


    for cls in reversed(classes):

        try:

            bpy.utils.unregister_class(
                cls
            )

        except:

            pass