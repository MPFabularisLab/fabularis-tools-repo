import bpy


# ============================================================
# FABULARIS TOOLS - CREA UV MANCANTI
# ============================================================


def crea_uv_map_mancanti(context):

    oggetti_modificati = []

    for obj in context.scene.objects:

        # Considera solo le Mesh
        if obj.type != 'MESH':
            continue

        # Se ha gia almeno una UV Map, non fare nulla
        if len(obj.data.uv_layers) > 0:
            continue

        # Crea la UV Map
        obj.data.uv_layers.new(
            name="UVMap"
        )

        oggetti_modificati.append(obj)

        print(
            f"UV Map creata: {obj.name}"
        )


    # ========================================================
    # SELEZIONA GLI OGGETTI MODIFICATI
    # ========================================================

    bpy.ops.object.select_all(
        action='DESELECT'
    )

    for obj in oggetti_modificati:
        obj.select_set(True)

    if oggetti_modificati:

        context.view_layer.objects.active = (
            oggetti_modificati[0]
        )


    print("--------------------------------")

    print(
        f"Oggetti modificati: "
        f"{len(oggetti_modificati)}"
    )

    print("Operazione completata.")


    return oggetti_modificati


# ============================================================
# OPERATORE
# ============================================================

class FABULARIS_OT_create_missing_uv(
    bpy.types.Operator
):

    bl_idname = "fabularis.create_missing_uv"

    bl_label = "Crea UV sui Modelli Senza UV"

    bl_description = (
        "Trova tutti i modelli Mesh che non hanno "
        "nessuna UV Map e ne crea automaticamente una"
    )

    bl_options = {
        'REGISTER',
        'UNDO',
    }


    def execute(self, context):

        try:

            oggetti_modificati = (
                crea_uv_map_mancanti(
                    context
                )
            )

        except Exception as e:

            self.report(
                {'ERROR'},
                str(e)
            )

            return {'CANCELLED'}


        # ====================================================
        # RISULTATO
        # ====================================================

        if oggetti_modificati:

            self.report(
                {'INFO'},
                f"UV Map creata su "
                f"{len(oggetti_modificati)} oggetti."
            )

        else:

            self.report(
                {'INFO'},
                "Tutti i modelli hanno gia una UV Map."
            )


        return {'FINISHED'}


# ============================================================
# PANNELLO FABULARIS TOOLS
# ============================================================

class FABULARIS_PT_uv_tools(
    bpy.types.Panel
):

    # Nome visualizzato dentro Fabularis Tools
    bl_label = "Crea UV Mancanti"

    bl_idname = "FABULARIS_PT_uv_tools"

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = "Fabularis Tools"


    def draw(self, context):

        layout = self.layout


        # ====================================================
        # PULSANTE
        # ====================================================

        layout.operator(
            FABULARIS_OT_create_missing_uv.bl_idname,
            text="Crea UV sui Modelli Senza UV",
            icon='ADD'
        )


        layout.separator()


        # ====================================================
        # DESCRIZIONE
        # ====================================================

        layout.label(
            text="Trova automaticamente tutte",
            icon='INFO'
        )

        layout.label(
            text="le Mesh senza UV Map."
        )

        layout.label(
            text="Crea la UV solo dove manca"
        )

        layout.label(
            text="e seleziona gli oggetti modificati."
        )


# ============================================================
# CLASSI
# ============================================================

classes = (

    FABULARIS_OT_create_missing_uv,

    FABULARIS_PT_uv_tools,

)


# ============================================================
# REGISTER
# ============================================================

def register():

    for cls in classes:

        bpy.utils.register_class(cls)


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    for cls in reversed(classes):

        try:

            bpy.utils.unregister_class(cls)

        except:

            pass