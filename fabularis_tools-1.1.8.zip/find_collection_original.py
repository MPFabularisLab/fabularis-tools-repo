import bpy


# ============================================================
# FABULARIS TOOLS - TROVA COLLECTION ORIGINALE
# ============================================================


def get_collection_instance(context):

    # Oggetto cliccato/selezionato nell'Outliner
    try:
        for item in context.selected_ids:

            if (
                isinstance(item, bpy.types.Object)
                and item.instance_type == 'COLLECTION'
                and item.instance_collection is not None
            ):
                return item

    except:
        pass


    # Fallback sull'oggetto attivo
    obj = context.active_object

    if (
        obj is not None
        and obj.instance_type == 'COLLECTION'
        and obj.instance_collection is not None
    ):
        return obj


    return None


def find_layer_collection(
    layer_collection,
    collection
):

    if layer_collection.collection == collection:
        return layer_collection


    for child in layer_collection.children:

        result = find_layer_collection(
            child,
            collection
        )

        if result is not None:
            return result


    return None


def select_collection_objects(
    context,
    collection
):

    # Deseleziona gli oggetti attuali
    for obj in context.selected_objects:
        obj.select_set(False)


    selected = []


    # all_objects comprende anche le sotto-collection
    for obj in collection.all_objects:

        if obj.name not in context.view_layer.objects:
            continue

        try:
            obj.select_set(True)
            selected.append(obj)

        except:
            pass


    if selected:

        context.view_layer.objects.active = (
            selected[0]
        )


    return len(selected)


# ============================================================
# OPERATORE
# ============================================================

class FABULARIS_OT_find_original_collection(
    bpy.types.Operator
):

    bl_idname = (
        "fabularis.find_original_collection"
    )

    bl_label = (
        "Trova Collection Originale"
    )

    bl_description = (
        "Trova la Collection originale della Collection Instance "
        "e seleziona tutti gli oggetti contenuti"
    )


    def execute(
        self,
        context
    ):

        obj = get_collection_instance(
            context
        )


        if obj is None:

            self.report(
                {'ERROR'},
                "Questo oggetto non è una Collection Instance"
            )

            return {'CANCELLED'}


        collection = (
            obj.instance_collection
        )


        layer_collection = find_layer_collection(
            context.view_layer.layer_collection,
            collection
        )


        if layer_collection is None:

            self.report(
                {'ERROR'},
                (
                    f"Collection '{collection.name}' "
                    "non presente nel View Layer"
                )
            )

            return {'CANCELLED'}


        # ====================================================
        # COLLECTION ATTIVA
        # ====================================================

        context.view_layer.active_layer_collection = (
            layer_collection
        )


        # ====================================================
        # SELEZIONA TUTTO IL CONTENUTO
        # ====================================================

        selected_count = select_collection_objects(
            context,
            collection
        )


        self.report(
            {'INFO'},
            (
                f"Collection originale: "
                f"{collection.name} | "
                f"{selected_count} oggetti selezionati"
            )
        )


        return {'FINISHED'}


# ============================================================
# MENU TASTO DESTRO OUTLINER
# ============================================================

def draw_outliner_menu(
    self,
    context
):

    self.layout.separator()


    self.layout.operator(
        "fabularis.find_original_collection",
        text="Trova Collection Originale",
        icon='VIEWZOOM'
    )


# ============================================================
# CLASSI
# ============================================================

classes = (

    FABULARIS_OT_find_original_collection,

)


# ============================================================
# REGISTER
# ============================================================

def register():

    for cls in classes:

        bpy.utils.register_class(
            cls
        )


    bpy.types.OUTLINER_MT_object.append(
        draw_outliner_menu
    )


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    try:

        bpy.types.OUTLINER_MT_object.remove(
            draw_outliner_menu
        )

    except:

        pass


    for cls in reversed(
        classes
    ):

        try:

            bpy.utils.unregister_class(
                cls
            )

        except:

            pass