import bpy


# ============================================================
# FABULARIS TOOLS - MATERIAL ADD
# ============================================================


# ============================================================
# OPERATORE
# ============================================================

class FABULARIS_OT_material_add_missing(
    bpy.types.Operator
):

    bl_idname = (
        "fabularis.material_add_missing"
    )

    bl_label = (
        "Assegna Materiale"
    )

    bl_description = (
        "Assegna il materiale scelto a tutte "
        "le Mesh che non hanno materiali"
    )

    bl_options = {
        'REGISTER',
        'UNDO',
    }


    # ========================================================
    # MATERIALE
    # ========================================================

    material: bpy.props.EnumProperty(
        name="Materiale",
        description="Materiale da assegnare",

        items=lambda self, context: [

            (
                mat.name,
                mat.name,
                ""
            )

            for mat in bpy.data.materials

        ]
    )


    # ========================================================
    # EXECUTE
    # ========================================================

    def execute(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material
        )


        if material is None:

            self.report(
                {'ERROR'},
                "Materiale non trovato."
            )

            return {'CANCELLED'}


        modified_objects = []


        # ====================================================
        # DESELEZIONA TUTTO
        # ====================================================

        for obj in context.selected_objects:

            try:

                obj.select_set(
                    False
                )

            except:

                pass


        # ====================================================
        # CERCA MESH SENZA MATERIALI
        # ====================================================

        for obj in context.scene.objects:


            if obj.type != 'MESH':

                continue


            # =================================================
            # NESSUN MATERIAL SLOT
            # =================================================

            if len(obj.data.materials) == 0:


                obj.data.materials.append(
                    material
                )


                modified_objects.append(
                    obj
                )


        # ====================================================
        # SELEZIONA GLI OGGETTI MODIFICATI
        # ====================================================

        for obj in modified_objects:

            obj.select_set(
                True
            )


        # ====================================================
        # IMPOSTA ACTIVE OBJECT
        # ====================================================

        if modified_objects:

            context.view_layer.objects.active = (
                modified_objects[0]
            )


        # ====================================================
        # RISULTATO
        # ====================================================

        self.report(
            {'INFO'},
            (
                f"Materiale '{material.name}' assegnato a "
                f"{len(modified_objects)} oggetti."
            )
        )


        return {'FINISHED'}


    # ========================================================
    # POPUP
    # ========================================================

    def invoke(
        self,
        context,
        event
    ):

        if not bpy.data.materials:

            self.report(
                {'ERROR'},
                "Non ci sono materiali nel file."
            )

            return {'CANCELLED'}


        self.material = (
            bpy.data.materials[0].name
        )


        return (
            context.window_manager.invoke_props_dialog(
                self,
                width=400
            )
        )


    # ========================================================
    # UI POPUP
    # ========================================================

    def draw(
        self,
        context
    ):

        layout = self.layout


        layout.label(
            text="Materiale da assegnare:",
            icon='MATERIAL'
        )


        layout.prop(
            self,
            "material",
            text=""
        )


# ============================================================
# PANEL - MATERIAL ADD
# ============================================================

class FABULARIS_PT_material_add(
    bpy.types.Panel
):

    bl_label = (
        "Material Add"
    )

    bl_idname = (
        "FABULARIS_PT_material_add"
    )

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = (
        "Fabularis Tools"
    )


    # ========================================================
    # FIGLIO DEL GRUPPO MATERIAL
    # ========================================================

    bl_parent_id = (
        "FABULARIS_PT_material"
    )


    # ========================================================
    # DRAW
    # ========================================================

    def draw(
        self,
        context
    ):

        layout = self.layout


        layout.label(
            text="Mesh senza materiale",
            icon='MATERIAL'
        )


        layout.separator()


        layout.label(
            text="Assegna un materiale a tutte"
        )


        layout.label(
            text="le Mesh che ne sono prive."
        )


        layout.separator()


        layout.operator(
            FABULARIS_OT_material_add_missing.bl_idname,
            text="Assegna Materiale",
            icon='MATERIAL'
        )


# ============================================================
# CLASSI
# ============================================================

classes = (

    FABULARIS_OT_material_add_missing,

    FABULARIS_PT_material_add,

)


# ============================================================
# REGISTER
# ============================================================

def register():

    for cls in classes:

        bpy.utils.register_class(
            cls
        )


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    for cls in reversed(
        classes
    ):

        try:

            bpy.utils.unregister_class(
                cls
            )

        except:

            pass