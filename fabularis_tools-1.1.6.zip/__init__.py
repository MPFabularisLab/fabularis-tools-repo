bl_info = {
    "name": "Fabularis Tools",
    "author": "Fabularis Lab",
    "version": (1, 1, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Fabularis Tools",
    "description": "Raccolta di strumenti personalizzati Fabularis Lab",
    "category": "3D View",
}


from . import material_gallery
from . import material_add
from . import collection_to_empty
from . import empty_to_collection
from . import uv_tools


modules = (
    material_gallery,
    material_add,
    collection_to_empty,
    empty_to_collection,
    uv_tools,
)


def register():

    for module in modules:
        module.register()


def unregister():

    for module in reversed(modules):
        module.unregister()