import bpy
import math


# ============================================================
# FABULARIS TOOLS - MATERIAL GALLERY
# ============================================================

_MSGBUS_OWNER = object()


# ============================================================
# UTILITY
# ============================================================

def redraw_ui(context):
    if not context:
        return

    wm = getattr(context, "window_manager", None)

    if not wm:
        return

    for window in wm.windows:
        if not window.screen:
            continue

        for area in window.screen.areas:
            try:
                area.tag_redraw()
            except:
                pass


def get_material_icon(material):
    try:
        return material.preview_ensure().icon_id
    except:
        return 0


def get_filtered_materials(context):
    search = (
        context.scene.material_gallery_search
        .strip()
        .lower()
    )

    materials = sorted(
        bpy.data.materials,
        key=lambda mat: mat.name.lower()
    )

    if search:
        materials = [
            mat
            for mat in materials
            if search in mat.name.lower()
        ]

    return materials


def get_gallery_layout(context):
    size = context.scene.material_gallery_size

    region_width = max(
        180,
        context.region.width
    )

    card_width = 58 + size * 17

    columns = max(
        1,
        min(
            int(region_width / card_width),
            10
        )
    )

    if size >= 9:
        rows = 2

    elif size >= 7:
        rows = 3

    elif size >= 5:
        rows = 4

    elif size >= 3:
        rows = 5

    else:
        rows = 6

    per_page = max(
        1,
        columns * rows
    )

    return (
        columns,
        rows,
        per_page
    )


def get_gallery_item(
    scene,
    material_name
):
    for item in scene.material_gallery_list:

        if item.material_name == material_name:
            return item

    return None


def get_multi_selected_names(scene):
    return [
        item.material_name
        for item in scene.material_gallery_list
        if item.selected
    ]


def get_multi_selected_materials(scene):
    result = []

    for name in get_multi_selected_names(scene):

        material = bpy.data.materials.get(
            name
        )

        if material is not None:
            result.append(
                material
            )

    return result


# ============================================================
# APPLICA MATERIALE
# ============================================================

def apply_material(
    material,
    context
):
    modified = 0

    for obj in context.selected_objects:

        if obj.type != 'MESH':
            continue

        if len(obj.data.materials) == 0:

            obj.data.materials.append(
                material
            )

        else:

            slot = obj.active_material_index

            if slot >= len(obj.data.materials):
                slot = 0

            obj.data.materials[
                slot
            ] = material

        modified += 1

    return modified


# ============================================================
# APRI MATERIALE NELLE PROPERTIES / SHADER
# ============================================================

def focus_material_in_blender(
    context,
    material
):
    if material is None:
        return False

    found = False

    for window in context.window_manager.windows:

        screen = window.screen

        if screen is None:
            continue

        for area in screen.areas:

            # =================================================
            # MATERIAL PROPERTIES
            # =================================================

            if area.type == 'PROPERTIES':

                try:
                    space = area.spaces.active

                    space.pin_id = material
                    space.use_pin_id = True
                    space.context = 'MATERIAL'

                    found = True

                except Exception as error:

                    print(
                        "Fabularis Material Gallery - Properties:",
                        error
                    )

            # =================================================
            # SHADER EDITOR
            # =================================================

            elif area.type == 'NODE_EDITOR':

                try:
                    space = area.spaces.active

                    if (
                        space.tree_type == 'ShaderNodeTree'
                        and
                        material.use_nodes
                        and
                        material.node_tree is not None
                    ):

                        space.shader_type = 'OBJECT'

                        space.pin = False
                        space.node_tree = material.node_tree
                        space.pin = True

                        found = True

                except Exception as error:

                    print(
                        "Fabularis Material Gallery - Shader:",
                        error
                    )

            try:
                area.tag_redraw()
            except:
                pass

    return found


# ============================================================
# RIPRISTINA PROPERTIES QUANDO CAMBIA OGGETTO
# ============================================================

def restore_normal_properties():

    wm = bpy.context.window_manager

    if wm is None:
        return


    for window in wm.windows:

        screen = window.screen

        if screen is None:
            continue


        for area in screen.areas:


            # =================================================
            # PROPERTIES
            # =================================================

            if area.type == 'PROPERTIES':

                try:

                    space = area.spaces.active


                    # =========================================
                    # TOGLIE SEMPRE IL PIN
                    # =========================================

                    space.use_pin_id = False


                    # =========================================
                    # ELIMINA IL DATABLOCK PINNATO
                    # =========================================

                    try:

                        space.pin_id = None

                    except:

                        pass


                    # =========================================
                    # TORNA ALLE PROPERTIES DELL'OGGETTO
                    # =========================================

                    try:

                        space.context = 'OBJECT'

                    except:

                        pass


                    area.tag_redraw()


                except Exception as error:

                    print(
                        "Fabularis Material Gallery - "
                        "Restore Properties:",
                        error
                    )


            # =================================================
            # SHADER EDITOR
            # =================================================

            elif area.type == 'NODE_EDITOR':

                try:

                    space = area.spaces.active


                    if (
                        space.tree_type
                        ==
                        'ShaderNodeTree'
                    ):

                        space.pin = False

                        space.shader_type = 'OBJECT'

                        area.tag_redraw()


                except Exception as error:

                    print(
                        "Fabularis Material Gallery - "
                        "Restore Shader:",
                        error
                    )


    try:

        bpy.context.view_layer.update()

    except:

        pass


    redraw_ui(
        bpy.context
    )


# ============================================================
# CAMBIO OGGETTO ATTIVO
# ============================================================

def active_object_changed():

    restore_normal_properties()


# ============================================================
# MSGBUS
# ============================================================

def register_msgbus():

    try:

        bpy.msgbus.clear_by_owner(
            _MSGBUS_OWNER
        )

    except:

        pass


    bpy.msgbus.subscribe_rna(

        key=(
            bpy.types.LayerObjects,
            "active"
        ),

        owner=_MSGBUS_OWNER,

        args=(),

        notify=active_object_changed,

        options={
            'PERSISTENT'
        }

    )


def unregister_msgbus():

    try:

        bpy.msgbus.clear_by_owner(
            _MSGBUS_OWNER
        )

    except:

        pass


# ============================================================
# CALLBACK
# ============================================================

def gallery_updated(
    self,
    context
):
    if not context:
        return

    context.scene.material_gallery_page = 0

    refresh_material_list(
        context
    )

    redraw_ui(
        context
    )


# ============================================================
# LIST ITEM
# ============================================================

class MATERIALGALLERY_PG_list_item(
    bpy.types.PropertyGroup
):

    material_name: bpy.props.StringProperty()

    selected: bpy.props.BoolProperty(
        name="Selezionato",
        default=False
    )


# ============================================================
# REFRESH LISTA
# ============================================================

def refresh_material_list(context):
    if not context:
        return

    scene = context.scene

    materials = get_filtered_materials(
        context
    )

    selected_names = {
        item.material_name
        for item in scene.material_gallery_list
        if item.selected
    }

    current_names = [
        item.material_name
        for item in scene.material_gallery_list
    ]

    new_names = [
        material.name
        for material in materials
    ]

    if current_names == new_names:
        return

    scene.material_gallery_list.clear()

    for material in materials:

        item = scene.material_gallery_list.add()

        item.material_name = material.name

        item.selected = (
            material.name
            in
            selected_names
        )

    if (
        scene.material_gallery_list_index
        >=
        len(scene.material_gallery_list)
    ):

        scene.material_gallery_list_index = max(
            0,
            len(scene.material_gallery_list) - 1
        )


# ============================================================
# UI LIST MATERIALI
# ============================================================

class MATERIALGALLERY_UL_materials(
    bpy.types.UIList
):

    def draw_item(
        self,
        context,
        layout,
        data,
        item,
        icon,
        active_data,
        active_propname,
        index
    ):

        material = bpy.data.materials.get(
            item.material_name
        )

        if material is None:
            return

        row = layout.row(
            align=True
        )

        if context.scene.material_multi_mode:

            row.prop(
                item,
                "selected",
                text=""
            )

        op = row.operator(
            "material_gallery.select_material",
            text=material.name,
            icon_value=get_material_icon(
                material
            )
        )

        op.material_name = material.name

        actions = row.operator(
            "material_gallery.material_actions",
            text="",
            icon='DOWNARROW_HLT'
        )

        actions.material_name = (
            material.name
        )


# ============================================================
# UI LIST REMAP
# ============================================================

class MATERIALGALLERY_UL_remap_materials(
    bpy.types.UIList
):

    def filter_items(
        self,
        context,
        data,
        propname
    ):

        collection = getattr(
            data,
            propname
        )

        search = (
            context.scene.material_remap_search
            .strip()
            .lower()
        )

        if not search:

            return (
                [
                    self.bitflag_filter_item
                    for _ in collection
                ],
                []
            )

        flags = [
            self.bitflag_filter_item
            if search in item.material_name.lower()
            else 0
            for item in collection
        ]

        return (
            flags,
            []
        )


    def draw_item(
        self,
        context,
        layout,
        data,
        item,
        icon,
        active_data,
        active_propname,
        index
    ):

        material = bpy.data.materials.get(
            item.material_name
        )

        if material is None:
            return

        row = layout.row(
            align=True
        )

        row.label(
            text=material.name,
            icon_value=get_material_icon(
                material
            )
        )

        row.label(
            text=f"Users: {material.users}"
        )


# ============================================================
# APRI MATERIALE
# ============================================================

class MATERIALGALLERY_OT_select_material(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.select_material"
    )

    bl_label = (
        "Apri Materiale"
    )

    material_name: bpy.props.StringProperty()


    def execute(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        context.scene.material_gallery_selected = (
            material.name
        )

        focus_material_in_blender(
            context,
            material
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# MENU AZIONI
# ============================================================

class MATERIALGALLERY_OT_material_actions(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.material_actions"
    )

    bl_label = (
        "Azioni Materiale"
    )

    material_name: bpy.props.StringProperty()


    def invoke(
        self,
        context,
        event
    ):

        if not bpy.data.materials.get(
            self.material_name
        ):
            return {'CANCELLED'}

        material_name = (
            self.material_name
        )


        def draw_menu(
            menu,
            popup_context
        ):

            layout = menu.layout

            material = bpy.data.materials.get(
                material_name
            )

            if material:

                layout.label(
                    text=material.name,
                    icon_value=get_material_icon(
                        material
                    )
                )

                layout.label(
                    text=f"Users: {material.users}"
                )

                layout.separator()

            layout.operator_context = (
                'INVOKE_DEFAULT'
            )

            rename = layout.operator(
                "material_gallery.rename_material",
                text="Rinomina materiale...",
                icon='SORTALPHA'
            )

            rename.material_name = (
                material_name
            )

            delete = layout.operator(
                "material_gallery.delete_material",
                text="Elimina materiale...",
                icon='TRASH'
            )

            delete.material_name = (
                material_name
            )


        context.window_manager.popup_menu(
            draw_menu,
            title="Materiale",
            icon='MATERIAL'
        )

        return {'FINISHED'}


# ============================================================
# RINOMINA
# ============================================================

class MATERIALGALLERY_OT_rename_material(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.rename_material"
    )

    bl_label = (
        "Rinomina Materiale"
    )

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    material_name: bpy.props.StringProperty()

    new_name: bpy.props.StringProperty(
        name="Nuovo nome",
        default=""
    )


    def invoke(
        self,
        context,
        event
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        self.new_name = (
            material.name
        )

        return (
            context.window_manager
            .invoke_props_dialog(
                self,
                width=420
            )
        )


    def draw(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material:

            box = self.layout.box()

            row = box.row()

            icon_id = get_material_icon(
                material
            )

            if icon_id:

                row.template_icon(
                    icon_value=icon_id,
                    scale=3
                )

            column = row.column()

            column.label(
                text="Materiale da rinominare:"
            )

            column.label(
                text=material.name,
                icon='MATERIAL'
            )

            column.label(
                text=f"Users: {material.users}"
            )

        self.layout.separator()

        self.layout.prop(
            self,
            "new_name",
            text="Nuovo nome"
        )


    def execute(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        new_name = (
            self.new_name.strip()
        )

        if not new_name:

            self.report(
                {'ERROR'},
                "Il nome non può essere vuoto"
            )

            return {'CANCELLED'}

        old_name = (
            material.name
        )

        was_selected = (
            context.scene.material_gallery_selected
            ==
            old_name
        )

        material.name = (
            new_name
        )

        new_name = (
            material.name
        )

        for item in (
            context.scene.material_gallery_list
        ):

            if item.material_name == old_name:

                item.material_name = (
                    new_name
                )

        for item in (
            context.scene.material_remap_list
        ):

            if item.material_name == old_name:

                item.material_name = (
                    new_name
                )

        if was_selected:

            context.scene.material_gallery_selected = (
                new_name
            )

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# ELIMINA
# ============================================================

class MATERIALGALLERY_OT_delete_material(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.delete_material"
    )

    bl_label = (
        "Elimina Materiale"
    )

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    material_name: bpy.props.StringProperty()


    def invoke(
        self,
        context,
        event
    ):

        if not bpy.data.materials.get(
            self.material_name
        ):
            return {'CANCELLED'}

        return (
            context.window_manager
            .invoke_props_dialog(
                self,
                width=440
            )
        )


    def draw(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return

        box = self.layout.box()

        box.alert = (
            True
        )

        box.label(
            text="ELIMINA MATERIALE",
            icon='ERROR'
        )

        box.separator()

        row = box.row()

        icon_id = get_material_icon(
            material
        )

        if icon_id:

            row.template_icon(
                icon_value=icon_id,
                scale=3
            )

        column = row.column()

        column.alert = (
            True
        )

        column.label(
            text=material.name,
            icon='MATERIAL'
        )

        column.label(
            text=f"Users: {material.users}"
        )

        self.layout.separator()

        warning = (
            self.layout.row()
        )

        warning.alert = (
            True
        )

        warning.label(
            text=(
                "Il materiale verrà rimosso anche "
                "dagli oggetti che lo utilizzano."
            ),
            icon='ERROR'
        )


    def execute(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        if (
            context.scene.material_gallery_selected
            ==
            material.name
        ):

            context.scene.material_gallery_selected = (
                ""
            )

        bpy.data.materials.remove(
            material,
            do_unlink=True
        )

        refresh_material_list(
            context
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# MULTI SELECT
# ============================================================

class MATERIALGALLERY_OT_select_visible(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.select_visible"
    )

    bl_label = (
        "Seleziona / Deseleziona"
    )

    select_state: bpy.props.BoolProperty(
        default=True
    )

    page: bpy.props.IntProperty(
        default=0
    )

    per_page: bpy.props.IntProperty(
        default=1,
        min=1
    )


    def execute(
        self,
        context
    ):

        scene = context.scene

        refresh_material_list(
            context
        )

        if (
            scene.material_gallery_mode
            ==
            'GALLERY'
        ):

            materials = get_filtered_materials(
                context
            )

            start = (
                self.page
                *
                self.per_page
            )

            end = (
                start
                +
                self.per_page
            )

            names = {
                material.name
                for material
                in materials[start:end]
            }

        else:

            names = {
                item.material_name
                for item
                in scene.material_gallery_list
            }

        for item in (
            scene.material_gallery_list
        ):

            if item.material_name in names:

                item.selected = (
                    self.select_state
                )

        redraw_ui(
            context
        )

        return {'FINISHED'}


class MATERIALGALLERY_OT_clear_multi(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.clear_multi"
    )

    bl_label = (
        "Deseleziona tutto"
    )


    def execute(
        self,
        context
    ):

        for item in (
            context.scene.material_gallery_list
        ):

            item.selected = False

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# APPLY
# ============================================================

class MATERIALGALLERY_OT_apply_material(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.apply_material"
    )

    bl_label = (
        "Applica Materiale"
    )

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    material_name: bpy.props.StringProperty()


    def execute(
        self,
        context
    ):

        material = bpy.data.materials.get(
            self.material_name
        )

        if material is None:
            return {'CANCELLED'}

        context.scene.material_gallery_selected = (
            material.name
        )

        modified = apply_material(
            material,
            context
        )

        self.report(
            {'INFO'},
            (
                f"{material.name} applicato a "
                f"{modified} oggetti"
            )
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# PAGINE
# ============================================================

class MATERIALGALLERY_OT_page_previous(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.page_previous"
    )

    bl_label = (
        "Pagina precedente"
    )

    current_page: bpy.props.IntProperty(
        default=0
    )


    def execute(
        self,
        context
    ):

        context.scene.material_gallery_page = max(
            0,
            self.current_page - 1
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


class MATERIALGALLERY_OT_page_next(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.page_next"
    )

    bl_label = (
        "Pagina successiva"
    )

    current_page: bpy.props.IntProperty(
        default=0
    )

    total_pages: bpy.props.IntProperty(
        default=1,
        min=1
    )


    def execute(
        self,
        context
    ):

        context.scene.material_gallery_page = min(
            self.current_page + 1,
            self.total_pages - 1
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# REMAP UTILITY
# ============================================================

def build_remap_target_list(
    context,
    excluded_names
):

    scene = context.scene

    scene.material_remap_list.clear()

    materials = sorted(
        [
            material
            for material
            in bpy.data.materials
            if material.name not in excluded_names
        ],
        key=lambda mat: mat.name.lower()
    )

    for material in materials:

        item = (
            scene.material_remap_list.add()
        )

        item.material_name = (
            material.name
        )

    scene.material_remap_index = (
        0
    )


def get_current_remap_target(context):

    scene = context.scene

    index = (
        scene.material_remap_index
    )

    if not (
        0
        <= index
        <
        len(scene.material_remap_list)
    ):

        return None

    return bpy.data.materials.get(
        scene.material_remap_list[
            index
        ].material_name
    )


# ============================================================
# REMAP SINGOLO
# ============================================================

class MATERIALGALLERY_OT_remap_users(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.remap_users"
    )

    bl_label = (
        "Remap Material Users"
    )

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    source_material: bpy.props.StringProperty()

    remove_source: bpy.props.BoolProperty(
        name="Elimina materiale originale",
        default=False
    )


    def invoke(
        self,
        context,
        event
    ):

        if not self.source_material:

            self.source_material = (
                context.scene.material_gallery_selected
            )

        source = bpy.data.materials.get(
            self.source_material
        )

        if source is None:

            self.report(
                {'ERROR'},
                "Seleziona prima un materiale"
            )

            return {'CANCELLED'}

        context.scene.material_remap_search = ""

        build_remap_target_list(
            context,
            {
                source.name
            }
        )

        if len(
            context.scene.material_remap_list
        ) == 0:

            self.report(
                {'ERROR'},
                "Nessun materiale di destinazione disponibile"
            )

            return {'CANCELLED'}

        return (
            context.window_manager
            .invoke_props_dialog(
                self,
                width=520
            )
        )


    def draw(
        self,
        context
    ):

        layout = self.layout

        source = bpy.data.materials.get(
            self.source_material
        )

        if source is None:
            return

        # ====================================================
        # SORGENTE
        # ====================================================

        source_box = layout.box()

        source_box.alert = True

        source_box.label(
            text="MATERIALE DA CAMBIARE (sorgente)",
            icon='ERROR'
        )

        source_box.separator()

        row = source_box.row()

        icon_id = get_material_icon(
            source
        )

        if icon_id:

            row.template_icon(
                icon_value=icon_id,
                scale=4
            )

        column = row.column()

        column.label(
            text=source.name,
            icon='MATERIAL'
        )

        column.label(
            text=f"Users: {source.users}"
        )

        # ====================================================
        # FRECCIA
        # ====================================================

        layout.separator()

        arrow = layout.row()

        arrow.alignment = 'CENTER'

        arrow.label(
            text="",
            icon='TRIA_DOWN'
        )

        # ====================================================
        # DESTINAZIONE
        # ====================================================

        destination_box = layout.box()

        destination_box.label(
            text="SOSTITUISCI CON (destinazione)",
            icon='ADD'
        )

        destination_box.separator()

        destination_box.prop(
            context.scene,
            "material_remap_search",
            text="",
            icon='VIEWZOOM'
        )

        destination_box.separator()

        destination_box.template_list(
            "MATERIALGALLERY_UL_remap_materials",
            "",
            context.scene,
            "material_remap_list",
            context.scene,
            "material_remap_index",
            rows=8
        )

        target = get_current_remap_target(
            context
        )

        # ====================================================
        # DESTINAZIONE SELEZIONATA
        # ====================================================

        if target:

            layout.separator()

            arrow = layout.row()

            arrow.alignment = 'CENTER'

            arrow.label(
                text="",
                icon='TRIA_DOWN'
            )

            target_box = layout.box()

            target_box.label(
                text=(
                    "MATERIALE DI DESTINAZIONE "
                    "SELEZIONATO"
                ),
                icon='CHECKMARK'
            )

            target_box.separator()

            row = target_box.row()

            icon_id = get_material_icon(
                target
            )

            if icon_id:

                row.template_icon(
                    icon_value=icon_id,
                    scale=4
                )

            column = row.column()

            column.label(
                text=target.name,
                icon='MATERIAL'
            )

            column.label(
                text=f"Users: {target.users}"
            )

        layout.separator()

        remove_box = layout.box()

        remove_box.prop(
            self,
            "remove_source"
        )


    def execute(
        self,
        context
    ):

        source = bpy.data.materials.get(
            self.source_material
        )

        target = get_current_remap_target(
            context
        )

        if (
            source is None
            or
            target is None
        ):

            return {'CANCELLED'}

        source_name = (
            source.name
        )

        target_name = (
            target.name
        )

        source.user_remap(
            target
        )

        if (
            self.remove_source
            and
            source.users == 0
        ):

            bpy.data.materials.remove(
                source
            )

        context.scene.material_gallery_selected = (
            target_name
        )

        refresh_material_list(
            context
        )

        redraw_ui(
            context
        )

        self.report(
            {'INFO'},
            (
                f"{source_name} -> "
                f"{target_name}"
            )
        )

        return {'FINISHED'}


# ============================================================
# MULTI REMAP
# ============================================================

class MATERIALGALLERY_OT_multi_remap_users(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.multi_remap_users"
    )

    bl_label = (
        "Multi Remap Material Users"
    )

    bl_options = {
        'REGISTER',
        'UNDO'
    }

    remove_sources: bpy.props.BoolProperty(
        name="Elimina materiali originali",
        default=False
    )


    def invoke(
        self,
        context,
        event
    ):

        refresh_material_list(
            context
        )

        selected_names = (
            get_multi_selected_names(
                context.scene
            )
        )

        if not selected_names:

            self.report(
                {'ERROR'},
                "Seleziona almeno un materiale"
            )

            return {'CANCELLED'}

        context.scene.material_remap_search = ""

        build_remap_target_list(
            context,
            set(
                selected_names
            )
        )

        if len(
            context.scene.material_remap_list
        ) == 0:

            self.report(
                {'ERROR'},
                "Nessun materiale di destinazione disponibile"
            )

            return {'CANCELLED'}

        return (
            context.window_manager
            .invoke_props_dialog(
                self,
                width=540
            )
        )


    def draw(
        self,
        context
    ):

        layout = self.layout

        sources = get_multi_selected_materials(
            context.scene
        )

        # ====================================================
        # SORGENTI
        # ====================================================

        source_box = layout.box()

        source_box.alert = True

        source_box.label(
            text=(
                f"MATERIALI DA CAMBIARE "
                f"({len(sources)} selezionati)"
            ),
            icon='ERROR'
        )

        source_box.separator()

        for material in sources[:8]:

            row = source_box.row(
                align=True
            )

            row.label(
                text=material.name,
                icon_value=get_material_icon(
                    material
                )
            )

            row.label(
                text=f"Users: {material.users}"
            )

        if len(sources) > 8:

            source_box.label(
                text=(
                    f"...e altri "
                    f"{len(sources) - 8} materiali"
                )
            )

        # ====================================================
        # FRECCIA
        # ====================================================

        layout.separator()

        arrow = layout.row()

        arrow.alignment = 'CENTER'

        arrow.label(
            text="",
            icon='TRIA_DOWN'
        )

        # ====================================================
        # TARGET
        # ====================================================

        target_box = layout.box()

        target_box.label(
            text="SOSTITUISCI TUTTI CON",
            icon='ADD'
        )

        target_box.separator()

        target_box.prop(
            context.scene,
            "material_remap_search",
            text="",
            icon='VIEWZOOM'
        )

        target_box.separator()

        target_box.template_list(
            "MATERIALGALLERY_UL_remap_materials",
            "multi_remap",
            context.scene,
            "material_remap_list",
            context.scene,
            "material_remap_index",
            rows=8
        )

        target = get_current_remap_target(
            context
        )

        # ====================================================
        # TARGET SELEZIONATO
        # ====================================================

        if target:

            layout.separator()

            arrow = layout.row()

            arrow.alignment = 'CENTER'

            arrow.label(
                text="",
                icon='TRIA_DOWN'
            )

            selected_box = layout.box()

            selected_box.label(
                text=(
                    "MATERIALE DI DESTINAZIONE "
                    "SELEZIONATO"
                ),
                icon='CHECKMARK'
            )

            selected_box.separator()

            row = selected_box.row()

            icon_id = get_material_icon(
                target
            )

            if icon_id:

                row.template_icon(
                    icon_value=icon_id,
                    scale=4
                )

            column = row.column()

            column.label(
                text=target.name,
                icon='MATERIAL'
            )

            column.label(
                text=f"Users: {target.users}"
            )

        layout.separator()

        remove_box = layout.box()

        remove_box.prop(
            self,
            "remove_sources"
        )


    def execute(
        self,
        context
    ):

        sources = get_multi_selected_materials(
            context.scene
        )

        target = get_current_remap_target(
            context
        )

        if (
            not sources
            or
            target is None
        ):

            return {'CANCELLED'}

        target_name = (
            target.name
        )

        source_names = [
            source.name
            for source in sources
        ]

        for source in sources:

            if source != target:

                source.user_remap(
                    target
                )

        if self.remove_sources:

            for name in source_names:

                source = bpy.data.materials.get(
                    name
                )

                if (
                    source is not None
                    and
                    source != target
                    and
                    source.users == 0
                ):

                    bpy.data.materials.remove(
                        source
                    )

        for item in (
            context.scene.material_gallery_list
        ):

            item.selected = False

        context.scene.material_gallery_selected = (
            target_name
        )

        refresh_material_list(
            context
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# REFRESH
# ============================================================

class MATERIALGALLERY_OT_refresh(
    bpy.types.Operator
):

    bl_idname = (
        "material_gallery.refresh"
    )

    bl_label = (
        "Aggiorna"
    )


    def execute(
        self,
        context
    ):

        for material in bpy.data.materials:

            try:
                material.preview_ensure()
            except:
                pass

        context.scene.material_gallery_page = 0

        refresh_material_list(
            context
        )

        redraw_ui(
            context
        )

        return {'FINISHED'}


# ============================================================
# PANEL MATERIAL
# ============================================================

class FABULARIS_PT_material(
    bpy.types.Panel
):

    bl_label = "Material"

    bl_idname = (
        "FABULARIS_PT_material"
    )

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = (
        "Fabularis Tools"
    )


    def draw(
        self,
        context
    ):

        pass


# ============================================================
# MATERIAL GALLERY PANEL
# ============================================================

class MATERIALGALLERY_PT_panel(
    bpy.types.Panel
):

    bl_label = (
        "Material Gallery"
    )

    bl_idname = (
        "MATERIALGALLERY_PT_panel"
    )

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = (
        "Fabularis Tools"
    )

    bl_parent_id = (
        "FABULARIS_PT_material"
    )


    def draw(
        self,
        context
    ):

        layout = self.layout

        scene = context.scene


        # ====================================================
        # SEARCH
        # ====================================================

        row = layout.row(
            align=True
        )

        row.prop(
            scene,
            "material_gallery_search",
            text="",
            icon='VIEWZOOM'
        )

        row.operator(
            "material_gallery.refresh",
            text="",
            icon='FILE_REFRESH'
        )


        # ====================================================
        # GALLERY / LIST
        # ====================================================

        layout.separator()

        layout.prop(
            scene,
            "material_gallery_mode",
            expand=True
        )

        materials = get_filtered_materials(
            context
        )

        layout.label(
            text=f"{len(materials)} materiali",
            icon='MATERIAL'
        )


        # ====================================================
        # CALCOLO PAGINAZIONE
        # ====================================================

        columns = 1
        rows = 1
        per_page = 1
        total_pages = 1
        current_page = 0

        if (
            scene.material_gallery_mode
            ==
            'GALLERY'
        ):

            (
                columns,
                rows,
                per_page
            ) = get_gallery_layout(
                context
            )

            total_pages = max(
                1,
                math.ceil(
                    len(materials)
                    /
                    per_page
                )
            )

            current_page = min(
                scene.material_gallery_page,
                total_pages - 1
            )


        # ====================================================
        # MULTI REMAP
        # ====================================================

        layout.separator()

        layout.prop(
            scene,
            "material_multi_mode",
            text="Multi Remap",
            toggle=True,
            icon='CHECKBOX_HLT'
        )

        if scene.material_multi_mode:

            selected_count = len(
                get_multi_selected_names(
                    scene
                )
            )

            row = layout.row(
                align=True
            )

            row.label(
                text=(
                    f"{selected_count} "
                    f"materiali selezionati"
                )
            )

            row.operator(
                "material_gallery.clear_multi",
                text="",
                icon='X'
            )

            row = layout.row(
                align=True
            )

            select_op = row.operator(
                "material_gallery.select_visible",
                text=(
                    "Seleziona pagina"
                    if
                    scene.material_gallery_mode
                    ==
                    'GALLERY'
                    else
                    "Seleziona lista"
                ),
                icon='CHECKBOX_HLT'
            )

            select_op.select_state = True
            select_op.page = current_page
            select_op.per_page = per_page

            deselect_op = row.operator(
                "material_gallery.select_visible",
                text=(
                    "Deseleziona pagina"
                    if
                    scene.material_gallery_mode
                    ==
                    'GALLERY'
                    else
                    "Deseleziona lista"
                ),
                icon='CHECKBOX_DEHLT'
            )

            deselect_op.select_state = False
            deselect_op.page = current_page
            deselect_op.per_page = per_page


        # ====================================================
        # GALLERY
        # ====================================================

        if (
            scene.material_gallery_mode
            ==
            'GALLERY'
        ):

            layout.separator()

            layout.label(
                text="Dimensione Preview"
            )

            layout.prop(
                scene,
                "material_gallery_size",
                text="",
                slider=True
            )

            info = layout.row()

            info.enabled = False

            info.label(
                text=(
                    f"{columns} colonne  |  "
                    f"{rows} righe  |  "
                    f"{per_page} per pagina"
                )
            )

            start = (
                current_page
                *
                per_page
            )

            end = (
                start
                +
                per_page
            )

            grid = layout.grid_flow(
                row_major=True,
                columns=columns,
                even_columns=True,
                even_rows=False,
                align=True
            )

            for material in materials[start:end]:

                box = grid.box()

                icon_id = get_material_icon(
                    material
                )

                item = get_gallery_item(
                    scene,
                    material.name
                )

                # ============================================
                # HEADER
                # ============================================

                name_row = box.row(
                    align=True
                )

                if (
                    scene.material_multi_mode
                    and
                    item is not None
                ):

                    name_row.prop(
                        item,
                        "selected",
                        text=""
                    )

                op = name_row.operator(
                    "material_gallery.select_material",
                    text=material.name,
                    emboss=False
                )

                op.material_name = (
                    material.name
                )

                actions = name_row.operator(
                    "material_gallery.material_actions",
                    text="",
                    icon='DOWNARROW_HLT'
                )

                actions.material_name = (
                    material.name
                )


                # ============================================
                # PREVIEW
                # ============================================

                if icon_id:

                    preview_row = box.row()

                    preview_row.alignment = (
                        'CENTER'
                    )

                    preview_row.template_icon(
                        icon_value=icon_id,
                        scale=(
                            1.4
                            +
                            scene.material_gallery_size
                            *
                            0.50
                        )
                    )


                # ============================================
                # USERS
                # ============================================

                users = box.row()

                users.enabled = False

                users.label(
                    text=f"Users: {material.users}"
                )


                # ============================================
                # APPLICA
                # ============================================

                apply_button = box.operator(
                    "material_gallery.apply_material",
                    text="Applica",
                    icon='CHECKMARK'
                )

                apply_button.material_name = (
                    material.name
                )


            # =================================================
            # PAGINAZIONE
            # =================================================

            layout.separator()

            row = layout.row(
                align=True
            )

            previous = row.operator(
                "material_gallery.page_previous",
                text="",
                icon='TRIA_LEFT'
            )

            previous.current_page = (
                current_page
            )

            row.label(
                text=(
                    f"Pagina "
                    f"{current_page + 1}"
                    f" / "
                    f"{total_pages}"
                )
            )

            next_page = row.operator(
                "material_gallery.page_next",
                text="",
                icon='TRIA_RIGHT'
            )

            next_page.current_page = (
                current_page
            )

            next_page.total_pages = (
                total_pages
            )


        # ====================================================
        # LISTA
        # ====================================================

        else:

            layout.separator()

            layout.template_list(
                "MATERIALGALLERY_UL_materials",
                "",
                scene,
                "material_gallery_list",
                scene,
                "material_gallery_list_index",
                rows=8
            )


        # ====================================================
        # REMAP BUTTON
        # ====================================================

        layout.separator()

        if scene.material_multi_mode:

            selected_count = len(
                get_multi_selected_names(
                    scene
                )
            )

            row = layout.row()

            row.enabled = (
                selected_count > 0
            )

            row.operator(
                "material_gallery.multi_remap_users",
                text=(
                    f"Remap selezionati... "
                    f"({selected_count})"
                ),
                icon='FILE_REFRESH'
            )

        else:

            selected = bpy.data.materials.get(
                scene.material_gallery_selected
            )

            if selected:

                op = layout.operator(
                    "material_gallery.remap_users",
                    text="Remap Users...",
                    icon='FILE_REFRESH'
                )

                op.source_material = (
                    selected.name
                )

            else:

                row = layout.row()

                row.enabled = False

                row.operator(
                    "material_gallery.remap_users",
                    text="Remap Users...",
                    icon='FILE_REFRESH'
                )


        # ====================================================
        # MATERIALE SELEZIONATO
        # ====================================================

        selected = bpy.data.materials.get(
            scene.material_gallery_selected
        )

        if selected:

            layout.separator()

            box = layout.box()

            row = box.row()

            icon_id = get_material_icon(
                selected
            )

            if icon_id:

                row.template_icon(
                    icon_value=icon_id,
                    scale=2
                )

            column = row.column()

            column.label(
                text=selected.name
            )

            column.label(
                text=f"Users: {selected.users}"
            )


# ============================================================
# CLASSI
# ============================================================

classes = (

    MATERIALGALLERY_PG_list_item,

    MATERIALGALLERY_UL_materials,
    MATERIALGALLERY_UL_remap_materials,

    MATERIALGALLERY_OT_select_material,

    MATERIALGALLERY_OT_material_actions,
    MATERIALGALLERY_OT_rename_material,
    MATERIALGALLERY_OT_delete_material,

    MATERIALGALLERY_OT_select_visible,
    MATERIALGALLERY_OT_clear_multi,

    MATERIALGALLERY_OT_apply_material,

    MATERIALGALLERY_OT_page_previous,
    MATERIALGALLERY_OT_page_next,

    MATERIALGALLERY_OT_remap_users,
    MATERIALGALLERY_OT_multi_remap_users,

    MATERIALGALLERY_OT_refresh,

    FABULARIS_PT_material,
    MATERIALGALLERY_PT_panel,

)


# ============================================================
# REGISTER
# ============================================================

def register():

    for cls in classes:

        bpy.utils.register_class(
            cls
        )


    bpy.types.Scene.material_gallery_search = (
        bpy.props.StringProperty(
            name="Search",
            default="",
            update=gallery_updated
        )
    )


    bpy.types.Scene.material_gallery_mode = (
        bpy.props.EnumProperty(
            name="Visualizzazione",
            items=[
                (
                    'GALLERY',
                    "Gallery",
                    "Gallery responsive"
                ),
                (
                    'LIST',
                    "Lista",
                    "Lista interna scrollabile"
                ),
            ],
            default='GALLERY'
        )
    )


    bpy.types.Scene.material_gallery_selected = (
        bpy.props.StringProperty(
            name="Materiale selezionato",
            default=""
        )
    )


    bpy.types.Scene.material_gallery_size = (
        bpy.props.IntProperty(
            name="Dimensione Preview",
            default=7,
            min=1,
            max=10,
            update=gallery_updated
        )
    )


    bpy.types.Scene.material_gallery_page = (
        bpy.props.IntProperty(
            default=0,
            min=0
        )
    )


    bpy.types.Scene.material_multi_mode = (
        bpy.props.BoolProperty(
            name="Multi Remap",
            description=(
                "Permette di selezionare "
                "più materiali e rimapparli "
                "verso un unico materiale"
            ),
            default=False
        )
    )


    bpy.types.Scene.material_gallery_list = (
        bpy.props.CollectionProperty(
            type=MATERIALGALLERY_PG_list_item
        )
    )


    bpy.types.Scene.material_gallery_list_index = (
        bpy.props.IntProperty(
            default=0
        )
    )


    bpy.types.Scene.material_remap_list = (
        bpy.props.CollectionProperty(
            type=MATERIALGALLERY_PG_list_item
        )
    )


    bpy.types.Scene.material_remap_index = (
        bpy.props.IntProperty(
            default=0
        )
    )


    bpy.types.Scene.material_remap_search = (
        bpy.props.StringProperty(
            name="Cerca materiale",
            default=""
        )
    )


    # ========================================================
    # AUTO UNPIN CAMBIO OGGETTO
    # ========================================================

    register_msgbus()


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    unregister_msgbus()


    try:

        restore_normal_properties()

    except:

        pass


    properties = (

        "material_remap_search",

        "material_remap_index",

        "material_remap_list",

        "material_gallery_list_index",

        "material_gallery_list",

        "material_multi_mode",

        "material_gallery_page",

        "material_gallery_size",

        "material_gallery_selected",

        "material_gallery_mode",

        "material_gallery_search",

    )


    for prop in properties:

        if hasattr(
            bpy.types.Scene,
            prop
        ):

            delattr(
                bpy.types.Scene,
                prop
            )


    for cls in reversed(
        classes
    ):

        try:

            bpy.utils.unregister_class(
                cls
            )

        except:

            pass