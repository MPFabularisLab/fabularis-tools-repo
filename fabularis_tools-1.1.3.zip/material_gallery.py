import bpy
import math


# ============================================================
# FABULARIS TOOLS - MATERIAL GALLERY
# ============================================================


# ============================================================
# UTILITY
# ============================================================

def redraw_ui(context):

    if context is None:
        return

    window_manager = getattr(
        context,
        "window_manager",
        None
    )

    if window_manager is None:
        return

    for window in window_manager.windows:

        screen = window.screen

        if screen is None:
            continue

        for area in screen.areas:

            try:
                area.tag_redraw()

            except:
                pass


def get_material_icon(material):

    try:

        return material.preview_ensure().icon_id

    except:

        return 0


def get_filtered_materials(context):

    search = (
        context.scene.material_gallery_search
        .strip()
        .lower()
    )

    materials = list(
        bpy.data.materials
    )

    materials.sort(
        key=lambda mat: mat.name.lower()
    )

    if search:

        materials = [

            mat

            for mat in materials

            if search in mat.name.lower()

        ]

    return materials


# ============================================================
# RESPONSIVE GALLERY
# ============================================================

def get_gallery_layout(context):

    scene = context.scene

    size = (
        scene.material_gallery_size
    )

    region_width = max(
        180,
        context.region.width
    )

    card_width = (
        58
        +
        size * 17
    )

    columns = int(
        region_width
        /
        card_width
    )

    columns = max(
        1,
        columns
    )

    columns = min(
        columns,
        10
    )


    if size >= 9:

        rows = 2


    elif size >= 7:

        rows = 3


    elif size >= 5:

        rows = 4


    elif size >= 3:

        rows = 5


    else:

        rows = 6


    per_page = max(
        1,
        columns * rows
    )


    return (
        columns,
        rows,
        per_page
    )


# ============================================================
# PAGINAZIONE
# ============================================================

def get_gallery_page_data(
    context
):

    scene = context.scene


    materials = get_filtered_materials(
        context
    )


    (
        columns,
        rows,
        per_page
    ) = get_gallery_layout(
        context
    )


    total_pages = max(
        1,
        math.ceil(
            len(materials)
            /
            per_page
        )
    )


    # ========================================================
    # PAGINA REALMENTE VISUALIZZABILE
    # ========================================================

    page = scene.material_gallery_page


    if page < 0:

        page = 0


    if page >= total_pages:

        page = (
            total_pages - 1
        )


    return (

        materials,

        columns,

        rows,

        per_page,

        total_pages,

        page,

    )


# ============================================================
# APPLICA MATERIALE
# ============================================================

def apply_material(
    material,
    context
):

    modified = 0


    for obj in context.selected_objects:


        if obj.type != 'MESH':

            continue


        if len(
            obj.data.materials
        ) == 0:


            obj.data.materials.append(
                material
            )


        else:


            slot = (
                obj.active_material_index
            )


            if slot >= len(
                obj.data.materials
            ):

                slot = 0


            obj.data.materials[
                slot
            ] = material


        modified += 1


    return modified


# ============================================================
# APRI MATERIALE SENZA SELEZIONARE OGGETTI
# ============================================================

def focus_material_in_blender(
    context,
    material
):

    if material is None:

        return False


    found_properties = False

    found_shader_editor = False


    # ========================================================
    # NON TOCCA:
    #
    # - selected_objects
    # - active object
    # - active_material_index
    # ========================================================


    for window in (
        context.window_manager.windows
    ):


        screen = window.screen


        if screen is None:

            continue


        for area in screen.areas:


            # =================================================
            # MATERIAL PROPERTIES
            # =================================================

            if area.type == 'PROPERTIES':


                try:


                    space = (
                        area.spaces.active
                    )


                    space.pin_id = (
                        material
                    )


                    space.use_pin_id = (
                        True
                    )


                    space.context = (
                        'MATERIAL'
                    )


                    found_properties = (
                        True
                    )


                except Exception as error:


                    print(
                        "Fabularis Material Gallery - "
                        "Properties:",
                        error
                    )


            # =================================================
            # SHADER EDITOR
            # =================================================

            elif area.type == 'NODE_EDITOR':


                try:


                    space = (
                        area.spaces.active
                    )


                    if (
                        space.tree_type
                        ==
                        'ShaderNodeTree'
                    ):


                        space.shader_type = (
                            'OBJECT'
                        )


                        if (
                            material.use_nodes
                            and
                            material.node_tree
                            is not None
                        ):


                            space.pin = False


                            space.node_tree = (
                                material.node_tree
                            )


                            space.pin = True


                            found_shader_editor = (
                                True
                            )


                except Exception as error:


                    print(
                        "Fabularis Material Gallery - "
                        "Shader Editor:",
                        error
                    )


            try:

                area.tag_redraw()

            except:

                pass


    try:

        context.view_layer.update()

    except:

        pass


    return (
        found_properties
        or
        found_shader_editor
    )


# ============================================================
# CALLBACK UI
# ============================================================

def gallery_updated(
    self,
    context
):

    if context is None:

        return


    context.scene.material_gallery_page = (
        0
    )


    refresh_material_list(
        context
    )


    redraw_ui(
        context
    )


# ============================================================
# LIST ITEM
# ============================================================

class MATERIALGALLERY_PG_list_item(
    bpy.types.PropertyGroup
):

    material_name: bpy.props.StringProperty()


    selected: bpy.props.BoolProperty(

        name="Selezionato",

        default=False

    )


# ============================================================
# REFRESH LISTA
# ============================================================

def refresh_material_list(
    context
):

    if context is None:

        return


    scene = context.scene


    materials = get_filtered_materials(
        context
    )


    selected_names = {

        item.material_name

        for item in (
            scene.material_gallery_list
        )

        if item.selected

    }


    current_names = [

        item.material_name

        for item in (
            scene.material_gallery_list
        )

    ]


    new_names = [

        mat.name

        for mat in materials

    ]


    # ========================================================
    # SE LA LISTA È GIÀ CORRETTA
    # NON TOCCHIAMO LA COLLECTION
    # ========================================================

    if current_names == new_names:

        return


    scene.material_gallery_list.clear()


    for material in materials:


        item = (
            scene.material_gallery_list.add()
        )


        item.material_name = (
            material.name
        )


        item.selected = (

            material.name
            in
            selected_names

        )


    if (
        scene.material_gallery_list_index
        >=
        len(scene.material_gallery_list)
    ):


        scene.material_gallery_list_index = max(

            0,

            len(
                scene.material_gallery_list
            )
            -
            1

        )


# ============================================================
# TROVA ITEM
# ============================================================

def get_gallery_item(
    scene,
    material_name
):

    for item in (
        scene.material_gallery_list
    ):


        if (
            item.material_name
            ==
            material_name
        ):

            return item


    return None


# ============================================================
# MULTI SELECT
# ============================================================

def get_multi_selected_names(
    scene
):

    return [

        item.material_name

        for item in (
            scene.material_gallery_list
        )

        if item.selected

    ]


def get_multi_selected_materials(
    scene
):

    result = []


    for name in (
        get_multi_selected_names(
            scene
        )
    ):


        material = (
            bpy.data.materials.get(
                name
            )
        )


        if material is not None:

            result.append(
                material
            )


    return result


# ============================================================
# UI LIST MATERIALI
# ============================================================

class MATERIALGALLERY_UL_materials(
    bpy.types.UIList
):


    def draw_item(
        self,
        context,
        layout,
        data,
        item,
        icon,
        active_data,
        active_propname,
        index
    ):


        material = (
            bpy.data.materials.get(
                item.material_name
            )
        )


        if material is None:

            return


        icon_id = get_material_icon(
            material
        )


        row = layout.row(
            align=True
        )


        if (
            context.scene.material_multi_mode
        ):


            row.prop(

                item,

                "selected",

                text=""

            )


        op = row.operator(

            "material_gallery.select_material",

            text=material.name,

            icon_value=icon_id

        )


        op.material_name = (
            material.name
        )


        actions = row.operator(

            "material_gallery.material_actions",

            text="",

            icon='DOWNARROW_HLT'

        )


        actions.material_name = (
            material.name
        )


# ============================================================
# UI LIST REMAP
# ============================================================

class MATERIALGALLERY_UL_remap_materials(
    bpy.types.UIList
):


    def filter_items(
        self,
        context,
        data,
        propname
    ):


        collection = getattr(
            data,
            propname
        )


        search = (
            context.scene.material_remap_search
            .strip()
            .lower()
        )


        if not search:


            return (

                [

                    self.bitflag_filter_item

                    for item in collection

                ],

                []

            )


        flags = []


        for item in collection:


            if (
                search
                in
                item.material_name.lower()
            ):


                flags.append(
                    self.bitflag_filter_item
                )


            else:


                flags.append(
                    0
                )


        return (
            flags,
            []
        )


    def draw_item(
        self,
        context,
        layout,
        data,
        item,
        icon,
        active_data,
        active_propname,
        index
    ):


        material = (
            bpy.data.materials.get(
                item.material_name
            )
        )


        if material is None:

            return


        icon_id = get_material_icon(
            material
        )


        layout.label(

            text=material.name,

            icon_value=icon_id

        )


# ============================================================
# SELEZIONA MATERIALE
# ============================================================

class MATERIALGALLERY_OT_select_material(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.select_material"
    )


    bl_label = (
        "Apri Materiale"
    )


    bl_description = (

        "Apre questo materiale nelle Material Properties "
        "e nello Shader Editor senza cambiare "
        "la selezione degli oggetti"

    )


    material_name: bpy.props.StringProperty()


    def execute(
        self,
        context
    ):


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:


            self.report(
                {'ERROR'},
                "Materiale non trovato"
            )


            return {
                'CANCELLED'
            }


        context.scene.material_gallery_selected = (
            material.name
        )


        opened = focus_material_in_blender(

            context,

            material

        )


        if opened:


            self.report(

                {'INFO'},

                (
                    f"Materiale "
                    f"'{material.name}' "
                    f"aperto"
                )

            )


        else:


            self.report(

                {'WARNING'},

                (
                    f"Materiale "
                    f"'{material.name}' "
                    f"selezionato. "
                    f"Nessun Material Properties/"
                    f"Shader Editor disponibile."
                )

            )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# MENU AZIONI MATERIALE
# ============================================================

class MATERIALGALLERY_OT_material_actions(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.material_actions"
    )


    bl_label = (
        "Azioni Materiale"
    )


    bl_description = (
        "Rinomina o elimina questo materiale"
    )


    material_name: bpy.props.StringProperty()


    def invoke(
        self,
        context,
        event
    ):


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:

            return {
                'CANCELLED'
            }


        material_name = (
            self.material_name
        )


        def draw_menu(
            menu,
            popup_context
        ):


            layout = (
                menu.layout
            )


            material = (
                bpy.data.materials.get(
                    material_name
                )
            )


            if material:


                icon_id = (
                    get_material_icon(
                        material
                    )
                )


                layout.label(

                    text=material.name,

                    icon_value=icon_id

                )


                layout.separator()


            layout.operator_context = (
                'INVOKE_DEFAULT'
            )


            rename = layout.operator(

                "material_gallery.rename_material",

                text="Rinomina materiale...",

                icon='SORTALPHA'

            )


            rename.material_name = (
                material_name
            )


            delete = layout.operator(

                "material_gallery.delete_material",

                text="Elimina materiale...",

                icon='TRASH'

            )


            delete.material_name = (
                material_name
            )


        context.window_manager.popup_menu(

            draw_menu,

            title="Materiale",

            icon='MATERIAL'

        )


        return {
            'FINISHED'
        }


# ============================================================
# RINOMINA MATERIALE
# ============================================================

class MATERIALGALLERY_OT_rename_material(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.rename_material"
    )


    bl_label = (
        "Rinomina Materiale"
    )


    bl_options = {
        'REGISTER',
        'UNDO'
    }


    material_name: bpy.props.StringProperty()


    new_name: bpy.props.StringProperty(

        name="Nuovo nome",

        default=""

    )


    def invoke(
        self,
        context,
        event
    ):


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:

            return {
                'CANCELLED'
            }


        self.new_name = (
            material.name
        )


        return (
            context.window_manager
            .invoke_props_dialog(

                self,

                width=420

            )
        )


    def draw(
        self,
        context
    ):


        layout = self.layout


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is not None:


            box = layout.box()


            row = box.row()


            icon_id = (
                get_material_icon(
                    material
                )
            )


            if icon_id:


                row.template_icon(

                    icon_value=icon_id,

                    scale=3

                )


            column = row.column()


            column.label(
                text="Materiale da rinominare:"
            )


            column.label(

                text=material.name,

                icon='MATERIAL'

            )


        layout.separator()


        layout.prop(

            self,

            "new_name",

            text="Nuovo nome"

        )


    def execute(
        self,
        context
    ):


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:

            return {
                'CANCELLED'
            }


        new_name = (
            self.new_name.strip()
        )


        if new_name == "":


            self.report(

                {'ERROR'},

                "Il nome non può essere vuoto"

            )


            return {
                'CANCELLED'
            }


        old_name = (
            material.name
        )


        was_selected = (

            context.scene
            .material_gallery_selected

            ==

            old_name

        )


        material.name = (
            new_name
        )


        actual_new_name = (
            material.name
        )


        for item in (
            context.scene.material_gallery_list
        ):


            if (
                item.material_name
                ==
                old_name
            ):


                item.material_name = (
                    actual_new_name
                )


        for item in (
            context.scene.material_remap_list
        ):


            if (
                item.material_name
                ==
                old_name
            ):


                item.material_name = (
                    actual_new_name
                )


        if was_selected:


            context.scene.material_gallery_selected = (
                actual_new_name
            )


        redraw_ui(
            context
        )


        self.report(

            {'INFO'},

            (
                f"{old_name} rinominato in "
                f"{actual_new_name}"
            )

        )


        return {
            'FINISHED'
        }


# ============================================================
# ELIMINA MATERIALE
# ============================================================

class MATERIALGALLERY_OT_delete_material(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.delete_material"
    )


    bl_label = (
        "Elimina Materiale"
    )


    bl_options = {
        'REGISTER',
        'UNDO'
    }


    material_name: bpy.props.StringProperty()


    def invoke(
        self,
        context,
        event
    ):


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:

            return {
                'CANCELLED'
            }


        return (
            context.window_manager
            .invoke_props_dialog(

                self,

                width=440

            )
        )


    def draw(
        self,
        context
    ):


        layout = (
            self.layout
        )


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:

            return


        warning_box = (
            layout.box()
        )


        warning_box.alert = (
            True
        )


        header = (
            warning_box.row()
        )


        header.alert = (
            True
        )


        header.label(

            text="ELIMINA MATERIALE",

            icon='ERROR'

        )


        warning_box.separator()


        row = (
            warning_box.row()
        )


        icon_id = (
            get_material_icon(
                material
            )
        )


        if icon_id:


            row.template_icon(

                icon_value=icon_id,

                scale=3

            )


        column = (
            row.column()
        )


        column.alert = True


        column.label(

            text=material.name,

            icon='MATERIAL'

        )


        column.label(

            text=f"Users: {material.users}"

        )


        layout.separator()


        warning = (
            layout.row()
        )


        warning.alert = (
            True
        )


        warning.label(

            text=(
                "Il materiale verrà rimosso "
                "anche dagli oggetti che lo utilizzano."
            ),

            icon='ERROR'

        )


    def execute(
        self,
        context
    ):


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:

            return {
                'CANCELLED'
            }


        material_name = (
            material.name
        )


        if (

            context.scene
            .material_gallery_selected

            ==

            material_name

        ):


            context.scene.material_gallery_selected = (
                ""
            )


        bpy.data.materials.remove(

            material,

            do_unlink=True

        )


        refresh_material_list(
            context
        )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# TOGGLE MULTI
# ============================================================

class MATERIALGALLERY_OT_toggle_multi(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.toggle_multi"
    )


    bl_label = (
        "Seleziona per Multi Remap"
    )


    material_name: bpy.props.StringProperty()


    def execute(
        self,
        context
    ):


        refresh_material_list(
            context
        )


        item = get_gallery_item(

            context.scene,

            self.material_name

        )


        if item is None:

            return {
                'CANCELLED'
            }


        item.selected = (
            not item.selected
        )


        context.scene.material_gallery_selected = (
            self.material_name
        )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# SELECT VISIBLE
# ============================================================

class MATERIALGALLERY_OT_select_visible(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.select_visible"
    )


    bl_label = (
        "Seleziona / Deseleziona"
    )


    select_state: bpy.props.BoolProperty(
        default=True
    )


    def execute(
        self,
        context
    ):


        scene = (
            context.scene
        )


        refresh_material_list(
            context
        )


        if (
            scene.material_gallery_mode
            ==
            'GALLERY'
        ):


            (
                materials,
                columns,
                rows,
                per_page,
                total_pages,
                current_page
            ) = get_gallery_page_data(
                context
            )


            # =================================================
            # IMPORTANTE
            # SINCRONIZZA LO STATO REALE
            # =================================================

            scene.material_gallery_page = (
                current_page
            )


            start = (
                current_page
                *
                per_page
            )


            end = (
                start
                +
                per_page
            )


            names_to_change = {

                material.name

                for material
                in
                materials[start:end]

            }


        else:


            names_to_change = {

                item.material_name

                for item in (
                    scene.material_gallery_list
                )

            }


        for item in (
            scene.material_gallery_list
        ):


            if (
                item.material_name
                in
                names_to_change
            ):


                item.selected = (
                    self.select_state
                )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# CLEAR MULTI
# ============================================================

class MATERIALGALLERY_OT_clear_multi(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.clear_multi"
    )


    bl_label = (
        "Deseleziona tutto"
    )


    def execute(
        self,
        context
    ):


        for item in (
            context.scene.material_gallery_list
        ):


            item.selected = (
                False
            )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# APPLY MATERIAL
# ============================================================

class MATERIALGALLERY_OT_apply_material(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.apply_material"
    )


    bl_label = (
        "Applica Materiale"
    )


    bl_options = {
        'REGISTER',
        'UNDO'
    }


    material_name: bpy.props.StringProperty()


    def execute(
        self,
        context
    ):


        material = (
            bpy.data.materials.get(
                self.material_name
            )
        )


        if material is None:

            return {
                'CANCELLED'
            }


        context.scene.material_gallery_selected = (
            material.name
        )


        modified = apply_material(

            material,

            context

        )


        self.report(

            {'INFO'},

            (
                f"{material.name} applicato a "
                f"{modified} oggetti"
            )

        )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# PAGINA PRECEDENTE
#
# VERSIONE SEMPLICE E ROBUSTA
# ============================================================

class MATERIALGALLERY_OT_page_previous(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.page_previous"
    )


    bl_label = (
        "Pagina precedente"
    )


    bl_description = (
        "Vai alla pagina precedente"
    )


    def execute(
        self,
        context
    ):


        scene = (
            context.scene
        )


        (
            materials,
            columns,
            rows,
            per_page,
            total_pages,
            current_page
        ) = get_gallery_page_data(
            context
        )


        # ====================================================
        # PRIMA SINCRONIZZIAMO LA PAGINA REALE
        # ====================================================

        scene.material_gallery_page = (
            current_page
        )


        # ====================================================
        # POI TORNIAMO INDIETRO
        # ====================================================

        if (
            scene.material_gallery_page
            >
            0
        ):


            scene.material_gallery_page -= (
                1
            )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# PAGINA SUCCESSIVA
#
# VERSIONE SEMPLICE E ROBUSTA
# ============================================================

class MATERIALGALLERY_OT_page_next(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.page_next"
    )


    bl_label = (
        "Pagina successiva"
    )


    bl_description = (
        "Vai alla pagina successiva"
    )


    def execute(
        self,
        context
    ):


        scene = (
            context.scene
        )


        (
            materials,
            columns,
            rows,
            per_page,
            total_pages,
            current_page
        ) = get_gallery_page_data(
            context
        )


        # ====================================================
        # SINCRONIZZA PRIMA LA PAGINA REALMENTE VISUALIZZATA
        # ====================================================

        scene.material_gallery_page = (
            current_page
        )


        # ====================================================
        # NON CI BASIAMO SU enabled DELLA UI.
        #
        # CONTROLLIAMO DIRETTAMENTE SE IL PRIMO ELEMENTO
        # DELLA PAGINA SUCCESSIVA ESISTE.
        # ====================================================

        next_start = (

            (
                scene.material_gallery_page
                +
                1
            )

            *

            per_page

        )


        if (
            next_start
            <
            len(materials)
        ):


            scene.material_gallery_page += (
                1
            )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# BUILD TARGET REMAP LIST
# ============================================================

def build_remap_target_list(
    context,
    excluded_names
):


    scene = (
        context.scene
    )


    scene.material_remap_list.clear()


    materials = [

        material

        for material in (
            bpy.data.materials
        )

        if (
            material.name
            not in
            excluded_names
        )

    ]


    materials.sort(
        key=lambda mat: mat.name.lower()
    )


    for material in materials:


        item = (
            scene.material_remap_list.add()
        )


        item.material_name = (
            material.name
        )


    scene.material_remap_index = (
        0
    )


# ============================================================
# TARGET REMAP
# ============================================================

def get_current_remap_target(
    context
):


    scene = (
        context.scene
    )


    index = (
        scene.material_remap_index
    )


    if (
        index < 0
        or
        index >= len(
            scene.material_remap_list
        )
    ):


        return None


    item = (
        scene.material_remap_list[
            index
        ]
    )


    return (
        bpy.data.materials.get(
            item.material_name
        )
    )


# ============================================================
# REMAP SINGOLO
# ============================================================

class MATERIALGALLERY_OT_remap_users(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.remap_users"
    )


    bl_label = (
        "Remap Material Users"
    )


    bl_options = {
        'REGISTER',
        'UNDO'
    }


    source_material: bpy.props.StringProperty()


    remove_source: bpy.props.BoolProperty(

        name="Elimina materiale originale",

        default=False

    )


    def invoke(
        self,
        context,
        event
    ):


        if not self.source_material:


            self.source_material = (
                context.scene
                .material_gallery_selected
            )


        source = (
            bpy.data.materials.get(
                self.source_material
            )
        )


        if source is None:


            self.report(

                {'ERROR'},

                "Seleziona prima un materiale"

            )


            return {
                'CANCELLED'
            }


        context.scene.material_remap_search = (
            ""
        )


        build_remap_target_list(

            context,

            {
                source.name
            }

        )


        if len(
            context.scene.material_remap_list
        ) == 0:


            self.report(

                {'ERROR'},

                "Nessun materiale di destinazione disponibile"

            )


            return {
                'CANCELLED'
            }


        return (
            context.window_manager
            .invoke_props_dialog(

                self,

                width=520

            )
        )


    def draw(
        self,
        context
    ):


        layout = (
            self.layout
        )


        source = (
            bpy.data.materials.get(
                self.source_material
            )
        )


        if source is None:

            return


        # ====================================================
        # SORGENTE
        # ====================================================

        source_box = (
            layout.box()
        )


        source_box.alert = (
            True
        )


        source_box.label(

            text="MATERIALE DA CAMBIARE (sorgente)",

            icon='ERROR'

        )


        source_box.separator()


        row = (
            source_box.row()
        )


        icon_id = (
            get_material_icon(
                source
            )
        )


        if icon_id:


            row.template_icon(

                icon_value=icon_id,

                scale=4

            )


        column = (
            row.column()
        )


        column.label(

            text=source.name,

            icon='MATERIAL'

        )


        column.label(
            text=f"Users: {source.users}"
        )


        # ====================================================
        # FRECCIA
        # ====================================================

        layout.separator()


        arrow = (
            layout.row()
        )


        arrow.alignment = (
            'CENTER'
        )


        arrow.label(

            text="",

            icon='TRIA_DOWN'

        )


        # ====================================================
        # DESTINAZIONE
        # ====================================================

        destination_box = (
            layout.box()
        )


        destination_box.label(

            text="SOSTITUISCI CON (destinazione)",

            icon='ADD'

        )


        destination_box.separator()


        destination_box.prop(

            context.scene,

            "material_remap_search",

            text="",

            icon='VIEWZOOM'

        )


        destination_box.separator()


        destination_box.template_list(

            "MATERIALGALLERY_UL_remap_materials",

            "",

            context.scene,

            "material_remap_list",

            context.scene,

            "material_remap_index",

            rows=8

        )


        # ====================================================
        # TARGET SELEZIONATO
        # ====================================================

        target = (
            get_current_remap_target(
                context
            )
        )


        if target:


            layout.separator()


            arrow = (
                layout.row()
            )


            arrow.alignment = (
                'CENTER'
            )


            arrow.label(

                text="",

                icon='TRIA_DOWN'

            )


            target_box = (
                layout.box()
            )


            target_box.label(

                text=(
                    "MATERIALE DI DESTINAZIONE "
                    "SELEZIONATO"
                ),

                icon='CHECKMARK'

            )


            target_box.separator()


            row = (
                target_box.row()
            )


            icon_id = (
                get_material_icon(
                    target
                )
            )


            if icon_id:


                row.template_icon(

                    icon_value=icon_id,

                    scale=4

                )


            column = (
                row.column()
            )


            column.label(

                text=target.name,

                icon='MATERIAL'

            )


            column.label(
                text=f"Users: {target.users}"
            )


        # ====================================================
        # ELIMINA
        # ====================================================

        layout.separator()


        remove_box = (
            layout.box()
        )


        remove_box.prop(

            self,

            "remove_source"

        )


    def execute(
        self,
        context
    ):


        source = (
            bpy.data.materials.get(
                self.source_material
            )
        )


        target = (
            get_current_remap_target(
                context
            )
        )


        if (
            source is None
            or
            target is None
        ):


            return {
                'CANCELLED'
            }


        source_name = (
            source.name
        )


        target_name = (
            target.name
        )


        source.user_remap(
            target
        )


        if (
            self.remove_source
            and
            source.users == 0
        ):


            bpy.data.materials.remove(
                source
            )


        context.scene.material_gallery_selected = (
            target_name
        )


        refresh_material_list(
            context
        )


        redraw_ui(
            context
        )


        self.report(

            {'INFO'},

            (
                f"{source_name} -> "
                f"{target_name}"
            )

        )


        return {
            'FINISHED'
        }


# ============================================================
# MULTI REMAP
# ============================================================

class MATERIALGALLERY_OT_multi_remap_users(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.multi_remap_users"
    )


    bl_label = (
        "Multi Remap Material Users"
    )


    bl_options = {
        'REGISTER',
        'UNDO'
    }


    remove_sources: bpy.props.BoolProperty(

        name="Elimina materiali originali",

        default=False

    )


    def invoke(
        self,
        context,
        event
    ):


        refresh_material_list(
            context
        )


        selected_names = (
            get_multi_selected_names(
                context.scene
            )
        )


        if not selected_names:


            self.report(

                {'ERROR'},

                "Seleziona almeno un materiale"

            )


            return {
                'CANCELLED'
            }


        context.scene.material_remap_search = (
            ""
        )


        build_remap_target_list(

            context,

            set(
                selected_names
            )

        )


        if len(
            context.scene.material_remap_list
        ) == 0:


            self.report(

                {'ERROR'},

                "Nessun materiale di destinazione disponibile"

            )


            return {
                'CANCELLED'
            }


        return (
            context.window_manager
            .invoke_props_dialog(

                self,

                width=540

            )
        )


    def draw(
        self,
        context
    ):


        layout = (
            self.layout
        )


        sources = (
            get_multi_selected_materials(
                context.scene
            )
        )


        source_box = (
            layout.box()
        )


        source_box.alert = (
            True
        )


        source_box.label(

            text=(
                f"MATERIALI DA CAMBIARE "
                f"({len(sources)} selezionati)"
            ),

            icon='ERROR'

        )


        source_box.separator()


        for material in sources[:8]:


            row = (
                source_box.row(
                    align=True
                )
            )


            row.label(

                text=material.name,

                icon_value=get_material_icon(
                    material
                )

            )


            row.label(
                text=f"Users: {material.users}"
            )


        if len(sources) > 8:


            source_box.label(

                text=(
                    f"...e altri "
                    f"{len(sources) - 8} materiali"
                )

            )


        layout.separator()


        arrow = (
            layout.row()
        )


        arrow.alignment = (
            'CENTER'
        )


        arrow.label(

            text="",

            icon='TRIA_DOWN'

        )


        target_box = (
            layout.box()
        )


        target_box.label(

            text="SOSTITUISCI TUTTI CON",

            icon='ADD'

        )


        target_box.separator()


        target_box.prop(

            context.scene,

            "material_remap_search",

            text="",

            icon='VIEWZOOM'

        )


        target_box.separator()


        target_box.template_list(

            "MATERIALGALLERY_UL_remap_materials",

            "multi_remap",

            context.scene,

            "material_remap_list",

            context.scene,

            "material_remap_index",

            rows=8

        )


        target = (
            get_current_remap_target(
                context
            )
        )


        if target:


            layout.separator()


            arrow = (
                layout.row()
            )


            arrow.alignment = (
                'CENTER'
            )


            arrow.label(

                text="",

                icon='TRIA_DOWN'

            )


            selected_box = (
                layout.box()
            )


            selected_box.label(

                text=(
                    "MATERIALE DI DESTINAZIONE "
                    "SELEZIONATO"
                ),

                icon='CHECKMARK'

            )


            selected_box.separator()


            row = (
                selected_box.row()
            )


            icon_id = (
                get_material_icon(
                    target
                )
            )


            if icon_id:


                row.template_icon(

                    icon_value=icon_id,

                    scale=4

                )


            column = (
                row.column()
            )


            column.label(

                text=target.name,

                icon='MATERIAL'

            )


            column.label(
                text=f"Users: {target.users}"
            )


        layout.separator()


        remove_box = (
            layout.box()
        )


        remove_box.prop(

            self,

            "remove_sources"

        )


    def execute(
        self,
        context
    ):


        sources = (
            get_multi_selected_materials(
                context.scene
            )
        )


        target = (
            get_current_remap_target(
                context
            )
        )


        if (
            not sources
            or
            target is None
        ):


            return {
                'CANCELLED'
            }


        target_name = (
            target.name
        )


        source_names = [

            source.name

            for source in sources

        ]


        for source in sources:


            if source != target:


                source.user_remap(
                    target
                )


        if self.remove_sources:


            for source_name in (
                source_names
            ):


                source = (
                    bpy.data.materials.get(
                        source_name
                    )
                )


                if (
                    source is not None
                    and
                    source != target
                    and
                    source.users == 0
                ):


                    bpy.data.materials.remove(
                        source
                    )


        for item in (
            context.scene.material_gallery_list
        ):


            item.selected = (
                False
            )


        context.scene.material_gallery_selected = (
            target_name
        )


        refresh_material_list(
            context
        )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# REFRESH
# ============================================================

class MATERIALGALLERY_OT_refresh(
    bpy.types.Operator
):


    bl_idname = (
        "material_gallery.refresh"
    )


    bl_label = (
        "Aggiorna"
    )


    def execute(
        self,
        context
    ):


        for material in (
            bpy.data.materials
        ):


            try:


                material.preview_ensure()


            except:


                pass


        # ====================================================
        # SE I MATERIALI SONO CAMBIATI,
        # TORNIAMO ALLA PRIMA PAGINA
        # ====================================================

        context.scene.material_gallery_page = (
            0
        )


        refresh_material_list(
            context
        )


        redraw_ui(
            context
        )


        return {
            'FINISHED'
        }


# ============================================================
# MACRO GRUPPO MATERIAL
# ============================================================

class FABULARIS_PT_material(
    bpy.types.Panel
):


    bl_label = (
        "Material"
    )


    bl_idname = (
        "FABULARIS_PT_material"
    )


    bl_space_type = (
        'VIEW_3D'
    )


    bl_region_type = (
        'UI'
    )


    bl_category = (
        "Fabularis Tools"
    )


    def draw(
        self,
        context
    ):


        pass


# ============================================================
# MATERIAL GALLERY PANEL
# ============================================================

class MATERIALGALLERY_PT_panel(
    bpy.types.Panel
):


    bl_label = (
        "Material Gallery"
    )


    bl_idname = (
        "MATERIALGALLERY_PT_panel"
    )


    bl_space_type = (
        'VIEW_3D'
    )


    bl_region_type = (
        'UI'
    )


    bl_category = (
        "Fabularis Tools"
    )


    bl_parent_id = (
        "FABULARIS_PT_material"
    )


    def draw(
        self,
        context
    ):


        layout = (
            self.layout
        )


        scene = (
            context.scene
        )


        # ====================================================
        # SEARCH
        # ====================================================

        row = layout.row(
            align=True
        )


        row.prop(

            scene,

            "material_gallery_search",

            text="",

            icon='VIEWZOOM'

        )


        row.operator(

            "material_gallery.refresh",

            text="",

            icon='FILE_REFRESH'

        )


        # ====================================================
        # GALLERY / LIST
        # ====================================================

        layout.separator()


        layout.prop(

            scene,

            "material_gallery_mode",

            expand=True

        )


        materials = get_filtered_materials(
            context
        )


        layout.label(

            text=f"{len(materials)} materiali",

            icon='MATERIAL'

        )


        # ====================================================
        # MULTI REMAP
        # ====================================================

        layout.separator()


        layout.prop(

            scene,

            "material_multi_mode",

            text="Multi Remap",

            toggle=True,

            icon='CHECKBOX_HLT'

        )


        if scene.material_multi_mode:


            selected_count = len(
                get_multi_selected_names(
                    scene
                )
            )


            row = layout.row(
                align=True
            )


            row.label(

                text=(
                    f"{selected_count} "
                    f"materiali selezionati"
                )

            )


            row.operator(

                "material_gallery.clear_multi",

                text="",

                icon='X'

            )


            row = layout.row(
                align=True
            )


            select_op = row.operator(

                "material_gallery.select_visible",

                text=(

                    "Seleziona pagina"

                    if
                    scene.material_gallery_mode
                    ==
                    'GALLERY'

                    else

                    "Seleziona lista"

                ),

                icon='CHECKBOX_HLT'

            )


            select_op.select_state = (
                True
            )


            deselect_op = row.operator(

                "material_gallery.select_visible",

                text=(

                    "Deseleziona pagina"

                    if
                    scene.material_gallery_mode
                    ==
                    'GALLERY'

                    else

                    "Deseleziona lista"

                ),

                icon='CHECKBOX_DEHLT'

            )


            deselect_op.select_state = (
                False
            )


        # ====================================================
        # GALLERY
        # ====================================================

        if (
            scene.material_gallery_mode
            ==
            'GALLERY'
        ):


            layout.separator()


            layout.label(
                text="Dimensione Preview"
            )


            layout.prop(

                scene,

                "material_gallery_size",

                text="",

                slider=True

            )


            (
                materials,
                columns,
                rows,
                per_page,
                total_pages,
                current_page
            ) = get_gallery_page_data(
                context
            )


            info = (
                layout.row()
            )


            info.enabled = (
                False
            )


            info.label(

                text=(

                    f"{columns} colonne  |  "

                    f"{rows} righe  |  "

                    f"{per_page} per pagina"

                )

            )


            start = (
                current_page
                *
                per_page
            )


            end = (
                start
                +
                per_page
            )


            page_materials = (
                materials[start:end]
            )


            # =================================================
            # GRID
            # =================================================

            grid = layout.grid_flow(

                row_major=True,

                columns=columns,

                even_columns=True,

                even_rows=False,

                align=True

            )


            for material in (
                page_materials
            ):


                box = (
                    grid.box()
                )


                icon_id = (
                    get_material_icon(
                        material
                    )
                )


                gallery_item = (
                    get_gallery_item(

                        scene,

                        material.name

                    )
                )


                # ============================================
                # HEADER
                # ============================================

                name_row = box.row(
                    align=True
                )


                if (
                    scene.material_multi_mode
                    and
                    gallery_item is not None
                ):


                    name_row.prop(

                        gallery_item,

                        "selected",

                        text=""

                    )


                name = name_row.operator(

                    "material_gallery.select_material",

                    text=material.name,

                    emboss=False

                )


                name.material_name = (
                    material.name
                )


                # ============================================
                # MENU
                # ============================================

                actions = name_row.operator(

                    "material_gallery.material_actions",

                    text="",

                    icon='DOWNARROW_HLT'

                )


                actions.material_name = (
                    material.name
                )


                # ============================================
                # PREVIEW
                # ============================================

                if icon_id:


                    preview_row = (
                        box.row()
                    )


                    preview_row.alignment = (
                        'CENTER'
                    )


                    preview_row.template_icon(

                        icon_value=icon_id,

                        scale=(

                            1.4

                            +

                            scene.material_gallery_size

                            *

                            0.50

                        )

                    )


                # ============================================
                # APPLICA
                # ============================================

                apply_row = (
                    box.row()
                )


                apply_row.scale_y = (
                    1.10
                )


                apply_button = (
                    apply_row.operator(

                        "material_gallery.apply_material",

                        text="Applica",

                        icon='CHECKMARK'

                    )
                )


                apply_button.material_name = (
                    material.name
                )


            # =================================================
            # PAGINAZIONE
            #
            # LE FRECCE RIMANGONO SEMPRE CLICCABILI.
            # SONO GLI OPERATORI A DECIDERE SE POSSONO MUOVERSI.
            # =================================================

            layout.separator()


            row = layout.row(
                align=True
            )


            row.operator(

                "material_gallery.page_previous",

                text="",

                icon='TRIA_LEFT'

            )


            row.label(

                text=(

                    f"Pagina "

                    f"{current_page + 1}"

                    f" / "

                    f"{total_pages}"

                )

            )


            row.operator(

                "material_gallery.page_next",

                text="",

                icon='TRIA_RIGHT'

            )


        # ====================================================
        # LISTA
        # ====================================================

        else:


            layout.separator()


            layout.template_list(

                "MATERIALGALLERY_UL_materials",

                "",

                scene,

                "material_gallery_list",

                scene,

                "material_gallery_list_index",

                rows=8

            )


        # ====================================================
        # REMAP
        # ====================================================

        layout.separator()


        if scene.material_multi_mode:


            selected_count = len(
                get_multi_selected_names(
                    scene
                )
            )


            row = (
                layout.row()
            )


            row.enabled = (
                selected_count > 0
            )


            row.operator(

                "material_gallery.multi_remap_users",

                text=(

                    f"Remap selezionati... "

                    f"({selected_count})"

                ),

                icon='FILE_REFRESH'

            )


        else:


            selected_name = (
                scene.material_gallery_selected
            )


            selected = (
                bpy.data.materials.get(
                    selected_name
                )
            )


            if selected:


                remap = (
                    layout.operator(

                        "material_gallery.remap_users",

                        text="Remap Users...",

                        icon='FILE_REFRESH'

                    )
                )


                remap.source_material = (
                    selected.name
                )


            else:


                row = (
                    layout.row()
                )


                row.enabled = (
                    False
                )


                row.operator(

                    "material_gallery.remap_users",

                    text="Remap Users...",

                    icon='FILE_REFRESH'

                )


        # ====================================================
        # MATERIALE SELEZIONATO
        # ====================================================

        selected_name = (
            scene.material_gallery_selected
        )


        selected = (
            bpy.data.materials.get(
                selected_name
            )
        )


        if selected:


            layout.separator()


            box = (
                layout.box()
            )


            row = (
                box.row()
            )


            icon_id = (
                get_material_icon(
                    selected
                )
            )


            if icon_id:


                row.template_icon(

                    icon_value=icon_id,

                    scale=2

                )


            column = (
                row.column()
            )


            column.label(
                text=selected.name
            )


            column.label(
                text=f"Users: {selected.users}"
            )


# ============================================================
# CLASSI
# ============================================================

classes = (

    MATERIALGALLERY_PG_list_item,

    MATERIALGALLERY_UL_materials,

    MATERIALGALLERY_UL_remap_materials,

    MATERIALGALLERY_OT_select_material,

    MATERIALGALLERY_OT_material_actions,

    MATERIALGALLERY_OT_rename_material,

    MATERIALGALLERY_OT_delete_material,

    MATERIALGALLERY_OT_toggle_multi,

    MATERIALGALLERY_OT_select_visible,

    MATERIALGALLERY_OT_clear_multi,

    MATERIALGALLERY_OT_apply_material,

    MATERIALGALLERY_OT_page_previous,

    MATERIALGALLERY_OT_page_next,

    MATERIALGALLERY_OT_remap_users,

    MATERIALGALLERY_OT_multi_remap_users,

    MATERIALGALLERY_OT_refresh,

    FABULARIS_PT_material,

    MATERIALGALLERY_PT_panel,

)


# ============================================================
# REGISTER
# ============================================================

def register():


    for cls in classes:


        bpy.utils.register_class(
            cls
        )


    bpy.types.Scene.material_gallery_search = (
        bpy.props.StringProperty(

            name="Search",

            default="",

            update=gallery_updated

        )
    )


    bpy.types.Scene.material_gallery_mode = (
        bpy.props.EnumProperty(

            name="Visualizzazione",

            items=[

                (
                    'GALLERY',

                    "Gallery",

                    "Gallery responsive"
                ),

                (
                    'LIST',

                    "Lista",

                    "Lista interna scrollabile"
                ),

            ],

            default='GALLERY'

        )
    )


    bpy.types.Scene.material_gallery_selected = (
        bpy.props.StringProperty(

            name="Materiale selezionato",

            default=""

        )
    )


    bpy.types.Scene.material_gallery_size = (
        bpy.props.IntProperty(

            name="Dimensione Preview",

            default=7,

            min=1,

            max=10,

            update=gallery_updated

        )
    )


    bpy.types.Scene.material_gallery_page = (
        bpy.props.IntProperty(

            default=0,

            min=0

        )
    )


    bpy.types.Scene.material_multi_mode = (
        bpy.props.BoolProperty(

            name="Multi Remap",

            description=(

                "Permette di selezionare "
                "piu materiali e rimapparli "
                "verso un unico materiale"

            ),

            default=False

        )
    )


    bpy.types.Scene.material_gallery_list = (
        bpy.props.CollectionProperty(

            type=MATERIALGALLERY_PG_list_item

        )
    )


    bpy.types.Scene.material_gallery_list_index = (
        bpy.props.IntProperty(

            default=0

        )
    )


    bpy.types.Scene.material_remap_list = (
        bpy.props.CollectionProperty(

            type=MATERIALGALLERY_PG_list_item

        )
    )


    bpy.types.Scene.material_remap_index = (
        bpy.props.IntProperty(

            default=0

        )
    )


    bpy.types.Scene.material_remap_search = (
        bpy.props.StringProperty(

            name="Cerca materiale",

            default=""

        )
    )


# ============================================================
# UNREGISTER
# ============================================================

def unregister():


    properties = [

        "material_remap_search",

        "material_remap_index",

        "material_remap_list",

        "material_gallery_list_index",

        "material_gallery_list",

        "material_multi_mode",

        "material_gallery_page",

        "material_gallery_size",

        "material_gallery_selected",

        "material_gallery_mode",

        "material_gallery_search",

    ]


    for prop in properties:


        if hasattr(
            bpy.types.Scene,
            prop
        ):


            delattr(
                bpy.types.Scene,
                prop
            )


    for cls in reversed(
        classes
    ):


        try:


            bpy.utils.unregister_class(
                cls
            )


        except:


            pass