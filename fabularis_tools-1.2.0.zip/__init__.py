bl_info = {
    "name": "Fabularis Tools",
    "author": "Fabularis Lab",
    "version": (1, 1, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Fabularis Tools",
    "description": "Raccolta di strumenti personalizzati Fabularis Lab",
    "category": "3D View",
}


# ============================================================
# MODULI
# ============================================================

from . import material_gallery
from . import material_add
from . import collection_to_empty
from . import empty_to_collection
from . import find_collection_original
from . import uv_tools


modules = (
    material_gallery,
    material_add,
    collection_to_empty,
    empty_to_collection,
    find_collection_original,
    uv_tools,
)


# ============================================================
# REGISTER
# ============================================================

def register():

    for module in modules:
        module.register()


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    for module in reversed(modules):
        module.unregister()